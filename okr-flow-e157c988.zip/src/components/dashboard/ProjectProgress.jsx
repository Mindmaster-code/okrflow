import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { FolderOpen, Calendar } from "lucide-react";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

// Função helper para formatar data corretamente sem problemas de timezone
const formatDate = (dateString) => {
  try {
    // Se a data já tem horário, use parseISO
    if (dateString.includes('T')) {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    }
    // Se é só data (YYYY-MM-DD), adicione o timezone local
    const [year, month, day] = dateString.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    return format(date, "dd/MM/yyyy", { locale: ptBR });
  } catch (error) {
    console.error('Error formatting date:', error);
    return dateString;
  }
};

export default function ProjectProgress({ projects, objectives }) {
  const getProjectProgress = (project) => {
    const projectObjectives = objectives.filter(o => o.project_id === project.id);
    if (projectObjectives.length === 0) return 0;
    
    const totalProgress = projectObjectives.reduce((sum, obj) => sum + obj.progress, 0);
    return Math.round(totalProgress / projectObjectives.length);
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-slate-900">
          <FolderOpen className="w-5 h-5 text-blue-600" />
          Progresso dos Projetos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {projects.slice(0, 5).map((project) => {
            const progress = getProjectProgress(project);
            return (
              <div key={project.id} className="space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold text-slate-900">{project.name}</h4>
                    <p className="text-sm text-slate-500">{project.responsible}</p>
                  </div>
                  <span className="text-2xl font-bold text-slate-900">{progress}%</span>
                </div>
                <Progress value={progress} className="h-3" />
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formatDate(project.start_date)} - {formatDate(project.end_date)}
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    project.status === 'active' ? 'bg-green-100 text-green-700' :
                    project.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {project.status === 'active' ? 'Ativo' :
                     project.status === 'completed' ? 'Concluído' : 'Pausado'}
                  </span>
                </div>
              </div>
            );
          })}
          {projects.length === 0 && (
            <p className="text-center text-slate-500 py-8">
              Nenhum projeto encontrado
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}