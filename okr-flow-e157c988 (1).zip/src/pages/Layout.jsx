

import React, { useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { 
  Home, 
  FolderKanban, 
  Target, 
  Key, 
  Zap, 
  Calendar, 
  BarChart3,
  LogOut,
  User,
  ChevronRight,
  Sparkles
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import OnboardingModal from "./components/profile/OnboardingModal";
import AIAssistantModal from "./components/ai/AIAssistantModal";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [showOnboarding, setShowOnboarding] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [showAIAssistant, setShowAIAssistant] = React.useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      if (!userData.company || !userData.position || !userData.goal) {
        setShowOnboarding(true);
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    loadUser();
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const menuItems = [
    { name: "Dashboard", icon: Home, path: createPageUrl("Dashboard") },
    { name: "Objetivos", icon: Target, path: createPageUrl("Objectives") },
    { name: "Key Results", icon: Key, path: createPageUrl("KeyResults") },
    { name: "Iniciativas", icon: Zap, path: createPageUrl("Initiatives") },
    { name: "Check-ins", icon: Calendar, path: createPageUrl("CheckIns") },
    { name: "Relatórios", icon: BarChart3, path: createPageUrl("Reports") }
  ];

  // SE A PÁGINA ATUAL É A LANDING, NÃO RENDERIZA O LAYOUT!
  if (currentPageName === "Home" || currentPageName === "Landing") {
    return <>{children}</>;
  }

  // For all other pages, show a loading spinner while user data is being fetched.
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="animate-pulse text-slate-600">Carregando...</div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <OnboardingModal 
        open={showOnboarding} 
        onComplete={handleOnboardingComplete}
      />
      
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 to-blue-50">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarContent className="bg-white">
            <div className="p-6 border-b border-slate-200 bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">OKR Flow</h1>
                  <p className="text-xs text-slate-500">Gestão Estratégica</p>
                </div>
              </div>
            </div>

            <SidebarGroup className="bg-white">
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase px-6 py-2 bg-white">
                Navegação
              </SidebarGroupLabel>
              <SidebarGroupContent className="bg-white">
                <SidebarMenu>
                  {menuItems.map((item) => {
                    const isActive = location.pathname === item.path;
                    return (
                      <SidebarMenuItem key={item.name}>
                        <SidebarMenuButton asChild isActive={isActive}>
                          <Link 
                            to={item.path} 
                            className={`flex items-center gap-3 px-6 py-3 transition-colors ${
                              isActive 
                                ? 'bg-purple-50 text-purple-700' 
                                : 'text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.name}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {user && (
              <div className="mt-auto p-6 border-t border-slate-200 bg-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{user.full_name || user.email}</p>
                    <p className="text-xs text-slate-500 truncate">{user.email}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Link to={createPageUrl("Profile")}>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <User className="w-4 h-4 mr-2" />
                      Meu Perfil
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm" onClick={handleLogout} className="w-full justify-start">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </Button>
                </div>
              </div>
            )}
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Home className="w-4 h-4" />
                <ChevronRight className="w-4 h-4" />
                <span className="font-medium text-slate-900">{currentPageName || "Dashboard"}</span>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>

          {user && !loading && (
            <Button
              onClick={() => setShowAIAssistant(true)}
              className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-2xl bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 hover:scale-110 transition-all duration-300 z-50"
              title="Assistente de OKRs com IA"
            >
              <Sparkles className="w-6 h-6 text-white" />
            </Button>
          )}
        </main>
      </div>

      {user && (
        <AIAssistantModal
          open={showAIAssistant}
          onClose={() => setShowAIAssistant(false)}
          user={user}
        />
      )}
    </SidebarProvider>
  );
}

