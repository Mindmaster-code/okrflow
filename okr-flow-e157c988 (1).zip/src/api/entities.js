import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Objective = base44.entities.Objective;

export const KeyResult = base44.entities.KeyResult;

export const Sprint = base44.entities.Sprint;

export const CheckIn = base44.entities.CheckIn;



// auth sdk:
export const User = base44.auth;