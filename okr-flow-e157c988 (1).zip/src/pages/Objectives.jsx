
import React, { useState, useEffect, useCallback } from "react";
import { Objective, KeyResult } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Target, Eye, Building2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

import ObjectiveForm from "../components/objectives/ObjectiveForm";
import ObjectiveCard from "../components/objectives/ObjectiveCard";
import ObjectiveFilters from "../components/objectives/ObjectiveFilters";

export default function Objectives() {
  const [objectives, setObjectives] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingObjective, setEditingObjective] = useState(null);
  const [filters, setFilters] = useState({
    department: 'all',
    quarter: 'all',
    year: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  const recalculateObjectivesProgress = async (objectivesData, keyResultsData) => {
    for (const objective of objectivesData) {
      const relatedKeyResults = keyResultsData.filter(kr => kr.objective_id === objective.id);
      
      let newProgress = 0;
      if (relatedKeyResults.length > 0) {
        const totalProgress = relatedKeyResults.reduce((sum, kr) => {
          const krProgress = kr.target_value > 0 ? Math.min(100, (kr.current_value / kr.target_value) * 100) : 0;
          return sum + krProgress;
        }, 0);
        newProgress = Math.round(totalProgress / relatedKeyResults.length);
      }
      
      if (objective.progress !== newProgress) {
        await Objective.update(objective.id, { 
          title: objective.title,
          description: objective.description || '', // Ensure description is a string
          department: objective.department,
          quarter: objective.quarter,
          year: objective.year,
          progress: newProgress 
        });
      }
    }
  };

  const loadData = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let objectivesData;
      
      if (userData.role === 'admin' && showAllUsers) {
        const allObjectives = await Objective.list('-created_date');
        const allUsersData = await User.list();
        
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(uniqueCompanies);

        let filteredObjectivesByCompany = allObjectives;
        let usersInCurrentScope = [...new Set(allObjectives.map(o => o.created_by))].filter(Boolean);
        
        if (selectedCompany !== 'all') {
          const usersFromSelectedCompany = allUsersData
            .filter(u => (u.company || 'Sem empresa') === selectedCompany)
            .map(u => u.email);
          
          filteredObjectivesByCompany = allObjectives.filter(o => 
            usersFromSelectedCompany.includes(o.created_by)
          );
          usersInCurrentScope = usersFromSelectedCompany.filter(u => 
            filteredObjectivesByCompany.some(o => o.created_by === u)
          );
        }
        
        setAllUsers(usersInCurrentScope.sort());

        if (selectedUser !== 'all') {
          objectivesData = filteredObjectivesByCompany.filter(o => o.created_by === selectedUser);
        } else {
          objectivesData = filteredObjectivesByCompany;
        }

      } else {
        objectivesData = await Objective.filter({ created_by: userData.email });
        setAllUsers([]);
        setAllCompanies([]);
        setSelectedCompany('all');
        setSelectedUser('all');
        setUserCompanyMap({});
      }
      
      setObjectives(objectivesData);
      
      const allKeyResults = await KeyResult.list();
      const objectiveIds = objectivesData.map(obj => obj.id);
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));

      setKeyResults(keyResultsData);
      
      await recalculateObjectivesProgress(objectivesData, keyResultsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, [showAllUsers, selectedCompany, selectedUser]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSubmit = async (objectiveData) => {
    try {
      if (editingObjective) {
        await Objective.update(editingObjective.id, objectiveData);
      } else {
        await Objective.create(objectiveData);
      }
      setShowForm(false);
      setEditingObjective(null);
      loadData();
    } catch (error) {
      console.error('Error saving objective:', error);
    }
  };

  const handleEdit = (objective) => {
    setEditingObjective(objective);
    setShowForm(true);
  };

  const handleDelete = async (objectiveId) => {
    if (window.confirm('Tem certeza que deseja excluir este objetivo? Todos os resultados chave relacionados serão afetados.')) {
      try {
        await Objective.delete(objectiveId);
        loadData();
      } catch (error) {
        console.error('Error deleting objective:', error);
      }
    }
  };

  const getFilteredObjectives = () => {
    return objectives.filter(objective => {
      return (filters.department === 'all' || objective.department === filters.department) &&
             (filters.quarter === 'all' || objective.quarter === filters.quarter) &&
             (filters.year === 'all' || objective.year.toString() === filters.year);
    });
  };

  const getObjectiveKeyResults = (objectiveId) => {
    return keyResults.filter(kr => kr.objective_id === objectiveId);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="h-80 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Objetivos</h1>
              <p className="text-slate-600">Gerencie seus objetivos estratégicos por trimestre</p>
            </div>
          </div>
          <Button 
            onClick={() => {
              setShowForm(true);
              setEditingObjective(null);
            }}
            className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Objetivo
          </Button>
        </div>

        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-obj"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all');
                      setSelectedUser('all');
                    }}
                  />
                  <Label htmlFor="show-all-obj" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-purple-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all');
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && userCompanyMap[email] !== 'Sem empresa' && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <ObjectiveForm
              objective={editingObjective}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingObjective(null);
              }}
            />
          </div>
        )}

        <ObjectiveFilters
          filters={filters}
          onFiltersChange={setFilters}
          objectives={objectives}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getFilteredObjectives().map((objective) => (
            <div key={objective.id} className="relative">
              {showAllUsers && user?.role === 'admin' && (
                <Badge className="absolute -top-2 -right-2 z-10 bg-purple-600 text-white text-xs">
                  {objective.created_by}
                </Badge>
              )}
              <ObjectiveCard
                objective={objective}
                keyResults={getObjectiveKeyResults(objective.id)}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>

        {getFilteredObjectives().length === 0 && (
          <div className="text-center py-16">
            <Target className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum objetivo encontrado
            </h3>
            <p className="text-slate-500 mb-6">
              Crie seu primeiro objetivo estratégico para começar
            </p>
            <Button 
              onClick={() => {
                setShowForm(true);
                setEditingObjective(null);
              }}
              className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Criar Primeiro Objetivo
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
