import React, { useState, useEffect } from "react";
import { Project, Objective, KeyResult, Initiative, Sprint } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Target, FolderOpen, Key, Zap, Calendar, TrendingUp, RefreshCw } from "lucide-react";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Button } from "@/components/ui/button";

import StatsOverview from "../components/dashboard/StatsOverview";
import ProjectProgress from "../components/dashboard/ProjectProgress";
import ObjectiveProgress from "../components/dashboard/ObjectiveProgress";
import SprintStatus from "../components/dashboard/SprintStatus";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [initiatives, setInitiatives] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
    
    // Auto-refresh a cada 30 segundos
    const interval = setInterval(() => {
      loadData(true);
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const loadData = async (silent = false) => {
    if (!silent) setLoading(true);
    if (silent) setRefreshing(true);
    
    try {
      const userData = await User.me();
      setUser(userData);
      
      // Buscar apenas projetos do usuário
      const projectsData = await Project.filter({ created_by: userData.email });
      const projectIds = projectsData.map(p => p.id);
      
      // Buscar objetivos dos projetos do usuário
      const allObjectives = await Objective.list();
      const objectivesData = allObjectives.filter(obj => projectIds.includes(obj.project_id));
      const objectiveIds = objectivesData.map(obj => obj.id);
      
      // Buscar key results dos objetivos do usuário
      const allKeyResults = await KeyResult.list();
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
      const keyResultIds = keyResultsData.map(kr => kr.id);
      
      // Buscar iniciativas dos key results do usuário
      const allInitiatives = await Initiative.list();
      const initiativesData = allInitiatives.filter(init => keyResultIds.includes(init.key_result_id));
      
      // Buscar sprints dos projetos do usuário
      const allSprints = await Sprint.list();
      const sprintsData = allSprints.filter(spr => projectIds.includes(spr.project_id));

      setProjects(projectsData);
      setObjectives(objectivesData);
      setKeyResults(keyResultsData);
      setInitiatives(initiativesData);
      setSprints(sprintsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleManualRefresh = () => {
    loadData();
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-64 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-32 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              Dashboard OKR Flow
            </h1>
            <p className="text-slate-600 text-lg">
              Visão geral dos seus projetos e objetivos
            </p>
          </div>
          <Button
            onClick={handleManualRefresh}
            disabled={refreshing}
            variant="outline"
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        <StatsOverview 
          projects={projects}
          objectives={objectives}
          keyResults={keyResults}
          initiatives={initiatives}
          sprints={sprints}
        />

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <ProjectProgress projects={projects} objectives={objectives} />
          <ObjectiveProgress objectives={objectives} keyResults={keyResults} />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <SprintStatus sprints={sprints} initiatives={initiatives} />
          </div>
          
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-slate-900">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Atividade Recente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {initiatives.slice(0, 5).map((initiative) => (
                  <div key={initiative.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50">
                    <div className={`w-3 h-3 rounded-full ${
                      initiative.status === 'done' ? 'bg-green-500' :
                      initiative.status === 'doing' ? 'bg-blue-500' : 'bg-slate-300'
                    }`}></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm text-slate-900">{initiative.title}</p>
                      <p className="text-xs text-slate-500">{initiative.responsible}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}