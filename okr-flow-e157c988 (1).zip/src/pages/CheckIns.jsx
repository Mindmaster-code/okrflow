
import React, { useState, useEffect } from "react";
import { CheckIn, KeyResult, Objective } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Calendar, TrendingUp, AlertTriangle, CheckCircle2, Eye, Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

import CheckInModal from "../components/checkins/CheckInModal";
import KeyResultCheckInCard from "../components/checkins/KeyResultCheckInCard";
import CheckInFilters from "../components/checkins/CheckInFilters";

export default function CheckInsPage() {
  const [keyResults, setKeyResults] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [checkIns, setCheckIns] = useState([]);
  const [selectedKR, setSelectedKR] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [filters, setFilters] = useState({
    objective: 'all',
    status: 'all',
    needsUpdate: false
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Admin filters
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  useEffect(() => {
    loadData();
  }, [showAllUsers, selectedCompany, selectedUser]);

  const loadData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);

      const allObjectives = await Objective.list('-created_date');
      const allKeyResults = await KeyResult.list();
      const allCheckIns = await CheckIn.list('-check_in_date');

      let objectivesData;
      let keyResultsData;
      let checkInsData;

      if (userData.role === 'admin' && showAllUsers) {
        const allUsersData = await User.list();
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(uniqueCompanies);

        let usersInScope = Object.keys(companyMap);
        
        if (selectedCompany !== 'all') {
          usersInScope = usersInScope.filter(
            email => companyMap[email] === selectedCompany
          );
        }
        
        if (selectedUser !== 'all') {
          usersInScope = [selectedUser];
        }
        
        setAllUsers(usersInScope);

        objectivesData = allObjectives.filter(o => usersInScope.includes(o.created_by));
        const objectiveIds = objectivesData.map(o => o.id);
        keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        const keyResultIds = keyResultsData.map(kr => kr.id);
        checkInsData = allCheckIns.filter(ci => keyResultIds.includes(ci.key_result_id));
      } else {
        objectivesData = allObjectives.filter(o => o.created_by === userData.email);
        const objectiveIds = objectivesData.map(o => o.id);
        keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        const keyResultIds = keyResultsData.map(kr => kr.id);
        checkInsData = allCheckIns.filter(ci => keyResultIds.includes(ci.key_result_id));
        
        setAllUsers([]);
        setAllCompanies([]);
        setSelectedCompany('all');
        setSelectedUser('all');
        setUserCompanyMap({});
      }

      setObjectives(objectivesData);
      setKeyResults(keyResultsData);
      setCheckIns(checkInsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = (kr) => {
    setSelectedKR(kr);
    setShowModal(true);
  };

  const handleSubmitCheckIn = async (checkInData) => {
    try {
      await CheckIn.create(checkInData);
      
      // Calcular o novo progresso
      const newProgress = selectedKR.target_value > 0 
        ? Math.min(100, Math.round((checkInData.new_value / selectedKR.target_value) * 100))
        : 0;
      
      // Atualizar o valor atual E o progresso do Key Result
      await KeyResult.update(selectedKR.id, {
        current_value: checkInData.new_value,
        progress: newProgress
      });

      setShowModal(false);
      setSelectedKR(null);
      loadData();
    } catch (error) {
      console.error('Error creating check-in:', error);
      alert('Erro ao salvar check-in');
    }
  };

  const getFilteredKeyResults = () => {
    let filtered = keyResults;

    if (filters.objective !== 'all') {
      filtered = filtered.filter(kr => kr.objective_id === filters.objective);
    }

    if (filters.status !== 'all') {
      filtered = filtered.filter(kr => {
        const lastCheckIn = getLastCheckIn(kr.id);
        return lastCheckIn?.status === filters.status;
      });
    }

    if (filters.needsUpdate) {
      filtered = filtered.filter(kr => {
        const lastCheckIn = getLastCheckIn(kr.id);
        if (!lastCheckIn) return true;
        
        const daysSinceUpdate = Math.floor(
          (new Date() - new Date(lastCheckIn.check_in_date)) / (1000 * 60 * 60 * 24)
        );
        return daysSinceUpdate > 7;
      });
    }

    return filtered;
  };

  const getLastCheckIn = (keyResultId) => {
    const krCheckIns = checkIns.filter(ci => ci.key_result_id === keyResultId);
    return krCheckIns.length > 0 ? krCheckIns[0] : null;
  };

  const getKeyResultCheckIns = (keyResultId) => {
    return checkIns.filter(ci => ci.key_result_id === keyResultId);
  };

  const getObjectiveInfo = (objectiveId) => {
    return objectives.find(obj => obj.id === objectiveId);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 gap-6">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-64 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const stats = {
    total: keyResults.length,
    onTrack: keyResults.filter(kr => {
      const lastCheckIn = getLastCheckIn(kr.id);
      return lastCheckIn?.status === 'on_track';
    }).length,
    atRisk: keyResults.filter(kr => {
      const lastCheckIn = getLastCheckIn(kr.id);
      return lastCheckIn?.status === 'at_risk';
    }).length,
    offTrack: keyResults.filter(kr => {
      const lastCheckIn = getLastCheckIn(kr.id);
      return lastCheckIn?.status === 'off_track';
    }).length,
    needsUpdate: keyResults.filter(kr => {
      const lastCheckIn = getLastCheckIn(kr.id);
      if (!lastCheckIn) return true;
      const daysSinceUpdate = Math.floor(
        (new Date() - new Date(lastCheckIn.check_in_date)) / (1000 * 60 * 60 * 24)
      );
      return daysSinceUpdate > 7;
    }).length
  };

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
            <Calendar className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Check-ins de OKRs</h1>
            <p className="text-slate-600">Atualize o progresso dos seus Key Results</p>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
              <p className="text-xs text-slate-600">Total de KRs</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-700">{stats.onTrack}</p>
              <p className="text-xs text-slate-600">No Rumo</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-700">{stats.atRisk}</p>
              <p className="text-xs text-slate-600">Em Risco</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-red-700">{stats.offTrack}</p>
              <p className="text-xs text-slate-600">Fora do Rumo</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
            <CardContent className="p-4 text-center">
              <Calendar className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-700">{stats.needsUpdate}</p>
              <p className="text-xs text-slate-600">Precisam Atualizar</p>
            </CardContent>
          </Card>
        </div>

        {/* Admin Filters */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-checkins"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all');
                      setSelectedUser('all');
                    }}
                  />
                  <Label htmlFor="show-all-checkins" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all');
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <CheckInFilters
          filters={filters}
          onFiltersChange={setFilters}
          objectives={objectives}
        />

        <div className="grid md:grid-cols-2 gap-6">
          {getFilteredKeyResults().map((kr) => (
            <KeyResultCheckInCard
              key={kr.id}
              keyResult={kr}
              objective={getObjectiveInfo(kr.objective_id)}
              lastCheckIn={getLastCheckIn(kr.id)}
              checkIns={getKeyResultCheckIns(kr.id)}
              onCheckIn={handleCheckIn}
              showUserBadge={showAllUsers && user?.role === 'admin'}
            />
          ))}
        </div>

        {getFilteredKeyResults().length === 0 && (
          <div className="text-center py-16">
            <Calendar className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum Key Result encontrado
            </h3>
            <p className="text-slate-500">
              Crie Key Results para começar a fazer check-ins
            </p>
          </div>
        )}

        {showModal && selectedKR && (
          <CheckInModal
            keyResult={selectedKR}
            objective={getObjectiveInfo(selectedKR.objective_id)}
            lastCheckIn={getLastCheckIn(selectedKR.id)}
            onSubmit={handleSubmitCheckIn}
            onClose={() => {
              setShowModal(false);
              setSelectedKR(null);
            }}
          />
        )}
      </div>
    </div>
  );
}
