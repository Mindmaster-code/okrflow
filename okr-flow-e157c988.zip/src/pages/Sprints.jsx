
import React, { useState, useEffect } from "react";
import { Sprint, Project, Initiative, Objective, KeyResult } from "@/api/entities"; // Added Objective, KeyResult for user data isolation
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, Eye } from "lucide-react"; // Added Eye icon

import SprintForm from "../components/sprints/SprintForm";
import SprintCard from "../components/sprints/SprintCard";
import SprintFilters from "../components/sprints/SprintFilters";

// Added for Admin Filter UI
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Sprints() {
  const [sprints, setSprints] = useState([]);
  const [projects, setProjects] = useState([]);
  const [initiatives, setInitiatives] = useState([]);
  const [objectives, setObjectives] = useState([]); // Added for initiatives project validation
  const [keyResults, setKeyResults] = useState([]); // Added for initiatives project validation
  const [showForm, setShowForm] = useState(false);
  const [editingSprint, setEditingSprint] = useState(null);
  const [filters, setFilters] = useState({
    project: 'all',
    status: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // New states for admin filtering
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedUser, setSelectedUser] = useState('all');
  const [allUsers, setAllUsers] = useState([]);

  useEffect(() => {
    loadData();
  }, [showAllUsers, selectedUser]); // Re-run loadData when these change

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let projectsData;
      
      // Admin logic to fetch projects
      if (userData.role === 'admin' && showAllUsers) {
        projectsData = await Project.list('-created_date'); // Fetch all projects
        const uniqueUsers = [...new Set(projectsData.map(p => p.created_by))];
        setAllUsers(uniqueUsers);

        if (selectedUser !== 'all') {
          projectsData = projectsData.filter(p => p.created_by === selectedUser);
        }
      } else {
        // Regular user or admin not viewing all users, fetch only own projects
        projectsData = await Project.filter({ created_by: userData.email });
        setAllUsers([]); // Clear allUsers if not in admin all-user view
        setSelectedUser('all'); // Reset selected user
      }
      
      const projectIds = projectsData.map(p => p.id);
      
      // Fetch sprints belonging to the filtered projects
      const allSprints = await Sprint.list('-created_date');
      const sprintsData = allSprints.filter(spr => projectIds.includes(spr.project_id));
      
      // Fetch objectives belonging to the filtered projects
      const allObjectives = await Objective.list();
      const objectivesData = allObjectives.filter(obj => projectIds.includes(obj.project_id));
      setObjectives(objectivesData); // Set objectives state
      const objectiveIds = objectivesData.map(obj => obj.id);
      
      // Fetch key results belonging to the filtered objectives
      const allKeyResults = await KeyResult.list();
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
      setKeyResults(keyResultsData); // Set keyResults state
      const keyResultIds = keyResultsData.map(kr => kr.id);
      
      // Fetch initiatives belonging to the filtered key results
      const allInitiatives = await Initiative.list();
      const initiativesData = allInitiatives.filter(init => keyResultIds.includes(init.key_result_id));

      // Auto-update sprint status based on dates and initiatives
      const updatedSprints = await Promise.all(sprintsData.map(async (sprint) => {
        const sprintInitiatives = initiativesData.filter(i => i.sprint_id === sprint.id);
        const today = new Date();
        const endDate = new Date(sprint.end_date);
        
        let newStatus = sprint.status;
        
        if (sprintInitiatives.length > 0) {
          const allDone = sprintInitiatives.every(i => i.status === 'done');
          // If all initiatives are done OR sprint end date is past
          if (allDone || endDate < today) {
            newStatus = 'completed';
          } else if (sprint.status === 'planning') {
            // If initiatives exist and sprint is in planning, it becomes active
            newStatus = 'active';
          }
        } else if (endDate < today && sprint.status !== 'completed') {
            // If no initiatives but sprint end date is past, mark as completed
            newStatus = 'completed';
        }
        
        if (newStatus !== sprint.status) {
          await Sprint.update(sprint.id, { status: newStatus });
          return { ...sprint, status: newStatus };
        }
        
        return sprint;
      }));

      setSprints(updatedSprints);
      setProjects(projectsData);
      setInitiatives(initiativesData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (sprintData) => {
    try {
      if (editingSprint) {
        await Sprint.update(editingSprint.id, sprintData);
      } else {
        await Sprint.create(sprintData);
      }
      setShowForm(false);
      setEditingSprint(null);
      loadData();
    } catch (error) {
      console.error('Error saving sprint:', error);
    }
  };

  const handleEdit = (sprint) => {
    setEditingSprint(sprint);
    setShowForm(true);
  };

  const handleDelete = async (sprintId) => {
    if (window.confirm('Tem certeza que deseja excluir este sprint? As iniciativas associadas ficarão sem sprint.')) {
      try {
        await Sprint.delete(sprintId);
        loadData();
      } catch (error) {
        console.error('Error deleting sprint:', error);
      }
    }
  };

  const getFilteredSprints = () => {
    return sprints.filter(sprint => {
      return (filters.project === 'all' || sprint.project_id === filters.project) &&
             (filters.status === 'all' || sprint.status === filters.status);
    });
  };

  const getSprintInitiatives = (sprintId) => {
    const sprint = sprints.find(s => s.id === sprintId);
    if (!sprint) return [];
    
    // VALIDAÇÃO: Retornar APENAS iniciativas que pertencem ao mesmo projeto do sprint
    return initiatives.filter(initiative => {
      // Verificar se a iniciativa pertence a um KR/Objetivo do mesmo projeto
      const keyResult = keyResults.find(kr => kr.id === initiative.key_result_id);
      if (!keyResult) return false;
      
      const objective = objectives.find(obj => obj.id === keyResult.objective_id);
      if (!objective) return false;
      
      // Só retorna se for do mesmo projeto E estiver associada ao sprint
      return objective.project_id === sprint.project_id && initiative.sprint_id === sprintId;
    });
  };

  const getProjectName = (projectId) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : 'Projeto não encontrado';
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="h-80 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Sprints</h1>
              <p className="text-slate-600">Organize iniciativas em períodos de execução</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Sprint
          </Button>
        </div>

        {/* Admin Filter Section */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-sprints"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedUser('all'); // Reset user selection when toggling
                    }}
                  />
                  <Label htmlFor="show-all-sprints" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-indigo-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && allUsers.length > 0 && (
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger className="w-64">
                      <SelectValue placeholder="Filtrar por usuário" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os usuários</SelectItem>
                      {allUsers.map(email => (
                        <SelectItem key={email} value={email}>{email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <SprintForm
              sprint={editingSprint}
              projects={projects}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingSprint(null);
              }}
            />
          </div>
        )}

        <SprintFilters
          filters={filters}
          onFiltersChange={setFilters}
          projects={projects}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getFilteredSprints().map((sprint) => (
            <div key={sprint.id} className="relative">
              {showAllUsers && user?.role === 'admin' && (
                <Badge className="absolute -top-2 -right-2 z-10 bg-indigo-600 text-white text-xs">
                  {projects.find(p => p.id === sprint.project_id)?.created_by}
                </Badge>
              )}
              <SprintCard
                sprint={sprint}
                initiatives={getSprintInitiatives(sprint.id)}
                projectName={getProjectName(sprint.project_id)}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>

        {getFilteredSprints().length === 0 && (
          <div className="text-center py-16">
            <Calendar className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum sprint encontrado
            </h3>
            <p className="text-slate-500 mb-6">
              Crie seu primeiro sprint para organizar as iniciativas
            </p>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Criar Primeiro Sprint
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
