
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Save, TrendingUp, AlertTriangle, X as XCircle, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function CheckInModal({ keyResult, objective, lastCheckIn, onSubmit, onClose }) {
  const [formData, setFormData] = useState({
    key_result_id: keyResult.id,
    check_in_date: new Date().toISOString().split('T')[0],
    previous_value: keyResult.current_value,
    new_value: keyResult.current_value,
    status: lastCheckIn?.status || 'on_track',
    comments: '',
    blockers: '',
    confidence_level: lastCheckIn?.confidence_level || 7
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const newProgress = keyResult.target_value > 0 
    ? Math.min(100, Math.round((formData.new_value / keyResult.target_value) * 100))
    : 0;

  const progressChange = newProgress - keyResult.progress;

  const getStatusInfo = (status) => {
    switch (status) {
      case 'on_track':
        return {
          label: 'No Rumo',
          color: 'bg-green-100 text-green-700 border-green-200',
          icon: TrendingUp,
          iconColor: 'text-green-600'
        };
      case 'at_risk':
        return {
          label: 'Em Risco',
          color: 'bg-orange-100 text-orange-700 border-orange-200',
          icon: AlertTriangle,
          iconColor: 'text-orange-600'
        };
      case 'off_track':
        return {
          label: 'Fora do Rumo',
          color: 'bg-red-100 text-red-700 border-red-200',
          icon: XCircle,
          iconColor: 'text-red-600'
        };
      default:
        return {
          label: 'Desconhecido',
          color: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: Target,
          iconColor: 'text-slate-600'
        };
    }
  };

  const statusInfo = getStatusInfo(formData.status);
  const StatusIcon = statusInfo.icon;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-slate-900">
            Check-in de Progresso
          </DialogTitle>
          <div className="mt-2 space-y-2">
            <div>
              <p className="text-sm text-slate-600 font-medium">Objetivo:</p>
              <p className="text-slate-900">{objective?.title}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">Key Result:</p>
              <p className="text-slate-900">{keyResult.title}</p>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <p className="text-sm font-semibold text-blue-900 mb-1">Meta do KR:</p>
              <p className="text-2xl font-bold text-blue-700">
                {keyResult.target_value} {keyResult.unit}
              </p>
              <p className="text-xs text-blue-600 mt-1">
                Valor atual: {keyResult.current_value} {keyResult.unit}
              </p>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="check_in_date" className="text-sm font-semibold text-slate-700">
              Data do Check-in
            </Label>
            <Input
              id="check_in_date"
              type="date"
              value={formData.check_in_date}
              onChange={(e) => setFormData({ ...formData, check_in_date: e.target.value })}
              required
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Valor Anterior
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  step="0.01"
                  value={formData.previous_value}
                  disabled
                  className="bg-slate-50 pr-20"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-slate-500 font-medium">
                  {keyResult.unit}
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="new_value" className="text-sm font-semibold text-slate-700">
                Novo Valor Atual *
              </Label>
              <div className="relative">
                <Input
                  id="new_value"
                  type="number"
                  step="0.01"
                  value={formData.new_value}
                  onChange={(e) => setFormData({ ...formData, new_value: parseFloat(e.target.value) })}
                  required
                  className="border-slate-200 focus:border-blue-500 pr-20"
                  placeholder={`Ex: ${keyResult.current_value + 10}`}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-blue-600">
                  {keyResult.unit}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Faltam <strong className="text-slate-700">{Math.max(0, keyResult.target_value - formData.new_value).toFixed(2)} {keyResult.unit}</strong> para atingir a meta
              </p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-slate-700">Progresso:</span>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <span className="text-lg text-slate-500">{keyResult.progress}%</span>
                  <span className="mx-2 text-slate-400">→</span>
                  <span className="text-2xl font-bold text-blue-600">{newProgress}%</span>
                </div>
                {progressChange !== 0 && (
                  <Badge className={progressChange > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                    {progressChange > 0 ? '+' : ''}{progressChange}%
                  </Badge>
                )}
              </div>
            </div>
            <Progress value={newProgress} className="h-3" indicatorClassName="bg-blue-500" />
            
            <div className="flex justify-between text-sm text-slate-600 pt-2 border-t border-slate-200">
              <span className="font-semibold">{formData.new_value} {keyResult.unit}</span>
              <span>Meta: <strong className="text-slate-900">{keyResult.target_value} {keyResult.unit}</strong></span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <StatusIcon className={`w-4 h-4 ${statusInfo.iconColor}`} />
              Status de Saúde *
            </Label>
            <Select 
              value={formData.status} 
              onValueChange={(value) => setFormData({ ...formData, status: value })}
            >
              <SelectTrigger className="border-slate-200 focus:border-blue-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="on_track">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    <span>No Rumo - Progredindo conforme esperado</span>
                  </div>
                </SelectItem>
                <SelectItem value="at_risk">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-orange-600" />
                    <span>Em Risco - Requer atenção</span>
                  </div>
                </SelectItem>
                <SelectItem value="off_track">
                  <div className="flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-red-600" />
                    <span>Fora do Rumo - Muito atrasado</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confidence_level" className="text-sm font-semibold text-slate-700">
              Nível de Confiança (1-10)
            </Label>
            <div className="flex items-center gap-4">
              <Input
                id="confidence_level"
                type="range"
                min="1"
                max="10"
                value={formData.confidence_level}
                onChange={(e) => setFormData({ ...formData, confidence_level: parseInt(e.target.value) })}
                className="flex-1"
              />
              <span className="text-2xl font-bold text-slate-900 w-12 text-center">
                {formData.confidence_level}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Quão confiante você está em atingir a meta no prazo?
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="comments" className="text-sm font-semibold text-slate-700">
              Comentários sobre o Progresso
            </Label>
            <Textarea
              id="comments"
              value={formData.comments}
              onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
              placeholder="O que foi feito? Quais foram os resultados? O que vem a seguir?"
              rows={4}
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="blockers" className="text-sm font-semibold text-slate-700">
              Bloqueios ou Impedimentos
            </Label>
            <Textarea
              id="blockers"
              value={formData.blockers}
              onChange={(e) => setFormData({ ...formData, blockers: e.target.value })}
              placeholder="Há algo impedindo o progresso? Precisa de ajuda?"
              rows={3}
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
              <Save className="w-4 h-4 mr-2" />
              Salvar Check-in
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
