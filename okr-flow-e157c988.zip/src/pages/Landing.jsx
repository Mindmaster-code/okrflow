import React from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-white mb-6">OKR Flow</h1>
          <p className="text-2xl text-slate-300 mb-8">Gestão de OKRs com Inteligência Artificial</p>
          <button
            onClick={() => base44.auth.redirectToLogin(createPageUrl("Dashboard"))}
            className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-lg text-lg"
          >
            Começar Gratuitamente
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-3">IA Completa</h3>
            <p className="text-slate-300">Crie OKRs profissionais em segundos</p>
          </div>
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-3">Metodologia Pro</h3>
            <p className="text-slate-300">Projetos → Objetivos → KRs → Iniciativas</p>
          </div>
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-3">Relatórios</h3>
            <p className="text-slate-300">Dashboard completo e exportação PDF</p>
          </div>
        </div>
      </div>
    </div>
  );
}