import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function DebugData() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const user = await base44.auth.me();
      
      // Carregar TUDO que o usuário tem acesso
      let initiatives = [];
      try {
        initiatives = await base44.entities.Initiative.list();
      } catch (e) {
        console.log("Sem initiatives ou entidade não existe");
      }
      
      const projects = await base44.entities.Project.list();
      const objectives = await base44.entities.Objective.list();
      const keyResults = await base44.entities.KeyResult.list();
      const users = await base44.entities.User.list();

      setData({
        initiatives,
        projects,
        objectives,
        keyResults,
        users,
        currentUser: user
      });
    } catch (error) {
      alert("Erro: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">🔍 Debug de Dados</h1>
        
        <Button onClick={loadAllData} disabled={loading} className="mb-6">
          {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
          Carregar Todos os Dados
        </Button>

        {data && (
          <div className="space-y-6">
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <p className="font-semibold">Usuário Atual: {data.currentUser.email}</p>
                <p className="text-sm text-slate-600">Empresa: {data.currentUser.company || "Sem empresa"}</p>
                <p className="text-sm text-slate-600">Role: {data.currentUser.role}</p>
              </CardContent>
            </Card>

            {/* INITIATIVES */}
            <Card>
              <CardHeader>
                <CardTitle>Initiatives (antigas) - {data.initiatives.length}</CardTitle>
              </CardHeader>
              <CardContent>
                {data.initiatives.length === 0 ? (
                  <p className="text-slate-500">Nenhuma initiative encontrada</p>
                ) : (
                  <div className="space-y-2">
                    {data.initiatives.slice(0, 10).map(init => (
                      <div key={init.id} className="p-3 bg-slate-50 rounded border text-sm">
                        <div className="flex justify-between">
                          <span className="font-semibold">{init.title || "❌ SEM TÍTULO"}</span>
                          <Badge variant="outline">{init.created_by}</Badge>
                        </div>
                        <div className="text-xs text-slate-600 mt-1">
                          {init.start_date} → {init.end_date} | Status: {init.status}
                        </div>
                      </div>
                    ))}
                    {data.initiatives.length > 10 && (
                      <p className="text-xs text-slate-500">... e mais {data.initiatives.length - 10}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* PROJECTS */}
            <Card>
              <CardHeader>
                <CardTitle>Projects (atuais) - {data.projects.length}</CardTitle>
              </CardHeader>
              <CardContent>
                {data.projects.length === 0 ? (
                  <p className="text-slate-500">Nenhum projeto encontrado</p>
                ) : (
                  <div className="space-y-2">
                    {data.projects.slice(0, 10).map(proj => (
                      <div key={proj.id} className="p-3 bg-blue-50 rounded border border-blue-200 text-sm">
                        <div className="flex justify-between">
                          <span className="font-semibold">{proj.title || "❌ SEM TÍTULO"}</span>
                          <Badge>{proj.created_by}</Badge>
                        </div>
                        <div className="text-xs text-slate-600 mt-1">
                          KR ID: {proj.key_result_id || "❌ SEM KR"} | {proj.start_date} → {proj.end_date}
                        </div>
                      </div>
                    ))}
                    {data.projects.length > 10 && (
                      <p className="text-xs text-slate-500">... e mais {data.projects.length - 10}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* OBJECTIVES */}
            <Card>
              <CardHeader>
                <CardTitle>Objetivos - {data.objectives.length}</CardTitle>
              </CardHeader>
              <CardContent>
                {data.objectives.map(obj => (
                  <div key={obj.id} className="p-2 bg-purple-50 rounded mb-2 text-sm">
                    <span className="font-semibold">{obj.title}</span> - <Badge variant="outline">{obj.created_by}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* KEY RESULTS */}
            <Card>
              <CardHeader>
                <CardTitle>Key Results - {data.keyResults.length}</CardTitle>
              </CardHeader>
              <CardContent>
                {data.keyResults.map(kr => (
                  <div key={kr.id} className="p-2 bg-green-50 rounded mb-2 text-sm">
                    <span className="font-semibold">{kr.title}</span> - Obj ID: {kr.objective_id}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* USERS */}
            <Card>
              <CardHeader>
                <CardTitle>Usuários - {data.users.length}</CardTitle>
              </CardHeader>
              <CardContent>
                {data.users.map(u => (
                  <div key={u.id} className="p-2 bg-slate-100 rounded mb-2 text-sm">
                    <span className="font-semibold">{u.email}</span> - {u.company || "Sem empresa"}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}