
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, Target, Zap, Pencil, Trash2, Key } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function InitiativeCard({ 
  initiative, 
  objectiveTitle,
  keyResultTitle,
  sprintName, 
  onEdit, 
  onDelete, 
  isDragging 
}) {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityLabel = (priority) => {
    switch (priority) {
      case 'critical': return 'Crítica';
      case 'high': return 'Alta';
      case 'medium': return 'Média';
      case 'low': return 'Baixa';
      default: return 'Média';
    }
  };

  const isOverdue = () => {
    const today = new Date();
    const endDate = new Date(initiative.end_date);
    return endDate < today && initiative.status !== 'done';
  };

  return (
    <Card className={`bg-white shadow-md hover:shadow-lg transition-all duration-200 border-0 ${
      isDragging ? 'shadow-2xl ring-2 ring-blue-400' : ''
    } ${isOverdue() ? 'ring-1 ring-red-300' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="font-semibold text-slate-900 text-sm leading-tight mb-2">
              {initiative.title}
            </h3>
            <p className="text-xs text-slate-600 line-clamp-2">
              {initiative.description}
            </p>
          </div>
          <Badge className={`${getPriorityColor(initiative.priority)} ml-2 text-xs`}>
            {getPriorityLabel(initiative.priority)}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Target className="w-3 h-3 text-slate-400" />
            <span className="truncate">{objectiveTitle}</span>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Key className="w-3 h-3 text-slate-400" />
            <span className="truncate font-medium">{keyResultTitle}</span>
          </div>

          {initiative.sprint_id && (
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Zap className="w-3 h-3 text-slate-400" />
              <span className="truncate">{sprintName}</span>
            </div>
          )}
          
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <User className="w-3 h-3 text-slate-400" />
            <span className="truncate">{initiative.responsible}</span>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Calendar className="w-3 h-3 text-slate-400" />
            <span className={isOverdue() ? 'text-red-600 font-medium' : ''}>
              {format(new Date(initiative.start_date), "dd/MM", { locale: ptBR })} - 
              {format(new Date(initiative.end_date), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
        </div>

        {isOverdue() && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-2">
            <p className="text-xs text-red-700 font-medium">⚠️ Atrasada</p>
          </div>
        )}

        <div className="flex justify-end gap-1 pt-2 border-t border-slate-100">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(initiative);
            }}
            className="h-8 w-8 p-0 hover:bg-blue-50 hover:text-blue-600"
          >
            <Pencil className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(initiative.id);
            }}
            className="h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
