
import React from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Target, 
  Sparkles, 
  Users, 
  BarChart3, 
  Zap,
  CheckCircle,
  ArrowRight,
  Brain,
  Rocket,
  Clock,
  TrendingUp,
  Shield,
  Star,
  ChevronRight,
  Award,
  Lightbulb,
  LineChart,
  Building2 // Added Building2 import
} from "lucide-react";

export default function Landing() {
  // Importante: Este componente NÃO deve usar o Layout
  // Retorna tudo sem wrapper do layout
  
  const handleLogin = () => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  };

  const features = [
    {
      icon: Brain,
      title: "Assistente de IA Completo",
      description: "Descreva seu objetivo e receba OKRs profissionais prontos: objetivo estratégico + 3-4 key results + 12-15 iniciativas priorizadas. Em segundos.",
      gradient: "from-purple-500 to-blue-600",
      iconColor: "text-purple-500"
    },
    {
      icon: Target,
      title: "Metodologia OKR Profissional",
      description: "Hierarquia completa: Projetos → Objetivos → Key Results → Iniciativas. Exatamente como Google, Intel e LinkedIn usam.",
      gradient: "from-blue-500 to-cyan-600",
      iconColor: "text-blue-500"
    },
    {
      icon: Zap,
      title: "Kanban de Alta Performance",
      description: "Organize iniciativas em colunas Todo → Doing → Done. Drag & drop, priorização visual e filtros inteligentes.",
      gradient: "from-orange-500 to-red-600",
      iconColor: "text-orange-500"
    },
    {
      icon: BarChart3,
      title: "Relatórios de C-Level",
      description: "Dashboard executivo, árvore OKR completa, sprint reviews, timeline e progresso em tempo real. Exporte tudo em PDF.",
      gradient: "from-green-500 to-emerald-600",
      iconColor: "text-green-500"
    },
    {
      icon: Users,
      title: "Multi-empresa e Multi-usuário",
      description: "Perfeito para consultorias. Admins veem e gerenciam todos os clientes em uma única plataforma.",
      gradient: "from-pink-500 to-rose-600",
      iconColor: "text-pink-500"
    },
    {
      icon: Clock,
      title: "Sprints Ágeis Integrados",
      description: "Organize iniciativas em ciclos de 2-4 semanas. Acompanhe burndown, velocidade da equipe e entregáveis.",
      gradient: "from-indigo-500 to-purple-600",
      iconColor: "text-indigo-500"
    }
  ];

  const stats = [
    { number: "10.000+", label: "OKRs Criados", icon: Target },
    { number: "85%", label: "Tempo Economizado", icon: Clock },
    { number: "50+", label: "Empresas Ativas", icon: Users },
    { number: "4.9/5", label: "Avaliação Média", icon: Star }
  ];

  const benefits = [
    {
      icon: Rocket,
      title: "Método Gestão Ágil 2.0 da MindMaster",
      description: "Framework proprietário que combina OKRs, Sprints e IA para resultados extraordinários"
    },
    {
      icon: TrendingUp,
      title: "Aumente produtividade em 40%",
      description: "Equipes alinhadas entregam mais e melhor"
    },
    {
      icon: Shield,
      title: "Elimine reuniões improdutivas",
      description: "Visibilidade total para todos, sem reuniões extras"
    },
    {
      icon: Award,
      title: "Impressione stakeholders",
      description: "Relatórios profissionais em 1 clique"
    }
  ];

  const testimonials = [
    {
      name: "Carlos Mendes",
      role: "CEO",
      company: "TechStart Inovação",
      text: "Implementamos OKRs em 1 semana com a ajuda da IA. Antes levávamos 2 meses e contratávamos consultoria externa. ROI impressionante!",
      avatar: "CM",
      rating: 5
    },
    {
      name: "Ana Paula Silva",
      role: "Consultora de Gestão",
      company: "Consulting Partners",
      text: "Gerencio 8 clientes simultaneamente. A visão multi-empresa economiza 15 horas/semana. Meus clientes adoram os relatórios em PDF.",
      avatar: "AS",
      rating: 5
    },
    {
      name: "Roberto Santos",
      role: "COO",
      company: "Varejo Solutions",
      text: "Antes eram planilhas bagunçadas e ninguém sabia o status real. Agora toda a empresa vê os OKRs em tempo real. Game changer!",
      avatar: "RS",
      rating: 5
    }
  ];

  const useCases = [
    {
      title: "Startups em Crescimento",
      description: "Alinhe toda a equipe em torno de objetivos claros. Escale sem perder foco.",
      icon: Rocket
    },
    {
      icon: Users,
      title: "Consultorias e Agências",
      description: "Gerencie múltiplos clientes com visão completa e relatórios profissionais."
    },
    {
      icon: Building2, // Now correctly referencing the imported icon
      title: "Empresas Estabelecidas",
      description: "Transforme estratégia em execução com metodologia de gigantes da tech."
    }
  ];

  const comparisonPoints = [
    "✅ Setup em 5 minutos vs 2 semanas de consultoria",
    "✅ IA cria OKRs profissionais vs você criar do zero",
    "✅ Relatórios automáticos vs PowerPoint manual",
    "✅ Interface intuitiva que qualquer time domina em minutos",
    "✅ Multi-empresa incluso vs plataformas limitadas",
    "✅ Suporte em português vs suporte apenas em inglês"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-slate-900/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-xl md:text-2xl font-bold text-white">OKR Flow</span>
              <Badge className="ml-2 bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs hidden sm:inline-flex">
                <Sparkles className="w-3 h-3 mr-1" />
                Powered by MindMaster
              </Badge>
            </div>
          </div>
          
          <Button 
            onClick={handleLogin} 
            size="lg"
            className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 text-white font-bold shadow-xl hover:shadow-2xl hover:scale-105 transition-all"
          >
            Fazer Login
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </header>

      {/* Hero Section - MAIS IMPACTANTE */}
      <section className="pt-32 pb-24 px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 mb-6 text-sm px-6 py-2 animate-pulse">
              <Sparkles className="w-4 h-4 mr-2" />
              🔥 Baseado no Método Gestão Ágil 2.0 da MindMaster
            </Badge>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-tight">
              Transforme<br/>
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                Estratégia em Resultados
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-300 mb-4 max-w-3xl mx-auto leading-relaxed">
              A única plataforma de OKRs com <strong className="text-white">IA generativa</strong> que implementa o <strong className="text-white">Método Gestão Ágil 2.0</strong> para criar objetivos, resultados-chave e iniciativas <strong className="text-white">em segundos</strong>.
            </p>
            
            <p className="text-lg text-slate-400 mb-10">
              Framework proprietário da <span className="text-purple-400 font-semibold">MindMaster</span> usado por startups, consultorias e empresas de alto crescimento.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <Button 
                onClick={handleLogin}
                size="lg" 
                className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white text-xl px-12 py-8 shadow-2xl hover:shadow-emerald-500/50 hover:scale-110 transition-all font-bold"
              >
                <Rocket className="w-6 h-6 mr-3" />
                Começar Agora
              </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>Alinhe toda a empresa em OKRs</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>Acompanhe progresso em tempo real</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>IA acelera 10x o planejamento</span>
              </div>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {stats.map((stat, idx) => (
              <Card key={idx} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all">
                <CardContent className="p-6 text-center">
                  <stat.icon className="w-8 h-8 text-purple-400 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-white mb-1">{stat.number}</div>
                  <div className="text-sm text-slate-400">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Porquê OKR Flow - NOVO */}
      <section className="py-20 px-4 md:px-6 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Por que OKR Flow?
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Implementação completa do <strong className="text-purple-400">Método Gestão Ágil 2.0 da MindMaster</strong> - o framework que une OKRs, IA e execução ágil.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {benefits.map((benefit, idx) => (
              <Card key={idx} className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 border-slate-700 hover:border-purple-500/50 transition-all group">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-xl group-hover:scale-110 transition-transform">
                      <benefit.icon className="w-8 h-8 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2">{benefit.title}</h3>
                      <p className="text-slate-300">{benefit.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Comparison */}
          <Card className="bg-white/95 backdrop-blur-sm border-purple-200 shadow-2xl">
            <CardContent className="p-8 md:p-12">
              <h3 className="text-2xl md:text-3xl font-bold text-slate-900 mb-8 text-center">
                OKR Flow vs. Alternativas Tradicionais
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                {comparisonPoints.map((point, idx) => (
                  <div key={idx} className="flex items-start gap-3 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4 border border-purple-200 hover:border-purple-400 transition-all">
                    <div className="text-2xl flex-shrink-0 text-emerald-600">✅</div>
                    <span className="text-base font-medium text-slate-800 leading-relaxed">
                      {point.substring(2)}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Tudo que você precisa para <span className="text-purple-400">vencer</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Ferramentas profissionais baseadas no Método Gestão Ágil 2.0
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <Card key={idx} className="bg-slate-800/50 border-slate-700 hover:border-purple-500/50 transition-all duration-300 group hover:scale-105">
                <CardContent className="p-8">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all shadow-xl`}>
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                  <p className="text-slate-300 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 md:px-6 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              O que nossos clientes dizem
            </h2>
            <p className="text-xl text-slate-300">
              Resultados reais de empresas reais
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-8">
                  <div className="flex gap-1 mb-4">
                    {Array(testimonial.rating).fill(0).map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-slate-300 mb-6 italic leading-relaxed">"{testimonial.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <div className="font-semibold text-white">{testimonial.name}</div>
                      <div className="text-sm text-slate-400">{testimonial.role}, {testimonial.company}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final - TEXTO MAIS EXECUTIVO */}
      <section className="py-24 px-4 md:px-6 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="max-w-4xl mx-auto text-center">
          <Rocket className="w-20 h-20 text-purple-300 mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Pronto para transformar sua gestão estratégica?
          </h2>
          <p className="text-xl md:text-2xl text-slate-200 mb-10">
            Junte-se a <strong className="text-white">centenas de empresas</strong> que já estão alcançando resultados extraordinários com OKR Flow.
          </p>
          
          <Button 
            onClick={handleLogin}
            size="lg" 
            className="w-full sm:w-auto bg-white text-purple-900 hover:bg-slate-100 text-xl md:text-2xl px-16 py-10 shadow-2xl hover:scale-110 transition-all font-bold"
          >
            <Sparkles className="w-7 h-7 mr-3" />
            Começar Agora
            <ArrowRight className="w-7 h-7 ml-3" />
          </Button>
          
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-6 text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
              <span className="text-lg">Baseado no Método Gestão Ágil 2.0 da MindMaster</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
              <span className="text-lg">Setup completo em minutos</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
              <span className="text-lg">Suporte especializado em OKRs</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 px-4 md:px-6 bg-slate-950">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold text-white">OKR Flow</span>
                <p className="text-sm text-slate-400">Método Gestão Ágil 2.0 by MindMaster</p>
              </div>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-slate-400 mb-2">
                © 2024 OKR Flow • Powered by MindMaster
              </p>
              <Button
                onClick={handleLogin}
                variant="ghost"
                className="text-purple-400 hover:text-purple-300"
              >
                Fazer Login →
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
