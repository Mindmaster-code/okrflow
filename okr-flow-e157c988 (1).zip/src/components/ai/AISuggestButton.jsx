
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Card } from "@/components/ui/card";

export default function AISuggestButton({ 
  type, 
  context, 
  onSuggestionSelect,
  variant = "outline",
  size = "sm",
  className = ""
}) {
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState(null);
  const [error, setError] = useState(null);
  const [open, setOpen] = useState(false);

  const generateSuggestions = async () => {
    setLoading(true);
    setError(null);

    try {
      let prompt = "";
      let schema = {};

      switch (type) {
        case "objectives":
        case "objective_title":
          prompt = `Você é um consultor especializado em OKRs.

CONTEXTO:
Departamento: ${context.department || 'Não informado'}
Trimestre: ${context.quarter || 'Q1'} ${context.year || new Date().getFullYear()}

TAREFA:
Sugira 3 títulos profissionais e inspiradores para objetivos (Objectives) seguindo a metodologia OKR.

DIRETRIZES:
- Devem ser qualitativos e aspiracionais
- Entre 50-100 caracteres
- Claros e mensuráveis indiretamente
- Alinhados com estratégia empresarial

Exemplo: "Estabelecer liderança de mercado no segmento premium"`;

          schema = {
            type: "object",
            properties: {
              suggestions: {
                type: "array",
                items: { 
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" }
                  }
                },
                minItems: 3,
                maxItems: 3
              }
            }
          };
          break;

        case "objective_description":
          prompt = `Você é um consultor especializado em OKRs.

CONTEXTO:
Título do Objetivo: ${context.objective_title || 'Não informado'}

TAREFA:
Crie uma descrição profissional e detalhada para este objetivo seguindo a metodologia OKR.

DIRETRIZES:
- Explicar o "porquê" do objetivo
- Contexto e importância estratégica
- Impacto esperado no negócio
- Entre 100-300 caracteres
- Tom formal e profissional`;

          schema = {
            type: "object",
            properties: {
              description: { type: "string" }
            }
          };
          break;

        case "key_results":
          prompt = `Você é um consultor especializado em OKRs.

CONTEXTO:
Objetivo: ${context.objective_title || 'Não informado'}
Descrição: ${context.objective_description || 'Não informado'}
Trimestre: ${context.quarter || 'Q1'} ${context.year || new Date().getFullYear()}

TAREFA:
Sugira 3-4 Key Results (Resultados-Chave) mensuráveis para este objetivo.

DIRETRIZES:
- Cada KR deve ser QUANTIFICÁVEL
- Incluir valor baseline (atual) e target (meta)
- Unidade de medida clara (%, R$, quantidade, pontos, etc)
- Desafiador mas alcançável
- Específico e sem ambiguidade

Formato esperado:
- Título: "Aumentar taxa de conversão de 2% para 3.5%"
- Target: 3.5
- Current: 2
- Unit: "%"`;

          schema = {
            type: "object",
            properties: {
              key_results: {
                type: "array",
                minItems: 3,
                maxItems: 4,
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    target_value: { type: "number" },
                    current_value: { type: "number" },
                    unit: { type: "string" }
                  }
                }
              }
            }
          };
          break;

        case "projects":
        case "initiatives":
          prompt = `Você é um consultor especializado em OKRs.

CONTEXTO:
Key Result: ${context.key_result_title || 'Não informado'}
Objetivo: ${context.objective_title || 'Não informado'}
Descrição do KR: ${context.key_result_description || 'Não informado'}

TAREFA:
Sugira 3-5 projetos/iniciativas concretas e executáveis para atingir este Key Result.

DIRETRIZES:
- Ações específicas e práticas
- Priorizadas (low, medium, high, critical)
- Descrição objetiva de cada iniciativa
- Foco em resultados mensuráveis
- Viáveis de executar em um trimestre`;

          schema = {
            type: "object",
            properties: {
              initiatives: {
                type: "array",
                minItems: 3,
                maxItems: 5,
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    priority: { 
                      type: "string",
                      enum: ["low", "medium", "high", "critical"]
                    },
                    responsible: { type: "string" }
                  }
                }
              }
            }
          };
          break;

        default:
          throw new Error("Tipo de sugestão não suportado: " + type);
      }

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: schema
      });

      setSuggestions(result);
      setOpen(true);
    } catch (err) {
      console.error("Error generating suggestions:", err);
      setError("Erro ao gerar sugestões. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (suggestion) => {
    onSuggestionSelect(suggestion);
    setOpen(false);
    setSuggestions(null);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant={variant}
          size={size}
          onClick={generateSuggestions}
          disabled={loading}
          className={className}
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Gerando...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Sugerir com IA
            </>
          )}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-96 p-0" align="start">
        {error ? (
          <div className="p-4 bg-red-50 text-red-800 text-sm">
            {error}
          </div>
        ) : suggestions ? (
          <div className="max-h-96 overflow-y-auto">
            <div className="p-4 border-b bg-gradient-to-r from-purple-50 to-blue-50">
              <h4 className="font-semibold text-sm text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Sugestões da IA
              </h4>
              <p className="text-xs text-slate-600 mt-1">
                Clique em uma sugestão para usar
              </p>
            </div>
            
            <div className="p-2 space-y-1">
              {/* Objectives */}
              {(type === "objectives" || type === "objective_title") && suggestions.suggestions?.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSelect(suggestion)}
                  className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200"
                >
                  <p className="text-sm font-medium text-slate-900">{suggestion.title}</p>
                  {suggestion.description && (
                    <p className="text-xs text-slate-600 mt-1">{suggestion.description}</p>
                  )}
                </button>
              ))}

              {/* Objective Description */}
              {type === "objective_description" && (
                <button
                  onClick={() => handleSelect(suggestions.description)}
                  className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200"
                >
                  <p className="text-sm text-slate-700">{suggestions.description}</p>
                </button>
              )}

              {/* Key Results */}
              {type === "key_results" && suggestions.key_results?.map((kr, index) => (
                <button
                  key={index}
                  onClick={() => handleSelect(kr)}
                  className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200"
                >
                  <p className="text-sm font-medium text-slate-900 mb-1">{kr.title}</p>
                  <p className="text-xs text-slate-600 mb-2">{kr.description}</p>
                  <div className="flex gap-2 text-xs">
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded">
                      Meta: {kr.target_value} {kr.unit}
                    </span>
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                      Atual: {kr.current_value} {kr.unit}
                    </span>
                  </div>
                </button>
              ))}

              {/* Projects/Initiatives */}
              {(type === "projects" || type === "initiatives") && suggestions.initiatives?.map((init, index) => (
                <button
                  key={index}
                  onClick={() => handleSelect(init)}
                  className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200"
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-medium text-slate-900">{init.title}</p>
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      init.priority === 'critical' ? 'bg-red-100 text-red-700' :
                      init.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      init.priority === 'medium' ? 'bg-blue-100 text-blue-700' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {init.priority === 'critical' ? 'Crítica' :
                       init.priority === 'high' ? 'Alta' :
                       init.priority === 'medium' ? 'Média' : 'Baixa'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">{init.description}</p>
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </PopoverContent>
    </Popover>
  );
}
