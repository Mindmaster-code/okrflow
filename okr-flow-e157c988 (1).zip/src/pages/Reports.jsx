
import React, { useState, useEffect, useCallback } from "react";
import { Objective, KeyResult, Project, Sprint, CheckIn } from "@/api/entities";
import { User } from "@/api/entities";
import { BarChart3, Loader2, Target, TrendingUp, Eye, Building2, ThermometerSun } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getYear, getQuarter, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

import ExecutiveDashboard from "../components/reports/ExecutiveDashboard";
import OKRTreeView from "../components/reports/OKRTreeView";
import HealthScoreDashboard from "../components/reports/HealthScoreDashboard";

export default function ReportsPage() {
  const [data, setData] = useState({
    objectives: [],
    keyResults: [],
    projects: [],
    sprints: [],
    checkIns: []
  });
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState("executive");
  const [filters, setFilters] = useState({
    year: getYear(new Date()).toString(),
    quarter: `Q${getQuarter(new Date())}`,
    objective: "all",
  });

  const [user, setUser] = useState(null);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  const availableYears = [
    ...new Set(data.objectives.map((o) => o.year.toString())),
  ].sort((a, b) => b - a);
  const availableQuarters = ["Q1", "Q2", "Q3", "Q4"];

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        let currentUser = user;
        if (!currentUser) {
          currentUser = await User.me();
          setUser(currentUser);
        }

        let objectivesData = [];

        if (currentUser?.role === 'admin' && showAllUsers) {
          objectivesData = await Objective.list('-created_date');

          const allUsersData = await User.list();

          const companyMap = {};
          allUsersData.forEach(u => {
            companyMap[u.email] = u.company || 'Sem empresa';
          });
          setUserCompanyMap(companyMap);

          const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
          setAllCompanies(uniqueCompanies);

          let filteredObjectivesByCompany = objectivesData;
          let usersToDisplayInFilter = [...new Set(objectivesData.map(o => o.created_by))].filter(Boolean);

          if (selectedCompany !== 'all') {
            const usersInSelectedCompany = allUsersData
              .filter(u => (u.company || 'Sem empresa') === selectedCompany)
              .map(u => u.email);

            filteredObjectivesByCompany = objectivesData.filter(o =>
              usersInSelectedCompany.includes(o.created_by)
            );
            usersToDisplayInFilter = usersInSelectedCompany.filter(u => filteredObjectivesByCompany.some(o => o.created_by === u));
          }

          setAllUsers(usersToDisplayInFilter);

          if (selectedUser !== 'all') {
            objectivesData = filteredObjectivesByCompany.filter(o => o.created_by === selectedUser);
          } else {
            objectivesData = filteredObjectivesByCompany;
          }

        } else {
          objectivesData = await Objective.filter({ created_by: currentUser?.email });
          setAllUsers([]);
          setAllCompanies([]);
          setSelectedCompany('all');
          setSelectedUser('all');
          setUserCompanyMap({});
        }

        const objectiveIds = objectivesData.map(o => o.id);

        const allKeyResults = await KeyResult.list();
        const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        const keyResultIds = keyResultsData.map(kr => kr.id);

        const allProjects = await Project.list();
        const projectsData = allProjects.filter(proj => keyResultIds.includes(proj.key_result_id));

        const allSprints = await Sprint.list();
        const sprintsData = allSprints.filter(spr => {
          if (currentUser?.role === 'admin' && showAllUsers) {
            const userEmails = objectivesData.map(o => o.created_by);
            return userEmails.includes(spr.created_by);
          }
          return spr.created_by === currentUser?.email;
        });

        const allCheckIns = await CheckIn.list('-check_in_date');
        const checkInsData = allCheckIns.filter(ci => keyResultIds.includes(ci.key_result_id));

        setData({
          objectives: objectivesData,
          keyResults: keyResultsData,
          projects: projectsData,
          sprints: sprintsData,
          checkIns: checkInsData
        });
      } catch (error) {
        console.error("Error loading report data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [user, showAllUsers, selectedCompany, selectedUser]);

  const getHeatmapColor = (progress) => {
    if (progress < 0) return 'bg-slate-100 text-slate-400';
    if (progress < 40) return 'bg-red-100 text-red-700';
    if (progress < 70) return 'bg-yellow-100 text-yellow-700';
    return 'bg-green-100 text-green-700';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full p-8">
        <Loader2 className="w-12 h-12 text-slate-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col gap-4 mb-6">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <div>
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-slate-900">Relatórios Executivos</h1>
                <p className="text-sm md:text-base text-slate-600">Analytics e insights estratégicos</p>
            </div>
          </div>
        </div>

        {/* Filtros de Admin - SEMPRE VISÍVEL */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-reports"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all');
                      setSelectedUser('all');
                    }}
                  />
                  <Label htmlFor="show-all-reports" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-cyan-600" />
                    <span className="font-medium">Ver dados de todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select
                        value={selectedCompany}
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all');
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={selectedReport} onValueChange={setSelectedReport} className="space-y-4 md:space-y-6">
          <TabsList className="grid w-full grid-cols-3 gap-1 bg-white/80 backdrop-blur-sm shadow-lg h-auto p-1">
            <TabsTrigger value="health" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <ThermometerSun className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Health Score</span>
            </TabsTrigger>
            <TabsTrigger value="executive" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="tree" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <Target className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Árvore OKR</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="health">
            <div className="space-y-4 md:space-y-6">
              <div className="flex flex-col sm:flex-row gap-2">
                <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
                  <SelectTrigger className="w-full sm:w-32 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableQuarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
                  <SelectTrigger className="w-full sm:w-28 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableYears.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.objective} onValueChange={(val) => setFilters(f => ({ ...f, objective: val }))}>
                  <SelectTrigger className="w-full sm:w-48 bg-white/80">
                    <SelectValue placeholder="Todos os Objetivos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Objetivos</SelectItem>
                    {data.objectives.map(o => (
                      <SelectItem key={o.id} value={o.id}>{o.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <HealthScoreDashboard
                objectives={data.objectives}
                keyResults={data.keyResults}
                checkIns={data.checkIns}
                filters={filters}
              />
            </div>
          </TabsContent>

          <TabsContent value="executive">
            <div className="space-y-4 md:space-y-6">
              <div className="flex flex-col sm:flex-row gap-2">
                <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
                  <SelectTrigger className="w-full sm:w-32 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableQuarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
                  <SelectTrigger className="w-full sm:w-28 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableYears.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.objective} onValueChange={(val) => setFilters(f => ({ ...f, objective: val }))}>
                  <SelectTrigger className="w-full sm:w-48 bg-white/80">
                    <SelectValue placeholder="Todos os Objetivos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Objetivos</SelectItem>
                    {data.objectives.map(o => (
                      <SelectItem key={o.id} value={o.id}>{o.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <ExecutiveDashboard
                objectives={data.objectives}
                keyResults={data.keyResults}
                projects={data.projects}
                sprints={data.sprints}
                filters={filters}
                setFilters={setFilters}
                setSelectedReport={setSelectedReport}
              />
            </div>
          </TabsContent>

          <TabsContent value="tree">
            <div className="space-y-4 md:space-y-6">
              {/* The admin filter card is now global, so removed from here */}

              <div className="flex flex-col sm:flex-row gap-2">
                <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
                  <SelectTrigger className="w-full sm:w-32 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableQuarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
                  <SelectTrigger className="w-full sm:w-28 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableYears.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.objective} onValueChange={(val) => setFilters(f => ({ ...f, objective: val }))}>
                  <SelectTrigger className="w-full sm:w-48 bg-white/80">
                    <SelectValue placeholder="Todos os Objetivos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Objetivos</SelectItem>
                    {data.objectives.map(o => (
                      <SelectItem key={o.id} value={o.id}>{o.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <OKRTreeView
                objectives={(() => {
                  let filtered = data.objectives.filter(o =>
                    o.year.toString() === filters.year && o.quarter === filters.quarter
                  );
                  if (filters.objective && filters.objective !== 'all') {
                    filtered = filtered.filter(o => o.id === filters.objective);
                  }
                  return filtered;
                })()}
                keyResults={data.keyResults}
              />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
