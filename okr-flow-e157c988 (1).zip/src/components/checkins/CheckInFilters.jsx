import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Filter, AlertTriangle } from "lucide-react";

export default function CheckInFilters({ filters, onFiltersChange, objectives }) {
  const handleFilterChange = (key, value) => {
    onFiltersChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
      <CardContent className="p-4">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <span className="text-sm font-medium text-slate-700">Filtros:</span>
          </div>

          <Select 
            value={filters.objective} 
            onValueChange={(value) => handleFilterChange('objective', value)}
          >
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Todos os objetivos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os objetivos</SelectItem>
              {objectives.map((objective) => (
                <SelectItem key={objective.id} value={objective.id}>
                  {objective.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select 
            value={filters.status} 
            onValueChange={(value) => handleFilterChange('status', value)}
          >
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Todos os status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="on_track">No Rumo</SelectItem>
              <SelectItem value="at_risk">Em Risco</SelectItem>
              <SelectItem value="off_track">Fora do Rumo</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-2">
            <Switch
              id="needs-update"
              checked={filters.needsUpdate}
              onCheckedChange={(checked) => handleFilterChange('needsUpdate', checked)}
            />
            <Label htmlFor="needs-update" className="flex items-center gap-1 cursor-pointer text-sm">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
              Apenas KRs que precisam atualizar
            </Label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}