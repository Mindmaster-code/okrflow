import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertCircle, CheckCircle, Database } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function MigrateData() {
  const [migrating, setMigrating] = useState(false);
  const [results, setResults] = useState(null);

  const runMigration = async () => {
    if (!window.confirm('Isso vai migrar TODAS as initiatives antigas de TODOS os usuários. Continuar?')) {
      return;
    }

    setMigrating(true);
    setResults(null);

    try {
      const { data } = await base44.functions.invoke('migrateInitiatives');
      
      if (data.success) {
        setResults(data);
      } else {
        alert('Erro: ' + data.error);
      }
    } catch (error) {
      alert('Erro ao executar migração: ' + error.message);
    } finally {
      setMigrating(false);
    }
  };

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
            <Database className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Recuperar Projetos Antigos</h1>
            <p className="text-slate-600">Migração automática de initiatives para projects (TODOS os usuários)</p>
          </div>
        </div>

        <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0 mb-6">
          <CardContent className="p-6">
            <Alert className="mb-4">
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>
                Esta ferramenta vai migrar TODAS as initiatives antigas de TODOS os usuários para a nova entidade Project.
              </AlertDescription>
            </Alert>

            <Button
              onClick={runMigration}
              disabled={migrating}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 h-12"
            >
              {migrating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Migrando de todos os usuários...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Executar Migração Global
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {results && (
          <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Migração Concluída!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  ✅ <strong>{results.totalRecovered}</strong> projetos foram recuperados com sucesso!
                </AlertDescription>
              </Alert>

              {results.userResults && Object.keys(results.userResults).length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-slate-900">📊 Resultados por Usuário:</h4>
                  {Object.entries(results.userResults).map(([email, data]) => (
                    <Card key={email} className="bg-slate-50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-semibold text-slate-900">{email}</p>
                            <p className="text-sm text-slate-600">
                              ✅ {data.recovered}/{data.total} recuperados
                            </p>
                          </div>
                          {data.errors && data.errors.length > 0 && (
                            <Badge variant="outline" className="text-orange-600">
                              {data.errors.length} aviso{data.errors.length > 1 ? 's' : ''}
                            </Badge>
                          )}
                        </div>
                        {data.errors && data.errors.length > 0 && (
                          <div className="mt-3 space-y-1">
                            {data.errors.map((err, idx) => (
                              <p key={idx} className="text-xs text-orange-700">• {err}</p>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <Alert className="bg-blue-50 border-blue-200 mt-4">
                <AlertDescription className="text-blue-800">
                  👉 Volte para a página de <strong>Projetos</strong> e ative "Ver todos os usuários" para ver todos os dados recuperados!
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}