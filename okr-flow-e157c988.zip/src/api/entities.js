import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Objective = base44.entities.Objective;

export const KeyResult = base44.entities.KeyResult;

export const Initiative = base44.entities.Initiative;

export const Sprint = base44.entities.Sprint;



// auth sdk:
export const User = base44.auth;