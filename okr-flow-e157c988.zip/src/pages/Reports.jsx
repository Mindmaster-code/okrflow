
import React, { useState, useEffect, useCallback } from "react";
import { Project, Objective, KeyResult, Initiative, Sprint } from "@/api/entities";
import { User } from "@/api/entities";
import { BarChart3, Loader2, FolderOpen, Target, TrendingUp, Users, Calendar, ChevronRight, Zap, Key, Eye, Building2 } from "lucide-react"; // Add Building2
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getYear, getQuarter, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";


import SprintReviewReport from "../components/reports/SprintReviewReport";
import TimelineView from "../components/reports/TimelineView";
import ExecutiveDashboard from "../components/reports/ExecutiveDashboard";
import OKRTreeView from "../components/reports/OKRTreeView";

const KpiCard = ({ title, value, description, icon: Icon, color }) => (
  <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
    <CardContent className="p-6">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${color} flex items-center justify-center`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <p className="text-sm text-slate-600 font-medium">{title}</p>
          <p className="text-3xl font-bold text-slate-900">{value}</p>
          <p className="text-xs text-slate-500 mt-1">{description}</p>
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function ReportsPage() {
  const [data, setData] = useState({
    projects: [],
    objectives: [],
    keyResults: [],
    initiatives: [],
    sprints: [],
  });
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState("executive");
  const [filters, setFilters] = useState({
    year: getYear(new Date()).toString(),
    quarter: `Q${getQuarter(new Date())}`,
    project: "all",
  });

  // New states for admin filter
  const [user, setUser] = useState(null);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all'); // New state
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]); // New state
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({}); // New state

  const availableYears = [
    ...new Set(data.objectives.map((o) => o.year.toString())),
  ].sort((a, b) => b - a);
  const availableQuarters = ["Q1", "Q2", "Q3", "Q4"];

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        // Fetch user data if not already available in state
        let currentUser = user;
        if (!currentUser) {
          currentUser = await User.me();
          setUser(currentUser); // Set user state if it was fetched for the first time
        }

        let projectsData = [];
        
        if (currentUser?.role === 'admin' && showAllUsers) {
          // Admin viewing all users' data
          const allAvailableProjects = await Project.list('-created_date');

          // Collect unique users from all projects and fetch their company info
          const allUsersData = await User.list();
          
          const companyMap = {};
          allUsersData.forEach(u => {
            companyMap[u.email] = u.company || 'Sem empresa';
          });
          setUserCompanyMap(companyMap);
          
          const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
          setAllCompanies(uniqueCompanies);

          // Apply filter by specific company if selected
          let filteredProjectsByCompany = allAvailableProjects;
          let usersToDisplayInFilter = [...new Set(allAvailableProjects.map(p => p.created_by))].filter(Boolean); // All users from all projects initially
          
          if (selectedCompany !== 'all') {
            const usersInSelectedCompany = allUsersData
              .filter(u => (u.company || 'Sem empresa') === selectedCompany)
              .map(u => u.email);
            
            // Filter projects to only include those created by users in the selected company
            filteredProjectsByCompany = allAvailableProjects.filter(p => 
              usersInSelectedCompany.includes(p.created_by)
            );
            // Update users to display in user filter based on company selection
            usersToDisplayInFilter = usersInSelectedCompany.filter(u => filteredProjectsByCompany.some(p => p.created_by === u));
          }
          
          setAllUsers(usersToDisplayInFilter); // Set users for the user filter dropdown

          // Apply filter by specific user if selected, on top of company filter
          if (selectedUser !== 'all') {
            projectsData = filteredProjectsByCompany.filter(p => p.created_by === selectedUser);
          } else {
            projectsData = filteredProjectsByCompany;
          }

        } else {
          // Normal user or admin viewing their own data
          projectsData = await Project.filter({ created_by: currentUser?.email });
          setAllUsers([]); // Clear allUsers if not in admin all-users mode
          setAllCompanies([]); // Clear allCompanies
          setSelectedCompany('all'); // Reset selectedCompany
          setSelectedUser('all'); // Reset selectedUser to 'all' if not in admin all-users mode
          setUserCompanyMap({}); // Clear map
        }

        const projectIds = projectsData.map(p => p.id);

        // Buscar objetivos dos projetos filtrados
        const allObjectives = await Objective.list();
        const objectivesData = allObjectives.filter(obj => projectIds.includes(obj.project_id));
        const objectiveIds = objectivesData.map(obj => obj.id);

        // Buscar key results dos objetivos filtrados
        const allKeyResults = await KeyResult.list();
        const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        const keyResultIds = keyResultsData.map(kr => kr.id);

        // Buscar iniciativas dos key results filtrados
        const allInitiatives = await Initiative.list();
        const initiativesData = allInitiatives.filter(init => keyResultIds.includes(init.key_result_id));

        // Buscar sprints dos projetos filtrados
        const allSprints = await Sprint.list();
        const sprintsData = allSprints.filter(spr => projectIds.includes(spr.project_id));

        setData({
          projects: projectsData,
          objectives: objectivesData,
          keyResults: keyResultsData,
          initiatives: initiativesData,
          sprints: sprintsData
        });
      } catch (error) {
        console.error("Error loading report data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [user, showAllUsers, selectedCompany, selectedUser]); // Dependencies for useEffect


  // Executive Dashboard Logic - MOVED TO ExecutiveDashboard.js
  // filteredObjectives and related calculations are now inside ExecutiveDashboard.js

  // Project Performance Logic
  const selectedProject = data.projects.find(p => p.id === filters.project);
  const projectObjectives = data.objectives.filter(o => o.project_id === filters.project);
  const projectKeyResults = data.keyResults.filter(kr =>
    projectObjectives.some(obj => obj.id === kr.objective_id)
  );
  const projectInitiatives = data.initiatives.filter(i =>
    projectKeyResults.some(kr => kr.id === i.key_result_id)
  );

  const projectData = selectedProject ? {
    overallProgress: projectObjectives.length > 0
      ? Math.round(projectObjectives.reduce((acc, o) => acc + o.progress, 0) / projectObjectives.length)
      : 0,
    totalObjectives: projectObjectives.length,
    completedObjectives: projectObjectives.filter(o => o.progress === 100).length,
    totalKeyResults: projectKeyResults.length,
    onTrackKeyResults: projectKeyResults.filter(kr => kr.progress >= 70).length,
    totalInitiatives: projectInitiatives.length,
    completedInitiatives: projectInitiatives.filter(i => i.status === 'done').length,

    objectivesByQuarter: ['Q1', 'Q2', 'Q3', 'Q4'].map(quarter => {
      const quarterObjectives = projectObjectives.filter(o => o.quarter === quarter);
      return {
        quarter,
        progress: quarterObjectives.length > 0
          ? Math.round(quarterObjectives.reduce((acc, o) => acc + o.progress, 0) / quarterObjectives.length)
          : 0,
        count: quarterObjectives.length
      };
    }),

    responsiblePerformance: [...new Set(projectKeyResults.map(kr => kr.responsible))].map(responsible => {
      const responsibleKRs = projectKeyResults.filter(kr => kr.responsible === responsible);
      const responsibleInitiatives = projectInitiatives.filter(i => i.responsible === responsible);
      return {
        name: responsible,
        keyResults: responsibleKRs.length,
        avgProgress: responsibleKRs.length > 0
          ? Math.round(responsibleKRs.reduce((acc, kr) => acc + kr.progress, 0) / responsibleKRs.length)
          : 0,
        completedInitiatives: responsibleInitiatives.filter(i => i.status === 'done').length,
        totalInitiatives: responsibleInitiatives.length,
        completionRate: responsibleInitiatives.length > 0
          ? Math.round((responsibleInitiatives.filter(i => i.status === 'done').length / responsibleInitiatives.length) * 100)
          : 0
      };
    }),

    initiativeStatusData: [
      {
        name: 'A Fazer',
        value: projectInitiatives.filter(i => i.status === 'todo').length,
        color: '#64748b',
        percentage: projectInitiatives.length > 0
          ? Math.round((projectInitiatives.filter(i => i.status === 'todo').length / projectInitiatives.length) * 100)
          : 0
      },
      {
        name: 'Fazendo',
        value: projectInitiatives.filter(i => i.status === 'doing').length,
        color: '#3b82f6',
        percentage: projectInitiatives.length > 0
          ? Math.round((projectInitiatives.filter(i => i.status === 'doing').length / projectInitiatives.length) * 100)
          : 0
      },
      {
        name: 'Feito',
        value: projectInitiatives.filter(i => i.status === 'done').length,
        color: '#22c55e',
        percentage: projectInitiatives.length > 0
          ? Math.round((projectInitiatives.filter(i => i.status === 'done').length / projectInitiatives.length) * 100)
          : 0
      },
    ]
  } : null;

  // Custom label para o gráfico de pizza
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, value, percentage }) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    if (value === 0) return null;

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? 'start' : 'end'}
        dominantBaseline="central"
        fontSize="12"
        fontWeight="bold"
      >
        {`${value} (${percentage}%)`}
      </text>
    );
  };

  const getHeatmapColor = (progress) => {
    if (progress < 0) return 'bg-slate-100 text-slate-400';
    if (progress < 40) return 'bg-red-100 text-red-700';
    if (progress < 70) return 'bg-yellow-100 text-yellow-700';
    return 'bg-green-100 text-green-700';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full p-8">
        <Loader2 className="w-12 h-12 text-slate-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col gap-4 mb-6">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <div>
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-slate-900">Relatórios Executivos</h1>
                <p className="text-sm md:text-base text-slate-600">Analytics e insights estratégicos</p>
            </div>
          </div>
        </div>

        <Tabs value={selectedReport} onValueChange={setSelectedReport} className="space-y-4 md:space-y-6">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-4 gap-1 bg-white/80 backdrop-blur-sm shadow-lg h-auto p-1">
            <TabsTrigger value="executive" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Dashboard Executivo</span>
              <span className="sm:hidden">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="tree" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <Target className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Árvore OKR</span>
              <span className="sm:hidden">Árvore</span>
            </TabsTrigger>
            <TabsTrigger value="project" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <FolderOpen className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Performance por Projeto</span>
              <span className="sm:hidden">Projetos</span>
            </TabsTrigger>
            <TabsTrigger value="sprint" className="flex items-center justify-center gap-2 text-xs sm:text-sm py-2 px-2">
              <Zap className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Sprint Review</span>
              <span className="sm:hidden">Sprints</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="executive">
            <div className="space-y-4 md:space-y-6">
              <div className="flex flex-col sm:flex-row gap-2">
                <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
                  <SelectTrigger className="w-full sm:w-32 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableQuarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
                  <SelectTrigger className="w-full sm:w-28 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableYears.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                </Select>
                {/* New Project Filter for Executive Dashboard */}
                <Select value={filters.project} onValueChange={(val) => setFilters(f => ({ ...f, project: val }))}>
                  <SelectTrigger className="w-full sm:w-48 bg-white/80">
                    <SelectValue placeholder="Todos os Projetos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Projetos</SelectItem>
                    {data.projects.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <ExecutiveDashboard
                objectives={data.objectives}
                keyResults={data.keyResults}
                initiatives={data.initiatives}
                projects={data.projects}
                sprints={data.sprints} // Pass sprints for TimelineView
                filters={filters}
                setFilters={setFilters} // Pass setFilters for project performance click
                setSelectedReport={setSelectedReport} // Pass setSelectedReport for project performance click
              />
            </div>
          </TabsContent>

          <TabsContent value="tree">
            <div className="space-y-4 md:space-y-6">
              {/* Admin Filter for Tree View */}
              {user?.role === 'admin' && (
                <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Switch
                          id="show-all-tree"
                          checked={showAllUsers}
                          onCheckedChange={(checked) => {
                            setShowAllUsers(checked);
                            setSelectedCompany('all'); // Reset selected company when toggling "show all"
                            setSelectedUser('all'); // Reset selected user when toggling "show all"
                          }}
                        />
                        <Label htmlFor="show-all-tree" className="flex items-center gap-2 cursor-pointer">
                          <Eye className="w-4 h-4 text-purple-600" />
                          <span className="font-medium">Ver dados de todos os usuários</span>
                          <Badge variant="outline" className="text-xs">Admin</Badge>
                        </Label>
                      </div>

                      {showAllUsers && (
                        <div className="flex flex-col md:flex-row gap-3 pt-2">
                          {allCompanies.length > 0 && (
                            <Select 
                              value={selectedCompany} 
                              onValueChange={(value) => {
                                setSelectedCompany(value);
                                setSelectedUser('all'); // Reset selected user when company changes
                              }}
                            >
                              <SelectTrigger className="w-full md:w-64">
                                <Building2 className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Filtrar por empresa" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">Todas as empresas</SelectItem>
                                {allCompanies.map(company => (
                                  <SelectItem key={company} value={company}>{company}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}

                          {allUsers.length > 0 && (
                            <Select value={selectedUser} onValueChange={setSelectedUser}>
                              <SelectTrigger className="w-full md:w-64">
                                <SelectValue placeholder="Filtrar por usuário" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">Todos os usuários</SelectItem>
                                {allUsers.map(email => (
                                  <SelectItem key={email} value={email}>
                                    {email}
                                    {userCompanyMap[email] && (
                                      <span className="text-xs text-slate-500 ml-2">
                                        • {userCompanyMap[email]}
                                      </span>
                                    )}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="flex flex-col sm:flex-row gap-2">
                <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
                  <SelectTrigger className="w-full sm:w-32 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableQuarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
                  <SelectTrigger className="w-full sm:w-28 bg-white/80"><SelectValue /></SelectTrigger>
                  <SelectContent>{availableYears.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={filters.project} onValueChange={(val) => setFilters(f => ({ ...f, project: val }))}>
                  <SelectTrigger className="w-full sm:w-48 bg-white/80">
                    <SelectValue placeholder="Todos os Projetos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Projetos</SelectItem>
                    {data.projects.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <OKRTreeView
                objectives={(() => {
                  let filtered = data.objectives.filter(o =>
                    o.year.toString() === filters.year && o.quarter === filters.quarter
                  );
                  if (filters.project && filters.project !== 'all') {
                    filtered = filtered.filter(o => o.project_id === filters.project);
                  }
                  return filtered;
                })()}
                keyResults={data.keyResults}
                projects={data.projects}
              />
            </div>
          </TabsContent>

          <TabsContent value="project">
            <div className="space-y-6">
              <div className="flex gap-2">
                <Select value={filters.project} onValueChange={(val) => setFilters(f => ({ ...f, project: val }))}>
                  <SelectTrigger className="w-full sm:w-64 bg-white/80">
                    <SelectValue placeholder="Selecione um projeto" />
                  </SelectTrigger>
                  <SelectContent>
                    {data.projects.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedProject && projectData ? (
                <div className="space-y-6">
                  <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <FolderOpen className="w-6 h-6 text-blue-600" />
                        {selectedProject.name}
                        <Badge className={getHeatmapColor(projectData.overallProgress)}>
                          {projectData.overallProgress}% Progresso Geral
                        </Badge>
                      </CardTitle>
                      <p className="text-slate-600">{selectedProject.description}</p>
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                        <span>Responsável: {selectedProject.responsible}</span>
                        <span>•</span>
                        <span>{format(new Date(selectedProject.start_date), "dd/MM/yyyy", { locale: ptBR })} - {format(new Date(selectedProject.end_date), "dd/MM/yyyy", { locale: ptBR })}</span>
                      </div>
                    </CardHeader>
                  </Card>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <KpiCard
                      title="Objetivos Concluídos"
                      value={`${projectData.completedObjectives}/${projectData.totalObjectives}`}
                      description="Objetivos finalizados"
                      icon={Target}
                      color="from-green-500 to-green-600"
                    />
                    <KpiCard
                      title="KRs no Rumo"
                      value={`${projectData.onTrackKeyResults}/${projectData.totalKeyResults}`}
                      description="Progresso acima de 70%"
                      icon={TrendingUp}
                      color="from-blue-500 to-blue-600"
                    />
                    <KpiCard
                      title="Iniciativas Feitas"
                      value={`${projectData.completedInitiatives}/${projectData.totalInitiatives}`}
                      description="Ações concluídas"
                      icon={Users}
                      color="from-purple-500 to-purple-600"
                    />
                    <KpiCard
                      title="Progresso Geral"
                      value={`${projectData.overallProgress}%`}
                      description="Média dos objetivos"
                      icon={BarChart3}
                      color="from-orange-500 to-orange-600"
                    />
                  </div>

                  <div className="grid lg:grid-cols-2 gap-8">
                    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
                      <CardHeader>
                        <CardTitle>Progresso por Trimestre</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={projectData.objectivesByQuarter}>
                            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.3} />
                            <XAxis dataKey="quarter" stroke="#64748b" />
                            <YAxis stroke="#64748b" />
                            <Tooltip />
                            <Line
                              type="monotone"
                              dataKey="progress"
                              stroke="#8b5cf6"
                              strokeWidth={3}
                              dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 6 }}
                              name="Progresso (%)"
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
                      <CardHeader>
                        <CardTitle>Status das Iniciativas</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <PieChart>
                            <Pie
                              data={projectData.initiativeStatusData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={renderCustomizedLabel}
                              outerRadius={120}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {projectData.initiativeStatusData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value, name, props) => [`${value} (${props.payload.percentage}%)`, name]} />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-blue-600" />
                        Performance da Equipe
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {projectData.responsiblePerformance.map((person) => (
                          <div key={person.name} className="p-5 rounded-xl bg-gradient-to-r from-slate-50 to-blue-50 border border-slate-200">
                            <div className="flex justify-between items-center mb-4">
                              <h4 className="font-bold text-lg text-slate-900">{person.name}</h4>
                              <Badge variant="outline" className="text-sm font-semibold">
                                {person.avgProgress}% progresso médio
                              </Badge>
                            </div>

                            <div className="grid md:grid-cols-3 gap-6">
                              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                                <div className="text-2xl font-bold text-blue-600 mb-1">{person.keyResults}</div>
                                <div className="text-xs text-slate-500 font-medium">Key Results</div>
                              </div>

                              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                                <div className="text-2xl font-bold text-green-600 mb-1">
                                  {person.completedInitiatives}/{person.totalInitiatives}
                                </div>
                                <div className="text-xs text-slate-500 font-medium">Iniciativas Concluídas</div>
                              </div>

                              <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                                <div className="text-2xl font-bold text-purple-600 mb-1">{person.completionRate}%</div>
                                <div className="text-xs text-slate-500 font-medium">Taxa de Conclusão</div>
                              </div>
                            </div>

                            <div className="mt-4">
                              <div className="flex justify-between text-xs text-slate-500 mb-1">
                                <span>Progresso Geral</span>
                                <span>{person.avgProgress}%</span>
                              </div>
                              <Progress value={person.avgProgress} className="h-2" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
                  <CardContent className="py-16 text-center">
                    <FolderOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-slate-600 mb-2">
                      Selecione um projeto
                    </h3>
                    <p className="text-slate-500">
                      Escolha um projeto para ver a análise detalhada de performance
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="sprint">
            <SprintReviewReport
              sprints={data.sprints}
              initiatives={data.initiatives}
              keyResults={data.keyResults}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
