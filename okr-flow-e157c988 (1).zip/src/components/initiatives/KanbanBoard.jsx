
import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Play, CheckCircle2 } from "lucide-react";

import InitiativeCard from "./InitiativeCard";

const columns = [
  {
    id: 'todo',
    title: 'A Fazer',
    icon: Clock,
    color: 'from-slate-500 to-slate-600',
    bgColor: 'bg-slate-50',
    borderColor: 'border-slate-200'
  },
  {
    id: 'doing', 
    title: 'Fazendo',
    icon: Play,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200'
  },
  {
    id: 'done',
    title: 'Feito',
    icon: CheckCircle2,
    color: 'from-green-500 to-green-600',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200'
  }
];

export default function KanbanBoard({ 
  initiatives, 
  objectives, 
  keyResults,
  onStatusUpdate,
  onReorder,
  onEdit, 
  onDelete 
}) {
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const { draggableId, source, destination } = result;
    
    // Se mudou de coluna (status)
    if (source.droppableId !== destination.droppableId) {
      const newStatus = destination.droppableId;
      onStatusUpdate(draggableId, newStatus, destination.index);
    } 
    // Se mudou de posição na mesma coluna (reordenação)
    else if (source.index !== destination.index) {
      onReorder(draggableId, source.droppableId, source.index, destination.index);
    }
  };

  const getInitiativesByStatus = (status) => {
    return initiatives
      .filter(initiative => initiative.status === status)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  };

  const getRelatedData = (initiative) => {
    const keyResult = keyResults.find(kr => kr.id === initiative.key_result_id);
    const objective = keyResult ? objectives.find(obj => obj.id === keyResult.objective_id) : null;
    
    return {
      keyResultTitle: keyResult ? keyResult.title : 'Resultado Chave não encontrado',
      objectiveTitle: objective ? objective.title : 'Objetivo não encontrado'
    };
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="grid lg:grid-cols-3 gap-6">
        {columns.map((column) => {
          const columnInitiatives = getInitiativesByStatus(column.id);
          
          return (
            <div key={column.id} className="flex flex-col">
              <Card className={`${column.bgColor} ${column.borderColor} border-2 mb-4`}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${column.color} flex items-center justify-center shadow-sm`}>
                        <column.icon className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-slate-900 font-semibold">{column.title}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {columnInitiatives.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
              </Card>

              <Droppable droppableId={column.id}>
                {(provided, snapshot) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className={`flex-1 space-y-3 p-2 rounded-xl transition-all duration-200 min-h-[400px] ${
                      snapshot.isDraggingOver 
                        ? `${column.bgColor} border-2 border-dashed ${column.borderColor}` 
                        : 'bg-transparent'
                    }`}
                  >
                    {columnInitiatives.map((initiative, index) => {
                      const { keyResultTitle, objectiveTitle } = getRelatedData(initiative);
                      return (
                      <Draggable 
                        key={initiative.id} 
                        draggableId={initiative.id} 
                        index={index}
                      >
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={`transform transition-all duration-200 ${
                              snapshot.isDragging 
                                ? 'scale-105 shadow-2xl' // Optimized: Removed 'rotate-3' for a smoother drag animation.
                                : 'hover:shadow-lg'
                            }`}
                          >
                            <InitiativeCard
                              initiative={initiative}
                              keyResultTitle={keyResultTitle}
                              objectiveTitle={objectiveTitle}
                              onEdit={onEdit}
                              onDelete={onDelete}
                              isDragging={snapshot.isDragging}
                            />
                          </div>
                        )}
                      </Draggable>
                    )})}
                    {provided.placeholder}
                    
                    {columnInitiatives.length === 0 && (
                      <div className="text-center py-8 text-slate-400">
                        <column.icon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">Nenhuma iniciativa</p>
                      </div>
                    )}
                  </div>
                )}
              </Droppable>
            </div>
          );
        })}
      </div>
    </DragDropContext>
  );
}
