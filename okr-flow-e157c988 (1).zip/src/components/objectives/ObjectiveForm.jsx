
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Building2 } from "lucide-react";
import { Objective } from "@/api/entities";
import { base44 } from "@/api/base44Client";
import AISuggestButton from "../ai/AISuggestButton";

export default function ObjectiveForm({ objective, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    title: objective?.title || "",
    description: objective?.description || "",
    department: objective?.department || "",
    quarter: objective?.quarter || "Q1",
    year: objective?.year || new Date().getFullYear()
  });
  
  const [existingDepartments, setExistingDepartments] = useState([]);
  const [showNewDepartment, setShowNewDepartment] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadDepartments();
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const loadDepartments = async () => {
    try {
      const objectives = await Objective.list();
      const departments = [...new Set(objectives.map(obj => obj.department).filter(Boolean))];
      setExistingDepartments(departments.sort());
    } catch (error) {
      console.error('Error loading departments:', error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDepartmentSelect = (value) => {
    if (value === "__new__") {
      setShowNewDepartment(true);
      handleChange('department', '');
    } else {
      setShowNewDepartment(false);
      handleChange('department', value);
    }
  };

  const handleObjectiveSuggestion = (suggestion) => {
    setFormData(prev => ({
      ...prev,
      title: suggestion.title,
      description: suggestion.description
    }));
  };

  const handleDescriptionSuggestion = (description) => {
    setFormData(prev => ({
      ...prev,
      description: description
    }));
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - 1 + i);

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-bold text-slate-900 mb-2">
              {objective ? 'Editar Objetivo' : 'Novo Objetivo'}
            </CardTitle>
            {user?.company && (
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Building2 className="w-4 h-4" />
                <span className="font-medium">{user.company}</span>
              </div>
            )}
          </div>
          <AISuggestButton
            type="objectives"
            context={{
              department: formData.department,
              quarter: formData.quarter,
              year: formData.year
            }}
            onSuggestionSelect={handleObjectiveSuggestion}
            variant="default"
            className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white"
          />
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-700">
              Departamento *
            </Label>
            
            {!showNewDepartment ? (
              <Select 
                value={formData.department || "__placeholder__"} 
                onValueChange={handleDepartmentSelect}
                required
              >
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue placeholder="Selecione ou crie um departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__placeholder__" disabled>
                    Selecione um departamento
                  </SelectItem>
                  {existingDepartments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                  <SelectItem value="__new__" className="font-semibold text-purple-600">
                    + Criar novo departamento
                  </SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <div className="space-y-2">
                <Input
                  value={formData.department}
                  onChange={(e) => handleChange('department', e.target.value)}
                  placeholder="Digite o nome do novo departamento"
                  required
                  className="border-slate-200 focus:border-purple-500"
                  autoFocus
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setShowNewDepartment(false);
                    handleChange('department', '');
                  }}
                  className="text-xs"
                >
                  Cancelar e selecionar existente
                </Button>
              </div>
            )}
            
            {existingDepartments.length > 0 && !showNewDepartment && (
              <p className="text-xs text-slate-500">
                Departamentos existentes: {existingDepartments.join(', ')}
              </p>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Trimestre *
              </Label>
              <Select value={formData.quarter} onValueChange={(value) => handleChange('quarter', value)}>
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Q1">Q1 (Jan-Mar)</SelectItem>
                  <SelectItem value="Q2">Q2 (Abr-Jun)</SelectItem>
                  <SelectItem value="Q3">Q3 (Jul-Set)</SelectItem>
                  <SelectItem value="Q4">Q4 (Out-Dez)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Ano *
              </Label>
              <Select 
                value={formData.year.toString()} 
                onValueChange={(value) => handleChange('year', parseInt(value))}
              >
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-semibold text-slate-700">
              Título do Objetivo *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange('title', e.target.value)}
              placeholder="Ex: Aumentar receita recorrente"
              required
              className="border-slate-200 focus:border-purple-500"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="description" className="text-sm font-semibold text-slate-700">
                Descrição
              </Label>
              {formData.title && (
                <AISuggestButton
                  type="objective_description"
                  context={{
                    objective_title: formData.title
                  }}
                  onSuggestionSelect={handleDescriptionSuggestion}
                  variant="outline"
                  size="sm"
                  className="h-8"
                />
              )}
            </div>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descreva o objetivo estratégico..."
              rows={4}
              className="border-slate-200 focus:border-purple-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700">
              <Save className="w-4 h-4 mr-2" />
              Salvar Objetivo
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
