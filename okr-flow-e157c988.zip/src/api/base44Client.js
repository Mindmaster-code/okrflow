import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68c1cd1811a0e242e157c988", 
  requiresAuth: true // Ensure authentication is required for all operations
});
