
import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  TrendingUp, TrendingDown, AlertCircle, CheckCircle2, 
  Target, Users, Clock, Zap, Minus
} from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { LineChart, Line, ResponsiveContainer, Tooltip } from "recharts";

const MetricCard = ({ title, value, change, trend, subtitle, icon: Icon, color = "blue" }) => {
  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    green: "from-emerald-500 to-emerald-600",
    orange: "from-orange-500 to-orange-600",
    red: "from-red-500 to-red-600",
    purple: "from-purple-500 to-purple-600"
  };

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${colorClasses[color]} flex items-center justify-center`}>
            <Icon className="w-5 h-5 text-white" />
          </div>
          {change !== undefined && (
            <div className={`flex items-center gap-1 text-sm font-semibold ${
              trend === 'up' ? 'text-emerald-600' : 
              trend === 'down' ? 'text-red-600' : 
              'text-slate-500'
            }`}>
              {trend === 'up' ? <TrendingUp className="w-4 h-4" /> : 
               trend === 'down' ? <TrendingDown className="w-4 h-4" /> :
               <Minus className="w-4 h-4" />}
              {Math.abs(change)}%
            </div>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-sm text-slate-600 font-medium">{title}</p>
          <p className="text-3xl font-bold text-slate-900">{value}</p>
          {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
        </div>
      </CardContent>
    </Card>
  );
};

const HealthScore = ({ score, label }) => {
  const getColor = (score) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-orange-600';
    return 'text-red-600';
  };

  const getGradient = (score) => {
    if (score >= 80) return 'from-emerald-500 to-emerald-600';
    if (score >= 60) return 'from-blue-500 to-blue-600';
    if (score >= 40) return 'from-orange-500 to-orange-600';
    return 'from-red-500 to-red-600';
  };

  return (
    <div className="flex items-center gap-4">
      <div className="relative w-20 h-20">
        <svg className="w-20 h-20 transform -rotate-90">
          <circle
            cx="40"
            cy="40"
            r="32"
            stroke="currentColor"
            strokeWidth="6"
            fill="none"
            className="text-slate-100"
          />
          <circle
            cx="40"
            cy="40"
            r="32"
            stroke="url(#gradient)"
            strokeWidth="6"
            fill="none"
            strokeDasharray={`${(score / 100) * 200} 200`}
            strokeLinecap="round"
            className="transition-all duration-1000"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" className={getGradient(score).split(' ')[0].replace('from-', 'stop-')} />
              <stop offset="100%" className={getGradient(score).split(' ')[1].replace('to-', 'stop-')} />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`text-2xl font-bold ${getColor(score)}`}>{score}</span>
        </div>
      </div>
      <div>
        <p className="text-sm text-slate-600 font-medium">{label}</p>
        <p className={`text-lg font-bold ${getColor(score)}`}>
          {score >= 80 ? 'Excelente' : 
           score >= 60 ? 'Bom' : 
           score >= 40 ? 'Atenção' : 'Crítico'}
        </p>
      </div>
    </div>
  );
};

const PersonCard = ({ name, metrics, status }) => (
  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
    <div className="flex items-center gap-3">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
        status === 'good' ? 'bg-gradient-to-br from-emerald-400 to-emerald-600' :
        status === 'attention' ? 'bg-gradient-to-br from-orange-400 to-orange-600' :
        'bg-gradient-to-br from-blue-400 to-blue-600'
      }`}>
        {name.charAt(0)}
      </div>
      <div>
        <p className="font-semibold text-slate-900">{name}</p>
        <p className="text-xs text-slate-500">{metrics.initiatives} iniciativas • {metrics.completion}% conclusão</p>
      </div>
    </div>
    <div className="text-right">
      <p className="text-2xl font-bold text-slate-900">{metrics.avgProgress}%</p>
      <p className="text-xs text-slate-500">progresso médio</p>
    </div>
  </div>
);

const Alert = ({ type, message }) => {
  const config = {
    critical: { icon: AlertCircle, color: 'bg-red-50 border-red-200 text-red-800', iconColor: 'text-red-600' },
    warning: { icon: AlertCircle, color: 'bg-orange-50 border-orange-200 text-orange-800', iconColor: 'text-orange-600' },
    success: { icon: CheckCircle2, color: 'bg-emerald-50 border-emerald-200 text-emerald-800', iconColor: 'text-emerald-600' }
  };

  const { icon: Icon, color, iconColor } = config[type];

  return (
    <div className={`flex items-start gap-3 p-4 rounded-lg border ${color}`}>
      <Icon className={`w-5 h-5 mt-0.5 ${iconColor}`} />
      <p className="text-sm font-medium flex-1">{message}</p>
    </div>
  );
};

export default function ExecutiveDashboard({ 
  objectives, 
  keyResults, 
  initiatives, 
  projects,
  sprints,
  filters,
  setFilters,
  setSelectedReport
}) {
  const analytics = useMemo(() => {
    // Filtrar dados
    let filteredObjectives = objectives.filter(o =>
      o.year.toString() === filters.year && o.quarter === filters.quarter
    );

    // Filtrar por projeto se selecionado
    if (filters.project && filters.project !== 'all') {
      filteredObjectives = filteredObjectives.filter(o => o.project_id === filters.project);
    }

    const filteredKRs = keyResults.filter(kr =>
      filteredObjectives.some(obj => obj.id === kr.objective_id)
    );

    const filteredInitiatives = initiatives.filter(i =>
      filteredKRs.some(kr => kr.id === i.key_result_id)
    );

    // Métricas principais
    const avgProgress = filteredObjectives.length > 0
      ? Math.round(filteredObjectives.reduce((sum, o) => sum + o.progress, 0) / filteredObjectives.length)
      : 0;

    const onTrackObjectives = filteredObjectives.filter(o => o.progress >= 70).length;
    const atRiskObjectives = filteredObjectives.filter(o => o.progress < 40).length;

    const completedInitiatives = filteredInitiatives.filter(i => i.status === 'done').length;
    const completionRate = filteredInitiatives.length > 0
      ? Math.round((completedInitiatives / filteredInitiatives.length) * 100)
      : 0;

    // Health Score (algoritmo simples)
    const healthScore = Math.round(
      (avgProgress * 0.4) + // 40% peso no progresso médio
      ((onTrackObjectives / Math.max(1, filteredObjectives.length)) * 100 * 0.3) + // 30% peso em objetivos no rumo
      (completionRate * 0.3) // 30% peso em conclusão de iniciativas
    );

    // Performance por pessoa
    const peoplePerformance = {};
    filteredInitiatives.forEach(initiative => {
      if (!peoplePerformance[initiative.responsible]) {
        peoplePerformance[initiative.responsible] = {
          initiatives: [],
          keyResults: new Set()
        };
      }
      peoplePerformance[initiative.responsible].initiatives.push(initiative);
      peoplePerformance[initiative.responsible].keyResults.add(initiative.key_result_id);
    });

    const people = Object.entries(peoplePerformance).map(([name, data]) => {
      const completion = Math.round(
        (data.initiatives.filter(i => i.status === 'done').length / data.initiatives.length) * 100
      );
      
      const relatedKRs = Array.from(data.keyResults).map(krId =>
        filteredKRs.find(kr => kr.id === krId)
      ).filter(Boolean);

      const avgProgress = relatedKRs.length > 0
        ? Math.round(relatedKRs.reduce((sum, kr) => sum + kr.progress, 0) / relatedKRs.length)
        : 0;

      return {
        name,
        metrics: {
          initiatives: data.initiatives.length,
          completion,
          avgProgress
        },
        status: avgProgress >= 70 ? 'good' : avgProgress >= 40 ? 'attention' : 'critical'
      };
    }).sort((a, b) => b.metrics.avgProgress - a.metrics.avgProgress);

    // Próximas entregas críticas
    const upcomingCritical = filteredInitiatives
      .filter(i => {
        const daysUntilEnd = differenceInDays(parseISO(i.end_date), new Date());
        return i.status !== 'done' && daysUntilEnd <= 7 && daysUntilEnd >= 0 && i.priority === 'critical';
      })
      .sort((a, b) => new Date(a.end_date) - new Date(b.end_date));

    // Alertas automáticos
    const alerts = [];
    
    if (atRiskObjectives > 0) {
      alerts.push({
        type: 'critical',
        message: `${atRiskObjectives} objetivo${atRiskObjectives > 1 ? 's' : ''} com progresso abaixo de 40% - ação imediata necessária`
      });
    }

    if (upcomingCritical.length > 0) {
      alerts.push({
        type: 'warning',
        message: `${upcomingCritical.length} entrega${upcomingCritical.length > 1 ? 's' : ''} crítica${upcomingCritical.length > 1 ? 's' : ''} terminando nos próximos 7 dias`
      });
    }

    if (healthScore >= 80) {
      alerts.push({
        type: 'success',
        message: 'Excelente desempenho! Todos os indicadores estão saudáveis'
      });
    }

    // Dados para tendência (simplificado - em produção viria do histórico)
    const trendData = [
      { period: 'Sem 1', value: Math.max(0, avgProgress - 30) },
      { period: 'Sem 2', value: Math.max(0, avgProgress - 20) },
      { period: 'Sem 3', value: Math.max(0, avgProgress - 10) },
      { period: 'Sem 4', value: avgProgress }
    ];

    return {
      avgProgress,
      onTrackObjectives,
      atRiskObjectives,
      totalObjectives: filteredObjectives.length,
      completionRate,
      completedInitiatives,
      totalInitiatives: filteredInitiatives.length,
      healthScore,
      people: people.slice(0, 5),
      upcomingCritical,
      alerts,
      trendData
    };
  }, [objectives, keyResults, initiatives, filters]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Dashboard Executivo</h2>
          <p className="text-sm text-slate-600 mt-1">{filters.quarter} {filters.year}</p>
        </div>
        <Badge variant="outline" className="text-sm font-semibold px-4 py-2">
          Atualizado {format(new Date(), "dd MMM, HH:mm", { locale: ptBR })}
        </Badge>
      </div>

      {/* Filtros */}
      <div className="flex flex-wrap gap-2">
        <Select value={filters.project || 'all'} onValueChange={(val) => setFilters(f => ({ ...f, project: val }))}>
          <SelectTrigger className="w-64 bg-white/80">
            <SelectValue placeholder="Todos os Projetos" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Projetos</SelectItem>
            {projects.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={filters.quarter} onValueChange={(val) => setFilters(f => ({ ...f, quarter: val }))}>
          <SelectTrigger className="w-32 bg-white/80"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Q1">Q1</SelectItem>
            <SelectItem value="Q2">Q2</SelectItem>
            <SelectItem value="Q3">Q3</SelectItem>
            <SelectItem value="Q4">Q4</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={filters.year} onValueChange={(val) => setFilters(f => ({ ...f, year: val }))}>
          <SelectTrigger className="w-28 bg-white/80"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[...new Set(objectives.map(o => o.year.toString()))].sort((a, b) => b - a).map(y => (
              <SelectItem key={y} value={y}>{y}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Alertas */}
      {analytics.alerts.length > 0 && (
        <div className="space-y-2">
          {analytics.alerts.map((alert, idx) => (
            <Alert key={idx} type={alert.type} message={alert.message} />
          ))}
        </div>
      )}

      {/* Métricas principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Health Score"
          value={analytics.healthScore}
          subtitle="Saúde geral dos OKRs"
          icon={Target}
          color={analytics.healthScore >= 70 ? 'green' : analytics.healthScore >= 40 ? 'orange' : 'red'}
          change={5}
          trend="up"
        />
        <MetricCard
          title="Progresso Médio"
          value={`${analytics.avgProgress}%`}
          subtitle={`${analytics.totalObjectives} objetivos ativos`}
          icon={TrendingUp}
          color="blue"
          change={8}
          trend="up"
        />
        <MetricCard
          title="Taxa de Conclusão"
          value={`${analytics.completionRate}%`}
          subtitle={`${analytics.completedInitiatives}/${analytics.totalInitiatives} iniciativas`}
          icon={CheckCircle2}
          color="purple"
          change={3}
          trend="up"
        />
        <MetricCard
          title="Objetivos no Rumo"
          value={analytics.onTrackObjectives}
          subtitle={`${analytics.atRiskObjectives} em risco`}
          icon={Target}
          color={analytics.atRiskObjectives > 0 ? 'orange' : 'green'}
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Saúde dos OKRs */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="font-semibold text-slate-900 mb-6">Saúde dos OKRs</h3>
            <div className="space-y-6">
              <HealthScore score={analytics.healthScore} label="Score Geral" />
              
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">No Rumo</span>
                  <span className="text-sm font-bold text-emerald-600">
                    {analytics.onTrackObjectives} obj.
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Em Risco</span>
                  <span className="text-sm font-bold text-red-600">
                    {analytics.atRiskObjectives} obj.
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Conclusão</span>
                  <span className="text-sm font-bold text-blue-600">
                    {analytics.completionRate}%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tendência */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="font-semibold text-slate-900 mb-6">Tendência de Progresso</h3>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={analytics.trendData}>
                <Tooltip 
                  contentStyle={{ 
                    background: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    padding: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-4 flex items-center justify-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span className="text-slate-600">
                Evolução positiva nas últimas 4 semanas
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Próximas Entregas Críticas */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="font-semibold text-slate-900 mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-600" />
              Entregas Críticas
            </h3>
            {analytics.upcomingCritical.length > 0 ? (
              <div className="space-y-3">
                {analytics.upcomingCritical.slice(0, 4).map(initiative => {
                  const daysLeft = differenceInDays(parseISO(initiative.end_date), new Date());
                  return (
                    <div key={initiative.id} className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <p className="font-medium text-sm text-slate-900">{initiative.title}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-slate-600">{initiative.responsible}</span>
                        <Badge className="bg-orange-500 text-white text-xs">
                          {daysLeft} dia{daysLeft !== 1 ? 's' : ''}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm text-slate-600">Nenhuma entrega crítica próxima</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Performance da Equipe */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              Performance da Equipe
            </h3>
            <span className="text-sm text-slate-600">{analytics.people.length} pessoas</span>
          </div>
          <div className="space-y-3">
            {analytics.people.map(person => (
              <PersonCard key={person.name} {...person} />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
