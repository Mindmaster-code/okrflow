import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import AISuggestButton from "../ai/AISuggestButton";

export default function ProjectForm({ project, objectives, keyResults, sprints, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    key_result_id: project?.key_result_id || "",
    sprint_id: project?.sprint_id || "",
    title: project?.title || "",
    description: project?.description || "",
    responsible: project?.responsible || "",
    start_date: project?.start_date || "",
    end_date: project?.end_date || "",
    priority: project?.priority || "medium",
    status: project?.status || "todo"
  });

  const [selectedObjective, setSelectedObjective] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleProjectSuggestion = (suggestion) => {
    setFormData(prev => ({
      ...prev,
      title: suggestion.title,
      description: suggestion.description,
      responsible: suggestion.responsible || prev.responsible,
      priority: suggestion.priority || prev.priority
    }));
  };

  const selectedKR = keyResults.find(kr => kr.id === formData.key_result_id);
  const objectiveForKR = selectedKR ? objectives.find(obj => obj.id === selectedKR.objective_id) : null;

  const getAvailableKeyResults = () => {
    if (!selectedObjective) return keyResults;
    return keyResults.filter(kr => kr.objective_id === selectedObjective);
  };

  const getAvailableSprints = () => {
    if (!selectedKR) return sprints;
    // Sprints do mesmo usuário que criou o objetivo
    return sprints.filter(spr => spr.created_by === objectiveForKR?.created_by);
  };

  const getKRDates = () => {
    if (!selectedKR) return null;
    return {
      start: selectedKR.start_date,
      end: selectedKR.end_date
    };
  };

  const krDates = getKRDates();
  const isDateValid = krDates && formData.start_date && formData.end_date 
    ? formData.start_date >= krDates.start && formData.end_date <= krDates.end
    : true;

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">
            {project ? 'Editar Projeto' : 'Novo Projeto'}
          </CardTitle>
          {formData.key_result_id && (
            <AISuggestButton
              type="projects"
              context={{
                key_result_title: selectedKR?.title,
                objective_title: objectiveForKR?.title,
                key_result_description: selectedKR?.description
              }}
              onSuggestionSelect={handleProjectSuggestion}
              variant="default"
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
            />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-700">
              Objetivo (para filtrar KRs)
            </Label>
            <Select 
              value={selectedObjective} 
              onValueChange={(value) => {
                setSelectedObjective(value);
                handleChange('key_result_id', '');
                handleChange('start_date', '');
                handleChange('end_date', '');
              }}
            >
              <SelectTrigger className="border-slate-200">
                <SelectValue placeholder="Selecione um objetivo" />
              </SelectTrigger>
              <SelectContent>
                {objectives.map((objective) => (
                  <SelectItem key={objective.id} value={objective.id}>
                    {objective.title} ({objective.quarter} {objective.year})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-700">
              Resultado Chave *
            </Label>
            <Select 
              value={formData.key_result_id} 
              onValueChange={(value) => {
                handleChange('key_result_id', value);
                handleChange('start_date', '');
                handleChange('end_date', '');
              }}
              required
              disabled={!selectedObjective}
            >
              <SelectTrigger className="border-slate-200 focus:border-orange-500">
                <SelectValue placeholder={selectedObjective ? "Selecione o resultado chave" : "Selecione um objetivo primeiro"} />
              </SelectTrigger>
              <SelectContent>
                {getAvailableKeyResults().map((kr) => (
                  <SelectItem key={kr.id} value={kr.id}>
                    {kr.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {krDates && (
              <p className="text-xs text-slate-500">
                Período do KR: {krDates.start} a {krDates.end}
              </p>
            )}
          </div>

          {!isDateValid && formData.start_date && formData.end_date && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                As datas do projeto devem estar dentro do período do Resultado Chave ({krDates?.start} a {krDates?.end})
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-semibold text-slate-700">
              Título do Projeto *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange('title', e.target.value)}
              placeholder="Ex: Redesenhar landing page"
              required
              className="border-slate-200 focus:border-orange-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-semibold text-slate-700">
              Descrição
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descreva o escopo e detalhes do projeto..."
              rows={3}
              className="border-slate-200 focus:border-orange-500"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="responsible" className="text-sm font-semibold text-slate-700">
                Responsável *
              </Label>
              <Input
                id="responsible"
                value={formData.responsible}
                onChange={(e) => handleChange('responsible', e.target.value)}
                placeholder="Nome do responsável"
                required
                className="border-slate-200 focus:border-orange-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="priority" className="text-sm font-semibold text-slate-700">
                Prioridade *
              </Label>
              <Select value={formData.priority} onValueChange={(value) => handleChange('priority', value)}>
                <SelectTrigger className="border-slate-200 focus:border-orange-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baixa</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="critical">Crítica</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="start_date" className="text-sm font-semibold text-slate-700">
                Data de Início *
              </Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => handleChange('start_date', e.target.value)}
                required
                min={krDates?.start}
                max={krDates?.end}
                className="border-slate-200 focus:border-orange-500"
                disabled={!formData.key_result_id}
              />
              {!formData.key_result_id && (
                <p className="text-xs text-amber-600">Selecione um resultado chave primeiro</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="end_date" className="text-sm font-semibold text-slate-700">
                Data de Fim *
              </Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date}
                onChange={(e) => handleChange('end_date', e.target.value)}
                required
                min={formData.start_date || krDates?.start}
                max={krDates?.end}
                className="border-slate-200 focus:border-orange-500"
                disabled={!formData.key_result_id}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sprint" className="text-sm font-semibold text-slate-700">
              Sprint (Opcional)
            </Label>
            <Select 
              value={formData.sprint_id || "none"} 
              onValueChange={(value) => handleChange('sprint_id', value === "none" ? "" : value)}
              disabled={!formData.key_result_id}
            >
              <SelectTrigger className="border-slate-200 focus:border-orange-500">
                <SelectValue placeholder="Sem sprint (Backlog)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sem Sprint (Backlog)</SelectItem>
                {getAvailableSprints().map((sprint) => (
                  <SelectItem key={sprint.id} value={sprint.id}>
                    {sprint.name} ({sprint.start_date} a {sprint.end_date})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
              disabled={!isDateValid}
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar Projeto
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}