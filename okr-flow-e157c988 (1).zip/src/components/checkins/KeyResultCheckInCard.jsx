
import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Calendar, 
  TrendingUp, 
  AlertTriangle, 
  X as XCircle, 
  Clock,
  MessageSquare,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function KeyResultCheckInCard({ 
  keyResult, 
  objective, 
  lastCheckIn,
  checkIns = [],
  onCheckIn,
  showUserBadge = false
}) {
  const [showHistory, setShowHistory] = useState(false);

  const getStatusInfo = (status) => {
    switch (status) {
      case 'on_track':
        return {
          label: 'No Rumo',
          color: 'bg-green-100 text-green-700',
          icon: TrendingUp,
          iconColor: 'text-green-600'
        };
      case 'at_risk':
        return {
          label: 'Em Risco',
          color: 'bg-orange-100 text-orange-700',
          icon: AlertTriangle,
          iconColor: 'text-orange-600'
        };
      case 'off_track':
        return {
          label: 'Fora do Rumo',
          color: 'bg-red-100 text-red-700',
          icon: XCircle,
          iconColor: 'text-red-600'
        };
      default:
        return {
          label: 'Sem Check-in',
          color: 'bg-slate-100 text-slate-700',
          icon: Clock,
          iconColor: 'text-slate-400'
        };
    }
  };

  const statusInfo = getStatusInfo(lastCheckIn?.status);
  const StatusIcon = statusInfo.icon;

  const daysSinceLastUpdate = lastCheckIn 
    ? Math.floor((new Date() - new Date(lastCheckIn.check_in_date)) / (1000 * 60 * 60 * 24))
    : null;

  const needsUpdate = !lastCheckIn || daysSinceLastUpdate > 7;

  return (
    <Card className={`bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0 relative ${
      needsUpdate ? 'ring-2 ring-orange-200' : ''
    }`}>
      {showUserBadge && (
        <Badge className="absolute -top-2 -right-2 z-10 bg-blue-600 text-white text-xs">
          {keyResult.responsible}
        </Badge>
      )}
      
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-3">
          <Badge variant="outline" className="text-xs">
            {objective?.quarter} {objective?.year}
          </Badge>
          <div className="flex items-center gap-2">
            <StatusIcon className={`w-5 h-5 ${statusInfo.iconColor}`} />
            <Badge className={statusInfo.color}>
              {statusInfo.label}
            </Badge>
          </div>
        </div>

        <h3 className="font-bold text-lg text-slate-900 leading-tight mb-2">
          {keyResult.title}
        </h3>

        <p className="text-sm text-slate-600">
          <strong>Objetivo:</strong> {objective?.title}
        </p>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-slate-700">Progresso</span>
            <span className="text-2xl font-bold text-slate-900">{keyResult.progress}%</span>
          </div>
          <Progress value={keyResult.progress} className="h-3 [&>div]:bg-green-500" />
          <div className="flex justify-between text-xs text-slate-500">
            <span>{keyResult.current_value} {keyResult.unit}</span>
            <span>Meta: {keyResult.target_value} {keyResult.unit}</span>
          </div>
        </div>

        {/* Last Check-in Info */}
        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
          {lastCheckIn ? (
            <>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600 flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Último check-in:
                </span>
                <span className="font-medium text-slate-900">
                  {formatDistanceToNow(new Date(lastCheckIn.check_in_date), { 
                    addSuffix: true, 
                    locale: ptBR 
                  })}
                </span>
              </div>
              
              {lastCheckIn.confidence_level && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">Confiança:</span>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 10 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-2 h-4 rounded-sm ${
                          i < lastCheckIn.confidence_level ? 'bg-blue-500' : 'bg-slate-200'
                        }`}
                      />
                    ))}
                    <span className="ml-2 font-bold text-slate-900">
                      {lastCheckIn.confidence_level}/10
                    </span>
                  </div>
                </div>
              )}

              {lastCheckIn.comments && (
                <div className="pt-2 border-t border-slate-200">
                  <p className="text-xs text-slate-600 flex items-start gap-2">
                    <MessageSquare className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-2">{lastCheckIn.comments}</span>
                  </p>
                </div>
              )}

              {lastCheckIn.blockers && (
                <div className="flex items-start gap-2 text-xs text-red-600 bg-red-50 p-2 rounded">
                  <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  <span className="line-clamp-2">{lastCheckIn.blockers}</span>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-2">
              <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm text-slate-500">Nenhum check-in registrado</p>
            </div>
          )}
        </div>

        {/* History */}
        {checkIns.length > 1 && (
          <Collapsible open={showHistory} onOpenChange={setShowHistory}>
            <CollapsibleTrigger className="w-full">
              <Button variant="ghost" size="sm" className="w-full text-xs">
                {showHistory ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
                Histórico ({checkIns.length} check-ins)
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 space-y-2">
              {checkIns.slice(0, 5).map((checkIn, idx) => {
                const ciStatus = getStatusInfo(checkIn.status);
                const CIIcon = ciStatus.icon;
                return (
                  <div key={idx} className="text-xs bg-slate-50 p-2 rounded border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium text-slate-900">
                        {format(new Date(checkIn.check_in_date), "dd/MM/yyyy", { locale: ptBR })}
                      </span>
                      <div className="flex items-center gap-1">
                        <CIIcon className={`w-3 h-3 ${ciStatus.iconColor}`} />
                        <span className={`text-xs px-2 py-0.5 rounded ${ciStatus.color}`}>
                          {ciStatus.label}
                        </span>
                      </div>
                    </div>
                    <div className="text-slate-600">
                      Valor: {checkIn.new_value} {keyResult.unit}
                      {checkIn.confidence_level && (
                        <span className="ml-2">• Confiança: {checkIn.confidence_level}/10</span>
                      )}
                    </div>
                    {checkIn.comments && (
                      <p className="text-slate-500 mt-1 line-clamp-1">{checkIn.comments}</p>
                    )}
                  </div>
                );
              })}
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Actions */}
        <Button 
          onClick={() => onCheckIn(keyResult)}
          className={`w-full ${
            needsUpdate 
              ? 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700' 
              : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
          }`}
        >
          <Calendar className="w-4 h-4 mr-2" />
          {needsUpdate ? 'Atualização Necessária' : 'Fazer Check-in'}
        </Button>
      </CardContent>
    </Card>
  );
}
