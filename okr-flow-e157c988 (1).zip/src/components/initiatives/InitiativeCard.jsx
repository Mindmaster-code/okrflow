
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, Target, Key, Pencil, Trash2 } from "lucide-react"; // Removed Zap as sprintName is removed
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function InitiativeCard({ 
  initiative, 
  objectiveTitle,
  keyResultTitle,
  onEdit, 
  onDelete, 
  isDragging 
}) {
  const getPriorityProps = (priority) => {
    switch (priority) {
      case 'critical': return { badge: 'bg-red-100 text-red-700 border-red-200', label: 'Crítica' };
      case 'high': return { badge: 'bg-orange-100 text-orange-700 border-orange-200', label: 'Alta' };
      case 'medium': return { badge: 'bg-yellow-100 text-yellow-700 border-yellow-200', label: 'Média' };
      case 'low': return { badge: 'bg-green-100 text-green-700 border-green-200', label: 'Baixa' };
      default: return { badge: 'bg-slate-100 text-slate-700 border-slate-200', label: 'Média' };
    }
  };

  const getStatusConfig = (status) => {
    switch (status) {
      case 'done': return { bgColor: 'bg-green-50', borderColor: 'border-green-300' };
      case 'in_progress': return { bgColor: 'bg-blue-50', borderColor: 'border-blue-300' };
      case 'pending': return { bgColor: 'bg-yellow-50', borderColor: 'border-yellow-300' };
      case 'blocked': return { bgColor: 'bg-red-50', borderColor: 'border-red-300' };
      default: return { bgColor: 'bg-slate-50', borderColor: 'border-slate-300' };
    }
  };

  const priorityConfig = getPriorityProps(initiative.priority);
  const statusConfig = getStatusConfig(initiative.status);
  const priorityLabel = priorityConfig.label;

  return (
    <Card className={`${statusConfig.bgColor} border-2 ${statusConfig.borderColor} shadow-md hover:shadow-xl transition-all duration-300 ${
      isDragging ? 'rotate-2 scale-105 shadow-2xl' : ''
    } group`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start mb-2">
          <Badge className={`${priorityConfig.badge} text-xs font-semibold shadow-sm`}>
            {priorityLabel}
          </Badge>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(initiative);
              }}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7 p-0 hover:bg-orange-100 hover:text-orange-600"
            >
              <Pencil className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(initiative.id);
              }}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7 p-0 hover:bg-red-100 hover:text-red-600"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        <h4 className="font-bold text-slate-900 text-sm leading-tight group-hover:text-orange-600 transition-colors">
          {initiative.title}
        </h4>
        
        {initiative.description && (
          <p className="text-slate-600 text-xs mt-2 line-clamp-2">
            {initiative.description}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="space-y-2 p-3 bg-white/50 rounded-lg border border-slate-200">
          <div className="flex items-start gap-2">
            <Target className="w-3 h-3 text-purple-500 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-slate-700 font-medium truncate">{objectiveTitle}</p>
          </div>
          
          <div className="flex items-start gap-2">
            <Key className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-slate-600 truncate">{keyResultTitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-600">
          <User className="w-3 h-3 text-slate-400" />
          <span className="truncate">{initiative.responsible}</span>
        </div>
        
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <Calendar className="w-3 h-3 text-slate-400" />
          <span>
            {format(new Date(initiative.start_date), "dd/MM", { locale: ptBR })} - 
            {format(new Date(initiative.end_date), "dd/MM/yy", { locale: ptBR })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
