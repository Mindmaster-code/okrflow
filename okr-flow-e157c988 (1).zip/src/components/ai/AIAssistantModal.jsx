
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { Sparkles, Loader2, Target, Key, Zap, CheckCircle, Edit2, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
// Select components are no longer needed as project selection is removed
// import {
//   Select,
//   SelectContent,
//   SelectItem,
//   SelectTrigger,
//   SelectValue,
// } from "@/components/ui/select";

export default function AIAssistantModal({ open, onClose, user }) {
  const [userInput, setUserInput] = useState("");
  // const [selectedProject, setSelectedProject] = useState(""); // Removed
  const [generating, setGenerating] = useState(false);
  const [generatedOKR, setGeneratedOKR] = useState(null);
  const [error, setError] = useState(null);
  // const [projects, setProjects] = useState([]); // Removed
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (open) {
      // loadProjects(); // Removed
      setUserInput("");
      // setSelectedProject(""); // Removed
      setGeneratedOKR(null);
      setError(null);
    }
  }, [open]);

  // const loadProjects = async () => { // Removed
  //   try {
  //     const userData = await base44.auth.me();
  //     const projectsData = await base44.entities.Project.filter({ created_by: userData.email });
  //     setProjects(projectsData);
  //   } catch (error) {
  //     console.error("Error loading projects:", error);
  //   }
  // };

  const handleGenerate = async () => {
    if (!userInput.trim()) {
      setError("Por favor, descreva o que você deseja alcançar.");
      return;
    }

    setGenerating(true);
    setError(null);

    try {
      const currentYear = new Date().getFullYear();
      const currentQuarter = `Q${Math.ceil((new Date().getMonth() + 1) / 3)}`;
      
      const prompt = `Você é um consultor especialista em metodologia OKR (Objectives and Key Results).

CONTEXTO DO USUÁRIO:
- Empresa: ${user?.company || 'Não informado'}
- Cargo: ${user?.position || 'Não informado'}
- Objetivo geral: ${user?.goal || 'Não informado'}

SOLICITAÇÃO DO USUÁRIO:
"${userInput}"

TAREFA:
Crie um OKR completo, estruturado e profissional seguindo as melhores práticas de metodologia OKR.

DIRETRIZES:
1. O Objetivo deve ser:
   - Inspirador e motivador
   - Qualitativo e ambicioso
   - Claro e compreensível
   - Alinhado com o contexto da empresa
   - Deve incluir um departamento ou área responsável (e.g., Marketing, Vendas, Produto, Engenharia).

2. Os Key Results (3-4) devem ser:
   - Mensuráveis e quantificáveis
   - Específicos com valores baseline e meta
   - Desafiadores mas alcançáveis
   - Com unidades de medida claras

3. Os Projetos (3-5 por KR) devem ser:
   - Ações concretas e executáveis
   - Priorizadas (low, medium, high, critical)
   - Com descrições objetivas
   - Distribuídas ao longo do trimestre
   - Cada projeto deve ser atribuído a um Key Result específico.

Use o trimestre ${currentQuarter} ${currentYear} como período padrão.

Seja profissional, direto e baseado em melhores práticas de gestão empresarial.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            objective: {
              type: "object",
              properties: {
                title: { type: "string", description: "Título do objetivo (máx 100 caracteres)" },
                description: { type: "string", description: "Descrição detalhada do objetivo" },
                department: { type: "string", description: "Departamento ou área responsável pelo objetivo (e.g., Marketing, Vendas, Produto, Engenharia)" }, // Added department
                quarter: { type: "string", description: "Trimestre (Q1, Q2, Q3 ou Q4)" },
                year: { type: "number", description: "Ano" }
              },
              required: ["title", "description", "department", "quarter", "year"] // Added department
            },
            key_results: {
              type: "array",
              minItems: 3,
              maxItems: 4,
              items: {
                type: "object",
                properties: {
                  title: { type: "string", description: "Título do key result" },
                  description: { type: "string", description: "Descrição do key result" },
                  target_value: { type: "number", description: "Valor meta a atingir" },
                  current_value: { type: "number", description: "Valor atual/baseline" },
                  unit: { type: "string", description: "Unidade de medida (%, quantidade, R$, etc)" },
                  responsible: { type: "string", description: "Nome do responsável" }
                },
                required: ["title", "description", "target_value", "current_value", "unit", "responsible"]
              }
            },
            projects: { // Renamed from initiatives
              type: "array",
              minItems: 9,
              maxItems: 20,
              items: {
                type: "object",
                properties: {
                  key_result_index: { type: "number", description: "Índice do KR relacionado (0, 1, 2 ou 3)" },
                  title: { type: "string", description: "Título do projeto" }, // Changed from initiative
                  description: { type: "string", description: "Descrição do projeto" }, // Changed from initiative
                  priority: { type: "string", enum: ["low", "medium", "high", "critical"], description: "Prioridade" },
                  estimated_duration_days: { type: "number", description: "Duração estimada em dias" }
                },
                required: ["key_result_index", "title", "description", "priority"]
              }
            }
          },
          required: ["objective", "key_results", "projects"] // Renamed from initiatives
        }
      });

      setGeneratedOKR(result);
    } catch (err) {
      console.error("Error generating OKR:", err);
      setError("Erro ao gerar OKR. Por favor, tente novamente ou reformule sua solicitação.");
    } finally {
      setGenerating(false);
    }
  };

  const handleCreateAll = async () => {
    // if (!selectedProject) { // Removed project selection check
    //   setError("Por favor, selecione um projeto antes de criar o OKR.");
    //   return;
    // }
    
    setCreating(true);
    setError(null);

    try {
      // Criar objetivo
      const objective = await base44.entities.Objective.create({
        // project_id: selectedProject, // Removed project_id
        title: generatedOKR.objective.title,
        description: generatedOKR.objective.description,
        department: generatedOKR.objective.department, // Added department
        quarter: generatedOKR.objective.quarter,
        year: generatedOKR.objective.year,
        progress: 0
      });

      const quarterDates = {
        'Q1': { start: `${generatedOKR.objective.year}-01-01`, end: `${generatedOKR.objective.year}-03-31` },
        'Q2': { start: `${generatedOKR.objective.year}-04-01`, end: `${generatedOKR.objective.year}-06-30` },
        'Q3': { start: `${generatedOKR.objective.year}-07-01`, end: `${generatedOKR.objective.year}-09-30` },
        'Q4': { start: `${generatedOKR.objective.year}-10-01`, end: `${generatedOKR.objective.year}-12-31` }
      };
      const dates = quarterDates[generatedOKR.objective.quarter];

      // Criar Key Results
      const createdKRs = [];
      for (const kr of generatedOKR.key_results) {
        const createdKR = await base44.entities.KeyResult.create({
          objective_id: objective.id,
          title: kr.title,
          description: kr.description,
          responsible: kr.responsible,
          start_date: dates.start,
          end_date: dates.end,
          target_value: kr.target_value,
          current_value: kr.current_value,
          unit: kr.unit,
          progress: 0
        });
        createdKRs.push(createdKR);
      }

      // Criar Projetos (formerly Initiatives)
      for (const proj of generatedOKR.projects) { // Changed from generatedOKR.initiatives
        const relatedKR = createdKRs[proj.key_result_index];
        if (relatedKR) {
          const startDate = new Date(dates.start);
          const daysOffset = proj.key_result_index * 20;
          startDate.setDate(startDate.getDate() + daysOffset);
          
          const endDate = new Date(startDate);
          endDate.setDate(endDate.getDate() + (proj.estimated_duration_days || 14));
          
          await base44.entities.Project.create({ // Changed from Initiative.create
            key_result_id: relatedKR.id,
            sprint_id: null, // Projects are not directly linked to sprints here
            title: proj.title,
            description: proj.description,
            responsible: user.full_name || user.email,
            start_date: startDate.toISOString().split('T')[0],
            end_date: endDate.toISOString().split('T')[0],
            status: 'todo',
            priority: proj.priority,
            order: 0
          });
        }
      }

      alert(`✅ OKR criado com sucesso!\n\n✓ 1 Objetivo\n✓ ${createdKRs.length} Key Results\n✓ ${generatedOKR.projects.length} Projetos\n\nDepartamento: ${generatedOKR.objective.department}`); // Updated alert message
      
      setUserInput("");
      setGeneratedOKR(null);
      // setSelectedProject(""); // Removed
      onClose();
      
      window.location.reload();
    } catch (error) {
      console.error('Error creating OKR:', error);
      setError('Erro ao criar OKR. Verifique os dados e tente novamente.');
    } finally {
      setCreating(false);
    }
  };

  const handleRegenerate = () => {
    setGeneratedOKR(null);
    handleGenerate();
  };

  const getPriorityColor = (priority) => {
    const colors = {
      critical: "bg-red-100 text-red-700 border-red-200",
      high: "bg-orange-100 text-orange-700 border-orange-200",
      medium: "bg-blue-100 text-blue-700 border-blue-200",
      low: "bg-slate-100 text-slate-700 border-slate-200"
    };
    return colors[priority] || colors.medium;
  };

  const getPriorityLabel = (priority) => {
    const labels = {
      critical: "Crítica",
      high: "Alta",
      medium: "Média",
      low: "Baixa"
    };
    return labels[priority] || priority;
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[95vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <DialogTitle className="text-2xl">Assistente de OKRs com IA</DialogTitle>
              <DialogDescription>
                Gere objetivos, resultados-chave e projetos com inteligência artificial {/* Updated description */}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto pr-4 -mr-4">
          {!generatedOKR ? (
            <div className="space-y-6 py-4">
              {/* Removed projects.length === 0 warning card */}
              {/* No longer requires existing projects to use AI assistant */}

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-base font-semibold">O que você deseja alcançar?</Label>
                  <Textarea
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Exemplo: Aumentar as vendas do e-commerce em 30% através da melhoria da conversão e aumento do ticket médio..."
                    rows={4}
                    className="resize-none"
                    disabled={generating}
                  />
                  <p className="text-xs text-slate-500">
                    Seja específico sobre o resultado que deseja alcançar. Quanto mais contexto, melhor será o OKR gerado.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-600">💡 Sugestões baseadas no seu perfil:</Label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "Aumentar receita em 30%",
                      "Melhorar satisfação do cliente",
                      "Reduzir custos operacionais",
                      "Lançar novo produto",
                      "Expandir base de clientes"
                    ].map((suggestion) => (
                      <Button
                        key={suggestion}
                        variant="outline"
                        size="sm"
                        onClick={() => setUserInput(suggestion)}
                        disabled={generating}
                        className="text-xs"
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              <Button
                onClick={handleGenerate}
                disabled={generating || !userInput.trim()}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 h-12 text-base"
              >
                {generating ? (
                  <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Gerando OKR Completo...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Gerar OKR Completo com IA
                      </>
                    )}
                  </Button>

                  {generating && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-sm text-blue-800 text-center">
                        ⚡ Analisando seu objetivo e gerando OKR estruturado... Isso pode levar alguns segundos.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
            <div className="space-y-6 py-4">
              {/* HEADER COM AÇÕES */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <h3 className="text-lg font-semibold text-slate-900">OKR Gerado com Sucesso</h3>
                </div>
                <Button variant="outline" size="sm" onClick={handleRegenerate} disabled={generating || creating}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Gerar Novo
                </Button>
              </div>

              {/* CARD DE AÇÃO - NO TOPO! */}
              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-400 shadow-xl sticky top-0 z-10">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-5 h-5 text-blue-700" />
                    <h4 className="text-lg font-bold text-blue-900">Criar OKR no Sistema</h4> {/* Updated text */}
                  </div>
                  
                  {/* Removed project selection input */}
                  {/* Removed warning for no project selected */}

                  <div className="bg-green-50 border-2 border-green-400 rounded-lg p-3">
                    <p className="text-sm text-green-800 font-semibold text-center">
                      ✅ Pronto! Será criado: <strong>1 Objetivo</strong>, <strong>{generatedOKR.key_results.length} KRs</strong> e <strong>{generatedOKR.projects.length} projetos</strong> {/* Updated count and "projetos" */}
                    </p>
                    <p className="text-xs text-green-700 text-center mt-1">
                      Departamento: {generatedOKR.objective.department} {/* Added department display */}
                    </p>
                  </div>

                  {error && (
                    <div className="bg-red-50 border-2 border-red-200 rounded-lg p-3">
                      <p className="text-sm text-red-800 font-semibold">{error}</p>
                    </div>
                  )}

                  <div className="flex gap-3 pt-2">
                    <Button
                      variant="outline"
                      onClick={() => setGeneratedOKR(null)}
                      className="flex-1 h-12 text-base"
                      disabled={creating}
                    >
                      <Edit2 className="w-5 h-5 mr-2" />
                      Voltar e Editar
                    </Button>
                    <Button
                      onClick={handleCreateAll}
                      disabled={creating} // No longer depends on selectedProject
                      className="flex-1 h-12 text-base bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg font-bold"
                    >
                      {creating ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Criando...
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Criar OKR no Sistema
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* PREVIEW DO OKR - ABAIXO */}
              <div className="space-y-1 mb-4">
                <h4 className="text-sm font-semibold text-slate-600 uppercase">Prévia do OKR que será criado:</h4>
                <p className="text-xs text-slate-500">Role para baixo para ver todos os detalhes</p>
              </div>

              <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-purple-500 rounded-lg flex-shrink-0">
                      <Target className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-sm font-semibold text-purple-900 uppercase">Objetivo</h4>
                        {generatedOKR.objective.department && ( // Display department if present
                          <Badge variant="outline" className="bg-white">
                            {generatedOKR.objective.department}
                          </Badge>
                        )}
                        <Badge variant="outline" className="bg-white">
                          {generatedOKR.objective.quarter} {generatedOKR.objective.year}
                        </Badge>
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">
                        {generatedOKR.objective.title}
                      </h3>
                      <p className="text-sm text-slate-700">
                        {generatedOKR.objective.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-green-600" />
                  <h4 className="font-semibold text-slate-900">
                    Resultados-Chave ({generatedOKR.key_results.length})
                  </h4>
                </div>
                
                {generatedOKR.key_results.map((kr, index) => (
                  <Card key={index} className="bg-white border-green-200">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <span className="text-sm font-bold text-green-700">{index + 1}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h5 className="font-semibold text-slate-900 mb-1">{kr.title}</h5>
                          <p className="text-sm text-slate-600 mb-2">{kr.description}</p>
                          <div className="flex flex-wrap items-center gap-3 text-xs">
                            <Badge variant="outline" className="bg-green-50">
                              Meta: {kr.target_value} {kr.unit}
                            </Badge>
                            <Badge variant="outline" className="bg-slate-50">
                              Atual: {kr.current_value} {kr.unit}
                            </Badge>
                            <span className="text-slate-500">Responsável: {kr.responsible}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-orange-600" />
                  <h4 className="font-semibold text-slate-900">
                    Projetos ({generatedOKR.projects.length}) {/* Updated from Initiatives */}
                  </h4>
                </div>

                <div className="space-y-4">
                  {generatedOKR.key_results.map((kr, krIndex) => {
                    const krProjects = generatedOKR.projects.filter( // Changed from krInitiatives
                      proj => proj.key_result_index === krIndex // Changed from init
                    );
                    
                    if (krProjects.length === 0) return null; // Changed from krInitiatives
                    
                    return (
                      <div key={krIndex} className="space-y-2">
                        <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg">
                          <span className="text-xs font-semibold text-slate-700">
                            Para KR{krIndex + 1}: {kr.title}
                          </span>
                        </div>
                        <div className="grid gap-2 ml-4">
                          {krProjects.map((proj, projIndex) => ( // Changed from krInitiatives.map((init, initIndex)
                            <div
                              key={projIndex} // Changed from initIndex
                              className="flex items-start gap-2 p-3 bg-white border border-slate-200 rounded-lg"
                            >
                              <Zap className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-2">
                                  <h6 className="font-medium text-sm text-slate-900">{proj.title}</h6> {/* Changed from init.title */}
                                  <Badge className={`${getPriorityColor(proj.priority)} text-xs flex-shrink-0`}> {/* Changed from init.priority */}
                                    {getPriorityLabel(proj.priority)} {/* Changed from init.priority */}
                                  </Badge>
                                </div>
                                <p className="text-xs text-slate-600 mt-1">{proj.description}</p> {/* Changed from init.description */}
                                {proj.estimated_duration_days && ( // Changed from init.estimated_duration_days
                                  <p className="text-xs text-slate-500 mt-1">
                                    Duração estimada: {proj.estimated_duration_days} dias {/* Changed from init.estimated_duration_days */}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
