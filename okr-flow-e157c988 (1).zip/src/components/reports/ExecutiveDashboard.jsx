
import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, TrendingDown, AlertCircle, CheckCircle2, 
  Target, Users, Calendar, ArrowRight, Flag
} from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { LineChart, Line, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, Cell } from "recharts";

const ObjectiveStatusCard = ({ objective, keyResults }) => {
  const objKRs = keyResults.filter(kr => kr.objective_id === objective.id);
  const avgProgress = objKRs.length > 0
    ? Math.round(objKRs.reduce((sum, kr) => sum + kr.progress, 0) / objKRs.length)
    : 0;

  const getStatusColor = (progress) => {
    if (progress >= 70) return {
      bg: 'bg-green-50',
      border: 'border-green-300',
      text: 'text-green-700',
      badge: 'bg-green-100 text-green-700',
      bar: 'bg-green-500'
    };
    if (progress >= 40) return {
      bg: 'bg-orange-50',
      border: 'border-orange-300',
      text: 'text-orange-700',
      badge: 'bg-orange-100 text-orange-700',
      bar: 'bg-orange-500'
    };
    return {
      bg: 'bg-red-50',
      border: 'border-red-300',
      text: 'text-red-700',
      badge: 'bg-red-100 text-red-700',
      bar: 'bg-red-500'
    };
  };

  const status = getStatusColor(avgProgress);
  const statusText = avgProgress >= 70 ? 'No Rumo' : avgProgress >= 40 ? 'Atenção' : 'Risco';

  return (
    <Card className={`${status.bg} border-2 ${status.border} hover:shadow-lg transition-all`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Target className={`w-4 h-4 ${status.text}`} />
              <h4 className={`font-bold ${status.text}`}>{objective.title}</h4>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">{objective.department}</Badge>
              <span className="text-xs text-slate-600">{objKRs.length} KRs</span>
            </div>
          </div>
          <div className="text-right">
            <p className={`text-3xl font-bold ${status.text}`}>{avgProgress}%</p>
            <Badge className={`${status.badge} text-xs mt-1`}>{statusText}</Badge>
          </div>
        </div>
        <Progress value={avgProgress} className="h-2.5" indicatorClassName={status.bar} />
      </CardContent>
    </Card>
  );
};

const CriticalKeyResult = ({ kr, objective }) => {
  const daysUntilEnd = differenceInDays(parseISO(kr.end_date), new Date());
  const isOverdue = daysUntilEnd < 0;
  const isUrgent = daysUntilEnd <= 7 && daysUntilEnd >= 0;

  return (
    <div className={`p-4 rounded-lg border-2 ${
      isOverdue ? 'bg-red-50 border-red-300' :
      kr.progress < 40 ? 'bg-red-50 border-red-200' : 
      'bg-orange-50 border-orange-200'
    }`}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <h5 className="font-semibold text-slate-900 text-sm mb-1">{kr.title}</h5>
          <p className="text-xs text-slate-600 mb-2">{objective.title}</p>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">{kr.responsible}</Badge>
            {isOverdue && (
              <Badge className="bg-red-600 text-white text-xs">
                Atrasado {Math.abs(daysUntilEnd)} dias
              </Badge>
            )}
            {isUrgent && (
              <Badge className="bg-orange-600 text-white text-xs">
                {daysUntilEnd} dias restantes
              </Badge>
            )}
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-red-700">{kr.progress}%</p>
          <p className="text-xs text-slate-500">{kr.current_value}/{kr.target_value}</p>
        </div>
      </div>
      <Progress value={kr.progress} className="h-2" indicatorClassName="bg-red-500" />
    </div>
  );
};

const DepartmentPerformance = ({ objectives, keyResults }) => {
  const deptData = useMemo(() => {
    const depts = {};
    
    objectives.forEach(obj => {
      if (!depts[obj.department]) {
        depts[obj.department] = {
          objectives: [],
          keyResults: []
        };
      }
      depts[obj.department].objectives.push(obj);
      
      const objKRs = keyResults.filter(kr => kr.objective_id === obj.id);
      depts[obj.department].keyResults.push(...objKRs);
    });

    return Object.entries(depts).map(([name, data]) => {
      const avgProgress = data.keyResults.length > 0
        ? Math.round(data.keyResults.reduce((sum, kr) => sum + kr.progress, 0) / data.keyResults.length)
        : 0;
      
      return {
        name,
        progress: avgProgress,
        objectives: data.objectives.length,
        keyResults: data.keyResults.length
      };
    }).sort((a, b) => b.progress - a.progress);
  }, [objectives, keyResults]);

  return (
    <div className="space-y-3">
      {deptData.map(dept => (
        <div key={dept.name} className="p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h5 className="font-semibold text-slate-900">{dept.name}</h5>
              <p className="text-xs text-slate-600">
                {dept.objectives} objetivos • {dept.keyResults} KRs
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-slate-900">{dept.progress}%</p>
            </div>
          </div>
          <Progress value={dept.progress} className="h-2.5" />
        </div>
      ))}
    </div>
  );
};

export default function ExecutiveDashboard({ 
  objectives, 
  keyResults, 
  filters
}) {
  const analytics = useMemo(() => {
    let filteredObjectives = objectives.filter(o =>
      o.year.toString() === filters.year && o.quarter === filters.quarter
    );

    if (filters.objective && filters.objective !== 'all') {
      filteredObjectives = filteredObjectives.filter(o => o.id === filters.objective);
    }

    const filteredKRs = keyResults.filter(kr =>
      filteredObjectives.some(obj => obj.id === kr.objective_id)
    );

    const avgProgress = filteredObjectives.length > 0
      ? Math.round(filteredObjectives.reduce((sum, o) => sum + o.progress, 0) / filteredObjectives.length)
      : 0;

    const onTrackObjectives = filteredObjectives.filter(o => o.progress >= 70);
    const attentionObjectives = filteredObjectives.filter(o => o.progress >= 40 && o.progress < 70);
    const atRiskObjectives = filteredObjectives.filter(o => o.progress < 40);

    const criticalKRs = filteredKRs
      .filter(kr => {
        const daysUntilEnd = differenceInDays(parseISO(kr.end_date), new Date());
        return kr.progress < 70 && (daysUntilEnd <= 7 || kr.progress < 40);
      })
      .sort((a, b) => a.progress - b.progress)
      .slice(0, 5);

    // Dados por área para o gráfico
    const depts = {};
    filteredObjectives.forEach(obj => {
      if (!depts[obj.department]) {
        depts[obj.department] = { keyResults: [] };
      }
      const objKRs = filteredKRs.filter(kr => kr.objective_id === obj.id);
      depts[obj.department].keyResults.push(...objKRs);
    });

    const departmentChartData = Object.entries(depts).map(([name, data]) => {
      const avgProgress = data.keyResults.length > 0
        ? Math.round(data.keyResults.reduce((sum, kr) => sum + kr.progress, 0) / data.keyResults.length)
        : 0;
      
      return {
        name: name.length > 15 ? name.substring(0, 12) + '...' : name, // Shorten for Y-axis label
        fullName: name, // Keep full name for tooltip
        progress: avgProgress
      };
    }).sort((a, b) => b.progress - a.progress);

    return {
      avgProgress,
      onTrackObjectives,
      attentionObjectives,
      atRiskObjectives,
      totalObjectives: filteredObjectives.length,
      criticalKRs,
      departmentChartData,
      filteredObjectives,
      filteredKRs
    };
  }, [objectives, keyResults, filters]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Visão Executiva</h2>
          <p className="text-sm text-slate-600 mt-1">{filters.quarter} {filters.year} • Atualizado {format(new Date(), "dd MMM, HH:mm", { locale: ptBR })}</p>
        </div>
      </div>

      {/* Alerta Principal */}
      {analytics.atRiskObjectives.length > 0 && (
        <Card className="bg-red-50 border-2 border-red-300">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-red-600 mt-0.5" />
              <div>
                <h3 className="font-bold text-red-900 mb-1">Atenção Necessária</h3>
                <p className="text-sm text-red-800">
                  {analytics.atRiskObjectives.length} objetivo{analytics.atRiskObjectives.length > 1 ? 's' : ''} com progresso crítico (abaixo de 40%) - 
                  ação imediata da liderança necessária
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Métricas Principais */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-3">
              <TrendingUp className="w-8 h-8 text-blue-600" />
              <ArrowRight className="w-5 h-5 text-blue-400" />
            </div>
            <p className="text-sm text-blue-700 font-medium mb-1">Progresso Geral</p>
            <p className="text-4xl font-bold text-blue-900">{analytics.avgProgress}%</p>
            <p className="text-xs text-blue-600 mt-1">Média de {analytics.totalObjectives} objetivos</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-3">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
              <ArrowRight className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-sm text-green-700 font-medium mb-1">No Rumo</p>
            <p className="text-4xl font-bold text-green-900">{analytics.onTrackObjectives.length}</p>
            <p className="text-xs text-green-600 mt-1">Progresso ≥ 70%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-3">
              <AlertCircle className="w-8 h-8 text-red-600" />
              <ArrowRight className="w-5 h-5 text-red-400" />
            </div>
            <p className="text-sm text-red-700 font-medium mb-1">Em Risco</p>
            <p className="text-4xl font-bold text-red-900">{analytics.atRiskObjectives.length}</p>
            <p className="text-xs text-red-600 mt-1">Progresso &lt; 40%</p>
          </CardContent>
        </Card>
      </div>

      {/* Visão dos Objetivos */}
      <Card className="border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-5">
            <Flag className="w-5 h-5 text-purple-600" />
            <h3 className="font-bold text-slate-900 text-lg">Status dos Objetivos Estratégicos</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {analytics.filteredObjectives.map(obj => (
              <ObjectiveStatusCard
                key={obj.id}
                objective={obj}
                keyResults={analytics.filteredKRs}
              />
            ))}
          </div>
          {analytics.filteredObjectives.length === 0 && (
            <p className="text-center text-slate-500 py-8">Nenhum objetivo neste período</p>
          )}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Key Results Críticos */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-5">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h3 className="font-bold text-slate-900 text-lg">Key Results Críticos</h3>
            </div>
            {analytics.criticalKRs.length > 0 ? (
              <div className="space-y-3">
                {analytics.criticalKRs.map(kr => {
                  const objective = analytics.filteredObjectives.find(o => o.id === kr.objective_id);
                  return objective ? (
                    <CriticalKeyResult key={kr.id} kr={kr} objective={objective} />
                  ) : null;
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-3" />
                <p className="font-semibold text-slate-700">Nenhum KR crítico</p>
                <p className="text-sm text-slate-500 mt-1">Todos os resultados chave estão no rumo!</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ranking de Áreas */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-5">
              <Users className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-slate-900 text-lg">Ranking de Áreas</h3>
            </div>
            {analytics.departmentChartData.length > 0 ? (
              <div className="space-y-3">
                {analytics.departmentChartData.map((dept, index) => {
                  const color = dept.progress >= 70 ? 'green' : dept.progress >= 40 ? 'orange' : 'red';
                  const bgColor = {
                    green: 'bg-green-50',
                    orange: 'bg-orange-50',
                    red: 'bg-red-50'
                  }[color];
                  const textColor = {
                    green: 'text-green-700',
                    orange: 'text-orange-700',
                    red: 'text-red-700'
                  }[color];
                  const dotColor = {
                    green: 'bg-green-500',
                    orange: 'bg-orange-500',
                    red: 'bg-red-500'
                  }[color];
                  
                  return (
                    <div 
                      key={dept.fullName} 
                      className={`flex items-center justify-between p-4 rounded-lg ${bgColor} border-2 border-${color}-200 hover:shadow-md transition-all`}
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-bold text-slate-400 w-6">#{index + 1}</span>
                        </div>
                        <div className={`w-4 h-4 rounded-full ${dotColor} shadow-lg ring-4 ring-${color}-200 animate-pulse`}></div>
                        <div className="flex-1">
                          <h5 className={`font-semibold ${textColor}`}>{dept.fullName}</h5>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-2xl font-bold ${textColor}`}>{dept.progress}%</p>
                        <p className="text-xs text-slate-500">progresso</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-slate-300 mx-auto mb-3" />
                <p className="text-sm text-slate-500">Nenhuma área com dados</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Performance por Departamento */}
      <Card className="border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-5">
            <Users className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-lg">Performance por Área (Detalhes)</h3>
          </div>
          <DepartmentPerformance 
            objectives={analytics.filteredObjectives}
            keyResults={analytics.filteredKRs}
          />
        </CardContent>
      </Card>
    </div>
  );
}
