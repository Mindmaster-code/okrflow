import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, ThumbsUp, TriangleAlert, Sparkles } from 'lucide-react';

const Section = ({ title, items, icon: Icon, color }) => (
  <div>
    <h3 className={`flex items-center gap-2 font-semibold mb-3 ${color}`}>
      <Icon className="w-5 h-5" />
      {title}
    </h3>
    <ul className="list-disc list-inside space-y-2 text-slate-700 pl-2">
      {items.map((item, index) => (
        <li key={index} className="leading-relaxed">{item}</li>
      ))}
    </ul>
  </div>
);

export const AiAnalysisCard = ({ analysis }) => {
  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-xl">
      <CardHeader className="bg-white/60 backdrop-blur-sm border-b border-blue-200">
        <CardTitle className="flex items-center gap-2 text-xl text-slate-900">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          Análise e Recomendações da IA
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="p-4 bg-white/80 backdrop-blur-sm rounded-xl border border-blue-100">
            <h3 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-blue-600" />
              Resumo Executivo do Sprint
            </h3>
            <p className="text-slate-700 leading-relaxed">{analysis.summary}</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-4 bg-white/80 backdrop-blur-sm rounded-xl border border-green-100">
            <Section 
              title="O que foi bem" 
              items={analysis.what_went_well}
              icon={ThumbsUp}
              color="text-green-700"
            />
          </div>
          
          <div className="p-4 bg-white/80 backdrop-blur-sm rounded-xl border border-orange-100">
            <Section 
              title="Pontos de Melhoria"
              items={analysis.areas_for_improvement}
              icon={TriangleAlert}
              color="text-orange-700"
            />
          </div>
        </div>
         
        <div className="p-4 bg-white/80 backdrop-blur-sm rounded-xl border border-blue-100">
            <h3 className="flex items-center gap-2 font-semibold mb-3 text-blue-700">
                <Lightbulb className="w-5 h-5"/>
                Recomendações para o Próximo Sprint
            </h3>
            <ul className="list-disc list-inside space-y-2 text-slate-700 pl-2">
                {analysis.recommendations.map((item, index) => (
                    <li key={index} className="leading-relaxed">{item}</li>
                ))}
            </ul>
        </div>
      </CardContent>
    </Card>
  );
};