import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Key, Pencil, Trash2, Building2 } from "lucide-react";

export default function ObjectiveCard({ objective, keyResults, onEdit, onDelete }) {
  const getProgressColor = (progress) => {
    if (progress < 40) return 'bg-red-500';
    if (progress < 70) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start mb-3">
          <Badge className="bg-purple-100 text-purple-700 border-purple-200">
            {objective.quarter} {objective.year}
          </Badge>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(objective)}
              className="h-8 w-8 p-0 hover:bg-purple-50 hover:text-purple-600"
            >
              <Pencil className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(objective.id)}
              className="h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <Building2 className="w-4 h-4 text-slate-400" />
          <span className="text-sm font-semibold text-slate-600">{objective.department}</span>
        </div>

        <h3 className="font-bold text-lg text-slate-900 leading-tight">
          {objective.title}
        </h3>
        
        {objective.description && (
          <p className="text-sm text-slate-600 mt-2 line-clamp-2">
            {objective.description}
          </p>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-700">Progresso</span>
            <span className="text-2xl font-bold text-slate-900">{objective.progress}%</span>
          </div>
          <Progress 
            value={objective.progress} 
            className="h-3"
          />
        </div>

        <div className="flex items-center gap-2 text-sm text-slate-600 pt-2 border-t border-slate-100">
          <Key className="w-4 h-4 text-slate-400" />
          <span>
            {keyResults.length} resultado{keyResults.length !== 1 ? 's' : ''} chave
          </span>
        </div>
      </CardContent>
    </Card>
  );
}