import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Key, Zap, Calendar } from "lucide-react";

export default function StatsOverview({ objectives, keyResults, projects, sprints }) {
  const completedObjectives = objectives.filter(o => o.progress === 100).length;
  const onTrackKeyResults = keyResults.filter(kr => kr.progress >= 70).length;
  const doneProjects = projects.filter(p => p.status === 'done').length;
  const activeSprints = sprints.filter(s => s.status === 'active').length;

  const stats = [
    {
      title: "Objetivos Concluídos",
      value: completedObjectives,
      total: objectives.length,
      icon: Target,
      gradient: "from-green-500 to-green-600"
    },
    {
      title: "Resultados no Rumo",
      value: onTrackKeyResults,
      total: keyResults.length,
      icon: Key,
      gradient: "from-purple-500 to-purple-600"
    },
    {
      title: "Projetos Feitos",
      value: doneProjects,
      total: projects.length,
      icon: Zap,
      gradient: "from-orange-500 to-orange-600"
    },
    {
      title: "Sprints Ativos",
      value: activeSprints,
      total: sprints.length,
      icon: Calendar,
      gradient: "from-blue-500 to-blue-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat) => (
        <Card key={stat.title} className="bg-white/80 backdrop-blur-sm shadow-xl border-0 hover:shadow-2xl transition-all duration-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                <p className="text-sm text-slate-500">de {stat.total}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="font-medium text-slate-700">{stat.title}</p>
            <div className="mt-2 w-full bg-slate-200 rounded-full h-2">
              <div 
                className={`h-2 bg-gradient-to-r ${stat.gradient} rounded-full transition-all duration-500`}
                style={{ width: `${stat.total > 0 ? (stat.value / stat.total) * 100 : 0}%` }}
              />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}