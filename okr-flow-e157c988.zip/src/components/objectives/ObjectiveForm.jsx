import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";
import AISuggestButton from "../ai/AISuggestButton";

export default function ObjectiveForm({ objective, projects, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    project_id: objective?.project_id || "",
    title: objective?.title || "",
    description: objective?.description || "",
    quarter: objective?.quarter || "",
    year: objective?.year || new Date().getFullYear(),
    progress: objective?.progress || 0
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação: Projeto é obrigatório
    if (!formData.project_id) {
      alert("Por favor, selecione um projeto antes de criar o objetivo.");
      return;
    }
    
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const selectedProject = projects.find(p => p.id === formData.project_id);

  const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];
  const currentYear = new Date().getFullYear();
  const years = [currentYear - 1, currentYear, currentYear + 1, currentYear + 2];

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-900">
          {objective ? 'Editar Objetivo' : 'Novo Objetivo'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Projeto *
              </Label>
              <Select 
                value={formData.project_id} 
                onValueChange={(value) => handleChange('project_id', value)}
                required
              >
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue placeholder="Selecione o projeto" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!formData.project_id && (
                <p className="text-xs text-red-600">
                  ⚠️ Selecione um projeto para habilitar as sugestões de IA
                </p>
              )}
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="title" className="text-sm font-semibold text-slate-700">
                  Título do Objetivo *
                </Label>
                {formData.project_id && (
                  <AISuggestButton
                    type="objective_title"
                    context={{
                      project_name: selectedProject?.name,
                      quarter: formData.quarter,
                      year: formData.year
                    }}
                    onSuggestionSelect={(suggestion) => handleChange('title', suggestion)}
                  />
                )}
              </div>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleChange('title', e.target.value)}
                placeholder="Ex: Aumentar satisfação do cliente"
                required
                className="border-slate-200 focus:border-purple-500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="description" className="text-sm font-semibold text-slate-700">
                Descrição
              </Label>
              {formData.project_id && formData.title && (
                <AISuggestButton
                  type="objective_description"
                  context={{
                    objective_title: formData.title,
                    project_name: selectedProject?.name
                  }}
                  onSuggestionSelect={(suggestion) => handleChange('description', suggestion)}
                />
              )}
            </div>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descreva o objetivo de forma clara e específica..."
              rows={3}
              className="border-slate-200 focus:border-purple-500"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Trimestre *
              </Label>
              <Select 
                value={formData.quarter} 
                onValueChange={(value) => handleChange('quarter', value)}
                required
              >
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue placeholder="Selecione o trimestre" />
                </SelectTrigger>
                <SelectContent>
                  {quarters.map((quarter) => (
                    <SelectItem key={quarter} value={quarter}>
                      {quarter} - {
                        quarter === 'Q1' ? 'Jan-Mar' :
                        quarter === 'Q2' ? 'Abr-Jun' :
                        quarter === 'Q3' ? 'Jul-Set' : 'Out-Dez'
                      }
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Ano *
              </Label>
              <Select 
                value={formData.year.toString()} 
                onValueChange={(value) => handleChange('year', parseInt(value))}
                required
              >
                <SelectTrigger className="border-slate-200 focus:border-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {objective && (
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <p className="text-sm font-medium text-slate-700 mb-2">
                Progresso Atual: {formData.progress}%
              </p>
              <div className="w-full bg-slate-200 rounded-full h-3">
                <div 
                  className="h-3 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full transition-all duration-500"
                  style={{ width: `${formData.progress}%` }}
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">
                * O progresso é calculado automaticamente baseado nos resultados chave
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700">
              <Save className="w-4 h-4 mr-2" />
              Salvar Objetivo
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}