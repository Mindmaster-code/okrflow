
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Target } from "lucide-react";

export default function ObjectiveProgress({ objectives, keyResults }) {
  const getObjectiveKeyResults = (objectiveId) => {
    return keyResults.filter(kr => kr.objective_id === objectiveId);
  };

  const calculateObjectiveProgress = (objective) => {
    const objKeyResults = getObjectiveKeyResults(objective.id);
    if (objKeyResults.length === 0) return 0;
    
    const totalProgress = objKeyResults.reduce((sum, kr) => {
      // Ensure current_value and target_value are numbers and target_value is not zero
      const currentValue = typeof kr.current_value === 'number' ? kr.current_value : 0;
      const targetValue = typeof kr.target_value === 'number' && kr.target_value !== 0 ? kr.target_value : 1; // Avoid division by zero
      return sum + ((currentValue / targetValue) * 100);
    }, 0);
    
    return Math.min(100, Math.round(totalProgress / objKeyResults.length));
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-slate-900">
          <Target className="w-5 h-5 text-purple-600" />
          Progresso dos Objetivos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {objectives.slice(0, 5).map((objective) => {
            const progress = calculateObjectiveProgress(objective);
            const keyResultCount = getObjectiveKeyResults(objective.id).length;
            
            return (
              <div key={objective.id} className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold text-slate-900">{objective.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {objective.quarter} {objective.year}
                      </Badge>
                      <span className="text-xs text-slate-500">
                        {keyResultCount} resultado{keyResultCount !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                  <span className="text-2xl font-bold text-slate-900">{progress}%</span>
                </div>
                <Progress value={progress} className="h-3" />
              </div>
            );
          })}
          {objectives.length === 0 && (
            <p className="text-center text-slate-500 py-8">
              Nenhum objetivo encontrado
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
