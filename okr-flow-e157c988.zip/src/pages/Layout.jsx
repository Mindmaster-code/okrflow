
import React, { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { 
  Home, 
  FolderKanban, 
  Target, 
  Key, 
  Zap, 
  Calendar, 
  BarChart3,
  LogOut
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentPageName !== "Landing" && currentPageName !== "Home") {
      loadUser();
    } else {
      setLoading(false);
    }
  }, [currentPageName]);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const menuItems = [
    { name: "Dashboard", icon: Home, path: createPageUrl("Dashboard") },
    { name: "Projetos", icon: FolderKanban, path: createPageUrl("Projects") },
    { name: "Objetivos", icon: Target, path: createPageUrl("Objectives") },
    { name: "Key Results", icon: Key, path: createPageUrl("KeyResults") },
    { name: "Kanban", icon: Zap, path: createPageUrl("Initiatives") },
    { name: "Sprints", icon: Calendar, path: createPageUrl("Sprints") },
    { name: "Relatórios", icon: BarChart3, path: createPageUrl("Reports") }
  ];

  if (currentPageName === "Landing" || currentPageName === "Home") {
    return <>{children}</>;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-gray-600">Carregando...</div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <Sidebar className="border-r bg-white">
          <SidebarContent>
            <div className="p-6 border-b">
              <h1 className="text-xl font-bold">OKR Flow</h1>
            </div>

            <SidebarGroup>
              <SidebarGroupLabel>Navegação</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems.map((item) => {
                    const isActive = location.pathname === item.path;
                    return (
                      <SidebarMenuItem key={item.name}>
                        <SidebarMenuButton asChild isActive={isActive}>
                          <Link to={item.path} className="flex items-center gap-3 px-6 py-3">
                            <item.icon className="w-5 h-5" />
                            <span>{item.name}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {user && (
              <div className="mt-auto p-6 border-t">
                <p className="text-sm font-semibold truncate">{user.full_name || user.email}</p>
                <Button variant="outline" size="sm" onClick={handleLogout} className="w-full mt-2">
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </div>
            )}
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b px-6 py-4">
            <SidebarTrigger />
          </header>
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
