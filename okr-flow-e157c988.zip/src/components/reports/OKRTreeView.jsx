
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ChevronDown,
  ChevronRight,
  Target,
  Key,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  User,
  Download, // NEW: Import Download icon
} from "lucide-react";
import { format, parseISO } from "date-fns"; // NEW: Import parseISO
import { ptBR } from "date-fns/locale";
import { Button } from "@/components/ui/button"; // NEW: Import Button component

const getHealthColor = (progress) => {
  if (progress >= 80) return {
    bg: 'bg-green-50',
    border: 'border-green-200',
    text: 'text-green-700',
    icon: 'text-green-600',
    progress: 'bg-green-500',
    status: 'Excelente',
    badge: 'bg-green-100 text-green-700'
  };
  if (progress >= 70) return {
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    text: 'text-blue-700',
    icon: 'text-blue-600',
    progress: 'bg-blue-500',
    status: 'No Rumo',
    badge: 'bg-blue-100 text-blue-700'
  };
  if (progress >= 40) return {
    bg: 'bg-orange-50',
    border: 'border-orange-200',
    text: 'text-orange-700',
    icon: 'text-orange-600',
    progress: 'bg-orange-500',
    status: 'Atenção',
    badge: 'bg-orange-100 text-orange-700'
  };
  return {
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-700',
    icon: 'text-red-600',
    progress: 'bg-red-500',
    status: 'Risco',
    badge: 'bg-red-100 text-red-700'
  };
};

const getHealthIcon = (progress) => {
  if (progress >= 70) return CheckCircle2;
  if (progress >= 40) return TrendingUp;
  return AlertTriangle;
};

const KeyResultItem = ({ keyResult }) => {
  const health = getHealthColor(keyResult.progress);
  const HealthIcon = getHealthIcon(keyResult.progress);

  return (
    <div className={`ml-8 p-4 rounded-lg border ${health.bg} ${health.border} mb-3 hover:shadow-md transition-all`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start gap-3 flex-1">
          <div className={`mt-1 p-2 rounded-lg bg-white shadow-sm`}>
            <Key className={`w-4 h-4 ${health.icon}`} />
          </div>
          <div className="flex-1">
            <h4 className={`font-semibold ${health.text} mb-1`}>
              {keyResult.title}
            </h4>
            {keyResult.description && (
              <p className="text-sm text-slate-600 mb-2">{keyResult.description}</p>
            )}
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                <span>{keyResult.responsible}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>
                  {format(new Date(keyResult.start_date), "dd/MM", { locale: ptBR })} -
                  {format(new Date(keyResult.end_date), "dd/MM/yy", { locale: ptBR })}
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <HealthIcon className={`w-5 h-5 ${health.icon}`} />
          <div className="text-right">
            <p className={`text-2xl font-bold ${health.text}`}>
              {keyResult.progress}%
            </p>
            <p className="text-xs text-slate-500">
              {keyResult.current_value} / {keyResult.target_value} {keyResult.unit}
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Progress value={keyResult.progress} className="h-2" indicatorClassName={health.progress} />
        <div className="flex justify-between items-center">
          <Badge className={health.badge} variant="outline">
            {health.status}
          </Badge>
          <span className="text-xs text-slate-500 font-medium">
            Meta: {keyResult.target_value} {keyResult.unit}
          </span>
        </div>
      </div>
    </div>
  );
};

const ObjectiveNode = ({ objective, keyResults, projectName }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const health = getHealthColor(objective.progress);
  const HealthIcon = getHealthIcon(objective.progress);

  const completedKRs = keyResults.filter(kr => kr.progress >= 100).length;
  const atRiskKRs = keyResults.filter(kr => kr.progress < 40).length;

  return (
    <div className="mb-6">
      <div
        className={`p-5 rounded-xl border-2 ${health.border} ${health.bg} cursor-pointer hover:shadow-lg transition-all`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4 flex-1">
            <button
              className={`mt-1 p-2 rounded-lg ${health.badge} hover:opacity-80 transition-opacity`}
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(!isExpanded);
              }}
            >
              {isExpanded ? (
                <ChevronDown className={`w-5 h-5 ${health.text}`} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${health.text}`} />
              )}
            </button>

            <div className={`p-3 rounded-xl bg-white shadow-md`}>
              <Target className={`w-6 h-6 ${health.icon}`} />
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className={`text-xl font-bold ${health.text}`}>
                  {objective.title}
                </h3>
                <Badge className={health.badge}>
                  {objective.quarter} {objective.year}
                </Badge>
              </div>

              {objective.description && (
                <p className="text-slate-700 mb-3">{objective.description}</p>
              )}

              <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600">
                <div className="flex items-center gap-1">
                  <span className="font-medium">Projeto:</span>
                  <span>{projectName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{keyResults.length} KRs</span>
                  {completedKRs > 0 && (
                    <Badge className="bg-green-100 text-green-700 text-xs">
                      ✓ {completedKRs} concluído{completedKRs > 1 ? 's' : ''}
                    </Badge>
                  )}
                  {atRiskKRs > 0 && (
                    <Badge className="bg-red-100 text-red-700 text-xs">
                      ⚠ {atRiskKRs} em risco
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 ml-4">
            <HealthIcon className={`w-7 h-7 ${health.icon}`} />
            <div className="text-right">
              <p className={`text-4xl font-bold ${health.text}`}>
                {objective.progress}%
              </p>
              <Badge className={health.badge}>
                {health.status}
              </Badge>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <Progress value={objective.progress} className="h-3" indicatorClassName={health.progress} />
        </div>
      </div>

      {isExpanded && keyResults.length > 0 && (
        <div className="mt-3 ml-4 border-l-4 border-slate-200 pl-4">
          {keyResults.map(kr => (
            <KeyResultItem key={kr.id} keyResult={kr} />
          ))}
        </div>
      )}

      {isExpanded && keyResults.length === 0 && (
        <div className="ml-12 mt-3 p-4 bg-slate-50 rounded-lg border border-slate-200">
          <p className="text-sm text-slate-500 text-center">
            Nenhum resultado chave cadastrado para este objetivo
          </p>
        </div>
      )}
    </div>
  );
};

export default function OKRTreeView({ objectives, keyResults, projects }) {
  const handleExportPDF = () => {
    // Criar uma versão otimizada para impressão/PDF
    const printContent = document.getElementById('okr-tree-content');
    if (!printContent) return;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Relatório OKR - ${new Date().toLocaleDateString('pt-BR')}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
              font-family: system-ui, -apple-system, sans-serif;
              padding: 40px;
              background: white;
            }
            h1 {
              color: #1e293b;
              margin-bottom: 8px;
              font-size: 28px;
            }
            .header {
              border-bottom: 3px solid #8b5cf6;
              padding-bottom: 20px;
              margin-bottom: 30px;
            }
            .subtitle {
              color: #64748b;
              font-size: 14px;
            }
            .objective {
              page-break-inside: avoid;
              margin-bottom: 30px;
              border: 2px solid #e2e8f0;
              border-radius: 12px;
              padding: 20px;
              background: #f8fafc;
            }
            .objective-header {
              display: flex;
              justify-content: space-between;
              align-items: start;
              margin-bottom: 15px;
            }
            .objective-title {
              font-size: 20px;
              font-weight: bold;
              color: #1e293b;
              margin-bottom: 8px;
            }
            .objective-meta {
              font-size: 12px;
              color: #64748b;
              margin-bottom: 10px;
            }
            .objective-description {
              color: #475569;
              margin-bottom: 15px;
              font-size: 14px;
            }
            .progress-bar {
              height: 12px;
              background: #e2e8f0;
              border-radius: 6px;
              overflow: hidden;
              margin-bottom: 10px;
            }
            .progress-fill {
              height: 100%;
              transition: width 0.3s;
            }
            .progress-excellent { background: linear-gradient(to right, #10b981, #059669); }
            .progress-good { background: linear-gradient(to right, #3b82f6, #2563eb); }
            .progress-attention { background: linear-gradient(to right, #f59e0b, #d97706); }
            .progress-risk { background: linear-gradient(to right, #ef4444, #dc2626); }
            .progress-label {
              display: flex;
              justify-content: space-between;
              font-size: 12px;
              color: #64748b;
              margin-top: 5px;
            }
            .key-results {
              margin-left: 20px;
              margin-top: 20px;
            }
            .key-result {
              page-break-inside: avoid;
              margin-bottom: 15px;
              padding: 15px;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              background: white;
            }
            .kr-header {
              display: flex;
              justify-content: space-between;
              align-items: start;
              margin-bottom: 10px;
            }
            .kr-title {
              font-weight: 600;
              color: #1e293b;
              font-size: 15px;
              margin-bottom: 5px;
            }
            .kr-description {
              color: #64748b;
              font-size: 13px;
              margin-bottom: 10px;
            }
            .kr-meta {
              font-size: 11px;
              color: #94a3b8;
              margin-bottom: 8px;
            }
            .kr-progress {
              font-size: 24px;
              font-weight: bold;
            }
            .kr-values {
              font-size: 11px;
              color: #64748b;
              margin-top: 3px;
            }
            .stats-grid {
              display: grid;
              grid-template-columns: repeat(5, 1fr);
              gap: 15px;
              margin-bottom: 30px;
              page-break-inside: avoid;
            }
            .stat-card {
              text-align: center;
              padding: 15px;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              background: #f8fafc;
            }
            .stat-value {
              font-size: 28px;
              font-weight: bold;
              color: #1e293b;
              margin-bottom: 5px;
            }
            .stat-label {
              font-size: 11px;
              color: #64748b;
              text-transform: uppercase;
              font-weight: 600;
            }
            .footer {
              margin-top: 40px;
              padding-top: 20px;
              border-top: 2px solid #e2e8f0;
              text-align: center;
              color: #94a3b8;
              font-size: 11px;
            }
            @media print {
              body { padding: 20px; }
              .objective { page-break-inside: avoid; }
              .key-result { page-break-inside: avoid; }
            }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
          <div class="footer">
            Gerado por OKR Flow em ${new Date().toLocaleString('pt-BR')} • Documento confidencial
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  if (objectives.length === 0) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
        <CardContent className="py-16 text-center">
          <Target className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-600 mb-2">
            Nenhum objetivo encontrado
          </h3>
          <p className="text-slate-500">
            Crie objetivos para visualizar a árvore OKR
          </p>
        </CardContent>
      </Card>
    );
  }

  const getProjectName = (projectId) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : 'Projeto não encontrado';
  };

  const getObjectiveKeyResults = (objectiveId) => {
    return keyResults.filter(kr => kr.objective_id === objectiveId);
  };

  // Estatísticas gerais
  const totalKRs = keyResults.length;
  const completedKRs = keyResults.filter(kr => kr.progress >= 100).length;
  const onTrackKRs = keyResults.filter(kr => kr.progress >= 70 && kr.progress < 100).length;
  const atRiskKRs = keyResults.filter(kr => kr.progress < 40).length;
  const avgProgress = objectives.length > 0
    ? Math.round(objectives.reduce((sum, obj) => sum + obj.progress, 0) / objectives.length)
    : 0;

  // Helper to map Tailwind text classes to hex colors for print
  const getPrintTextColor = (healthTextClass) => {
    if (healthTextClass.includes('green')) return '#047857'; // Tailwind green-700
    if (healthTextClass.includes('blue')) return '#1d4ed8'; // Tailwind blue-700
    if (healthTextClass.includes('orange')) return '#c2410c'; // Tailwind orange-700
    if (healthTextClass.includes('red')) return '#b91c1c'; // Tailwind red-700
    return '#1e293b'; // default slate-800 or similar
  };

  return (
    <div className="space-y-6">
      {/* Botão de Exportação */}
      <div className="flex justify-end">
        <Button
          onClick={handleExportPDF}
          className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 gap-2 shadow-lg"
        >
          <Download className="w-4 h-4" />
          Exportar Relatório em PDF
        </Button>
      </div>

      {/* Conteúdo para exportação - Hidden by default, shown only during print */}
      <div id="okr-tree-content" className="hidden print:block">
        <div className="header">
          <h1>Árvore de Objetivos e Resultados Chave (OKR)</h1>
          <div className="subtitle">
            Gerado em {format(new Date(), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
          </div>
        </div>

        {/* Dashboard de Estatísticas para Impressão */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-value" style={{ color: '#8b5cf6' }}>{objectives.length}</div>
            <div className="stat-label">Objetivos</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: '#7c3aed' }}>{totalKRs}</div>
            <div className="stat-label">Key Results</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: '#10b981' }}>{completedKRs}</div>
            <div className="stat-label">Concluídos</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: '#06b6d4' }}>{onTrackKRs}</div>
            <div className="stat-label">No Rumo</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: '#ef4444' }}>{atRiskKRs}</div>
            <div className="stat-label">Em Risco</div>
          </div>
        </div>

        {/* Progresso Geral para Impressão */}
        <div className="objective" style={{ background: 'linear-gradient(to right, #f8fafc, #ede9fe)' }}>
          <div className="objective-title">📊 Progresso Geral dos OKRs</div>
          <div className="progress-bar">
            <div
              className={`progress-fill ${
                avgProgress >= 80 ? 'progress-excellent' :
                avgProgress >= 70 ? 'progress-good' : // Adjusted to match getHealthColor thresholds
                avgProgress >= 40 ? 'progress-attention' : 'progress-risk'
              }`}
              style={{ width: `${avgProgress}%` }}
            ></div>
          </div>
          <div className="progress-label">
            <span>Média dos Objetivos</span>
            <span style={{ fontWeight: 'bold', fontSize: '14px' }}>{avgProgress}%</span>
          </div>
        </div>

        {/* Árvore OKR para Impressão */}
        {objectives
          .sort((a, b) => b.progress - a.progress)
          .map(objective => {
            const objKeyResults = getObjectiveKeyResults(objective.id);
            const health = getHealthColor(objective.progress);
            const projectName = getProjectName(objective.project_id);
            const objectivePrintColor = getPrintTextColor(health.text);

            return (
              <div key={objective.id} className="objective">
                <div className="objective-header">
                  <div style={{ flex: 1 }}>
                    <div className="objective-title">{objective.title}</div>
                    <div className="objective-meta">
                      {projectName} • {objective.quarter} {objective.year} • {objKeyResults.length} Key Results
                    </div>
                    {objective.description && (
                      <div className="objective-description">{objective.description}</div>
                    )}
                  </div>
                  <div style={{ textAlign: 'right', minWidth: '80px' }}>
                    <div className="kr-progress" style={{ color: objectivePrintColor }}>
                      {objective.progress}%
                    </div>
                    <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>
                      {health.status}
                    </div>
                  </div>
                </div>

                <div className="progress-bar">
                  <div
                    className={`progress-fill ${
                      objective.progress >= 80 ? 'progress-excellent' :
                      objective.progress >= 70 ? 'progress-good' :
                      objective.progress >= 40 ? 'progress-attention' : 'progress-risk'
                    }`}
                    style={{ width: `${objective.progress}%` }}
                  ></div>
                </div>

                {objKeyResults.length > 0 && (
                  <div className="key-results">
                    {objKeyResults.map(kr => {
                      const krHealth = getHealthColor(kr.progress);
                      const krPrintColor = getPrintTextColor(krHealth.text);
                      return (
                        <div key={kr.id} className="key-result">
                          <div className="kr-header">
                            <div style={{ flex: 1 }}>
                              <div className="kr-title">{kr.title}</div>
                              {kr.description && (
                                <div className="kr-description">{kr.description}</div>
                              )}
                              <div className="kr-meta">
                                👤 {kr.responsible} • 📅 {format(parseISO(kr.start_date), 'dd/MM', { locale: ptBR })} - {format(parseISO(kr.end_date), 'dd/MM/yy', { locale: ptBR })}
                              </div>
                            </div>
                            <div style={{ textAlign: 'right', minWidth: '70px' }}>
                              <div className="kr-progress" style={{ color: krPrintColor }}>
                                {kr.progress}%
                              </div>
                              <div className="kr-values">
                                {kr.current_value} / {kr.target_value} {kr.unit}
                              </div>
                            </div>
                          </div>
                          <div className="progress-bar" style={{ height: '8px' }}>
                            <div
                              className={`progress-fill ${
                                kr.progress >= 80 ? 'progress-excellent' :
                                kr.progress >= 70 ? 'progress-good' :
                                kr.progress >= 40 ? 'progress-attention' : 'progress-risk'
                              }`}
                              style={{ width: `${kr.progress}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
      </div>

      {/* Interactive view for screen - visible by default, hidden during print */}
      <div className="print:hidden">
        {/* Dashboard de Estatísticas */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-blue-900">{objectives.length}</p>
              <p className="text-xs text-blue-700 font-medium">Objetivos</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <Key className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-purple-900">{totalKRs}</p>
              <p className="text-xs text-purple-700 font-medium">Key Results</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-green-900">{completedKRs}</p>
              <p className="text-xs text-green-700 font-medium">Concluídos</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-cyan-100 border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-cyan-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-cyan-900">{onTrackKRs}</p>
              <p className="text-xs text-cyan-700 font-medium">No Rumo</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-50 to-red-100 border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-red-900">{atRiskKRs}</p>
              <p className="text-xs text-red-700 font-medium">Em Risco</p>
            </CardContent>
          </Card>
        </div>

        {/* Progresso Geral */}
        <Card className="bg-gradient-to-r from-slate-50 to-blue-50 border-0 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-900">Progresso Geral</h3>
              <div className="text-right">
                <p className="text-4xl font-bold text-blue-600">{avgProgress}%</p>
                <p className="text-sm text-slate-600">Média dos Objetivos</p>
              </div>
            </div>
            <Progress value={avgProgress} className="h-4" />
          </CardContent>
        </Card>

        {/* Árvore OKR */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-6 h-6 text-blue-600" />
              Árvore de Objetivos e Resultados Chave
            </CardTitle>
            <p className="text-sm text-slate-600 mt-2">
              Clique nos objetivos para expandir/recolher os resultados chave
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {objectives
              .sort((a, b) => b.progress - a.progress)
              .map(objective => (
                <ObjectiveNode
                  key={objective.id}
                  objective={objective}
                  keyResults={getObjectiveKeyResults(objective.id)}
                  projectName={getProjectName(objective.project_id)}
                />
              ))}
          </CardContent>
        </Card>

        {/* Legenda */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
          <CardContent className="p-6">
            <h4 className="font-semibold text-slate-900 mb-4">Legenda de Status</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-green-500"></div>
                <div>
                  <p className="font-medium text-sm">Excelente</p>
                  <p className="text-xs text-slate-500">≥ 80%</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-blue-500"></div>
                <div>
                  <p className="font-medium text-sm">No Rumo</p>
                  <p className="text-xs text-slate-500">70-79%</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-orange-500"></div>
                <div>
                  <p className="font-medium text-sm">Atenção</p>
                  <p className="text-xs text-slate-500">40-69%</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-red-500"></div>
                <div>
                  <p className="font-medium text-sm">Risco</p>
                  <p className="text-xs text-slate-500">&lt; 40%</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
