import React, { useState, useEffect } from "react";
import { Objective, KeyResult, Project, Sprint } from "@/api/entities";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Target, Key, Zap, Calendar, TrendingUp, RefreshCw } from "lucide-react";

import StatsOverview from "../components/dashboard/StatsOverview";
import ObjectiveProgress from "../components/dashboard/ObjectiveProgress";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [objectives, setObjectives] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [projects, setProjects] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
    
    const interval = setInterval(() => {
      loadData(true);
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const loadData = async (silent = false) => {
    if (!silent) setLoading(true);
    if (silent) setRefreshing(true);
    
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      const objectivesData = await Objective.filter({ created_by: userData.email });
      const objectiveIds = objectivesData.map(obj => obj.id);
      
      const allKeyResults = await KeyResult.list();
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
      const keyResultIds = keyResultsData.map(kr => kr.id);
      
      const allProjects = await Project.list();
      const projectsData = allProjects.filter(proj => keyResultIds.includes(proj.key_result_id));
      
      const sprintsData = await Sprint.filter({ created_by: userData.email });

      setObjectives(objectivesData);
      setKeyResults(keyResultsData);
      setProjects(projectsData);
      setSprints(sprintsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleManualRefresh = () => {
    loadData();
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-64 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-32 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              Dashboard OKR Flow
            </h1>
            <p className="text-slate-600 text-lg">
              {user?.company ? `${user.company} - ` : ''}Visão geral dos seus objetivos
            </p>
          </div>
          <Button
            onClick={handleManualRefresh}
            disabled={refreshing}
            variant="outline"
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        <StatsOverview 
          objectives={objectives}
          keyResults={keyResults}
          projects={projects}
          sprints={sprints}
        />

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <ObjectiveProgress objectives={objectives} keyResults={keyResults} />
          
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-slate-900">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Atividade Recente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {projects.slice(0, 5).map((project) => (
                  <div key={project.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50">
                    <div className={`w-3 h-3 rounded-full ${
                      project.status === 'done' ? 'bg-green-500' :
                      project.status === 'doing' ? 'bg-blue-500' : 'bg-slate-300'
                    }`}></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm text-slate-900">{project.title}</p>
                      <p className="text-xs text-slate-500">{project.responsible}</p>
                    </div>
                  </div>
                ))}
                {projects.length === 0 && (
                  <p className="text-center text-slate-500 py-4">Nenhum projeto recente</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sprint Status Card */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-900">
              <Calendar className="w-5 h-5 text-orange-600" />
              Status dos Sprints
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sprints.slice(0, 6).map((sprint) => {
                const sprintProjects = projects.filter(p => p.sprint_id === sprint.id);
                const completedProjects = sprintProjects.filter(p => p.status === 'done').length;
                const progress = sprintProjects.length > 0 
                  ? Math.round((completedProjects / sprintProjects.length) * 100)
                  : 0;
                
                return (
                  <div key={sprint.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-slate-900">{sprint.name}</h4>
                        <p className="text-xs text-slate-500">
                          {sprintProjects.length} projeto{sprintProjects.length !== 1 ? 's' : ''}
                        </p>
                      </div>
                      <span className="font-semibold text-slate-900">
                        {progress}% concluído
                      </span>
                    </div>
                    
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div 
                        className="h-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              {sprints.length === 0 && (
                <p className="text-center text-slate-500 py-8">
                  Nenhum sprint encontrado
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}