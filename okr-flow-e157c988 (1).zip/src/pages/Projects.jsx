
import React, { useState, useEffect, useCallback } from "react";
import { Project, Objective, Sprint, KeyResult } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Zap, Eye, Building2, Database } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import KanbanBoard from "../components/projects/KanbanBoard";
import ProjectForm from "../components/projects/ProjectForm";
import ProjectFilters from "../components/projects/ProjectFilters";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [filters, setFilters] = useState({
    objective: 'all',
    sprint: 'all',
    priority: 'all',
    responsible: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  const loadData = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let objectivesData;
      let keyResultsData;
      let projectsData;
      let sprintsData;

      if (userData.role === 'admin' && showAllUsers) {
        // ADMIN: Carregar TUDO
        const allObjectives = await Objective.list('-created_date');
        const allKeyResults = await KeyResult.list();
        const allProjects = await Project.list('-created_date');
        const allSprints = await Sprint.list();
        const allUsersData = await User.list();
        
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const companies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(companies);

        // Determine users for the "Filter by user" dropdown
        let usersForUserDropdown = [];
        if (selectedCompany === 'all') {
            usersForUserDropdown = allUsersData.map(u => u.email);
        } else {
            usersForUserDropdown = Object.keys(companyMap).filter(email => companyMap[email] === selectedCompany);
        }
        setAllUsers(usersForUserDropdown); // This sets the dropdown options

        // Determine the actual scope of users whose data we want to load
        let usersInScopeForDataLoading = [...usersForUserDropdown]; // Start with users from the selected company (or all)
        if (selectedUser !== 'all') {
          usersInScopeForDataLoading = [selectedUser]; // If a specific user is selected, override the scope
        }

        // Carregar dados dos usuários no escopo
        objectivesData = allObjectives.filter(o => usersInScopeForDataLoading.includes(o.created_by));
        keyResultsData = allKeyResults.filter(kr => 
          objectivesData.some(obj => obj.id === kr.objective_id)
        );
        projectsData = allProjects.filter(proj => usersInScopeForDataLoading.includes(proj.created_by));
        sprintsData = allSprints.filter(spr => usersInScopeForDataLoading.includes(spr.created_by));
        
      } else {
        // Usuário normal - APENAS seus dados
        const allProjects = await Project.list('-created_date');
        projectsData = allProjects.filter(proj => proj.created_by === userData.email);
        
        const allObjectives = await Objective.list('-created_date');
        objectivesData = allObjectives.filter(o => o.created_by === userData.email);
        
        const allKeyResults = await KeyResult.list();
        const objectiveIds = objectivesData.map(o => o.id);
        keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        
        const allSprints = await Sprint.list();
        sprintsData = allSprints.filter(spr => spr.created_by === userData.email);
        
        setAllCompanies([]);
        setAllUsers([]);
        setSelectedCompany('all');
        setSelectedUser('all');
      }

      setProjects(projectsData);
      setObjectives(objectivesData);
      setSprints(sprintsData);
      setKeyResults(keyResultsData);
      
      console.log('📊 PROJETOS CARREGADOS:', {
        total_projetos: projectsData.length,
        projetos_detalhes: projectsData.map(p => ({
          id: p.id,
          title: p.title,
          created_by: p.created_by,
          key_result_id: p.key_result_id
        })),
        objetivos: objectivesData.length,
        keyResults: keyResultsData.length,
        sprints: sprintsData.length
      });
      
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, [showAllUsers, selectedCompany, selectedUser]);

  useEffect(() => {
    loadData();
    
    const interval = setInterval(() => {
      loadData();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [loadData]);

  const handleSubmit = async (projectData) => {
    try {
      if (editingProject) {
        await Project.update(editingProject.id, projectData);
      } else {
        await Project.create({ ...projectData, order: 0, status: projectData.status || 'todo' });
      }
      setShowForm(false);
      setEditingProject(null);
      loadData();
    } catch (error) {
      console.error('Error saving project:', error);
    }
  };

  const handleStatusUpdate = async (projectId, newStatus, newIndex) => {
    try {
      const project = projects.find(p => p.id === projectId);
      if (!project) return;
      
      if (!project.key_result_id) {
        alert('Este projeto precisa ser editado para ter um resultado chave associado antes de ser movido.');
        loadData();
        return;
      }
      
      const movedProject = { ...project, status: newStatus };

      const projectsInOldStatus = projects
        .filter(p => p.status === project.status && p.id !== projectId)
        .sort((a, b) => (a.order || 0) - (b.order || 0))
        .map((p, idx) => ({ ...p, order: idx }));

      const projectsInNewStatus = projects
        .filter(p => p.status === newStatus && p.id !== projectId)
        .sort((a, b) => (a.order || 0) - (b.order || 0));

      const newStatusColumnWithMoved = [...projectsInNewStatus];
      newStatusColumnWithMoved.splice(newIndex, 0, movedProject);

      const newStatusColumnWithOrders = newStatusColumnWithMoved.map((p, idx) => ({ ...p, order: idx }));

      const finalOptimisticState = [
        ...projectsInOldStatus,
        ...newStatusColumnWithOrders,
        ...projects.filter(p => p.status !== project.status && p.status !== newStatus)
      ];

      setProjects(finalOptimisticState);
      
      const updates = finalOptimisticState
        .filter(p => (p.status === project.status && p.id !== projectId) || p.status === newStatus)
        .map(proj => {
          if (!proj.key_result_id) {
            console.warn(`Project ${proj.id} missing key_result_id during API update, skipping:`, proj);
            return null;
          }
          return Project.update(proj.id, {
            key_result_id: proj.key_result_id,
            sprint_id: proj.sprint_id || null,
            title: proj.title,
            description: proj.description || '',
            responsible: proj.responsible,
            start_date: proj.start_date,
            end_date: proj.end_date,
            priority: proj.priority,
            status: proj.status, 
            order: proj.order
          });
        }).filter(Boolean);
      
      await Promise.all(updates);
      
    } catch (error) {
      console.error('Error updating project status:', error);
      alert('Erro ao atualizar status do projeto. Verifique se todos têm um resultado chave associado.');
      loadData();
    }
  };

  const handleReorder = async (projectId, status, oldIndex, newIndex) => {
    try {
      const statusProjects = projects
        .filter(p => p.status === status)
        .sort((a, b) => (a.order || 0) - (b.order || 0));
      
      const movedProject = statusProjects.find(p => p.id === projectId);
      
      if (!movedProject) return;
      if (!movedProject.key_result_id) {
        alert(`O projeto "${movedProject.title}" não pode ser reordenado porque não tem um resultado chave associado. Edite-o para corrigir.`);
        loadData();
        return;
      }
      
      const reorderedArray = [...statusProjects];
      const [itemToMove] = reorderedArray.splice(oldIndex, 1);
      reorderedArray.splice(newIndex, 0, itemToMove);
      
      const reorderedColumnWithNewOrders = reorderedArray.map((proj, idx) => ({ ...proj, order: idx }));

      const finalOptimisticState = projects.map(proj => {
        const updatedItem = reorderedColumnWithNewOrders.find(r => r.id === proj.id);
        if (updatedItem) {
          return updatedItem;
        }
        return proj;
      });

      setProjects(finalOptimisticState);
      
      const updates = reorderedColumnWithNewOrders.map(proj => {
        if (!proj.key_result_id) {
          console.warn(`Project ${proj.id} missing key_result_id during API update, skipping:`, proj);
          return null;
        }
        return Project.update(proj.id, {
          key_result_id: proj.key_result_id,
          sprint_id: proj.sprint_id || null,
          title: proj.title,
          description: proj.description || '',
          responsible: proj.responsible,
          start_date: proj.start_date,
          end_date: proj.end_date,
          priority: proj.priority,
          status: proj.status,
          order: proj.order
        });
      }).filter(Boolean);
      
      await Promise.all(updates);
      
    } catch (error) {
      console.error('Error reordering projects:', error);
      alert('Erro ao reordenar projetos. Verifique se todos têm um resultado chave associado.');
      loadData();
    }
  };

  const handleEdit = (project) => {
    setEditingProject(project);
    setShowForm(true);
  };

  const handleDelete = async (projectId) => {
    if (window.confirm('Tem certeza que deseja excluir este projeto?')) {
      try {
        await Project.delete(projectId);
        loadData();
      } catch (error) {
        console.error('Error deleting project:', error);
      }
    }
  };

  const getFilteredProjects = () => {
    let filtered = [...projects];
    
    console.log('🔍 FILTRANDO PROJETOS:', {
      total_antes_filtro: filtered.length,
      filtros: filters
    });
    
    // Filtro por objetivo
    if (filters.objective !== 'all') {
      const relevantKeyResultIds = keyResults
        .filter(kr => kr.objective_id === filters.objective)
        .map(kr => kr.id);
      filtered = filtered.filter(p => relevantKeyResultIds.includes(p.key_result_id));
      console.log('  → Após filtro objetivo:', filtered.length);
    }

    // Filtro por sprint
    if (filters.sprint !== 'all') {
      if (filters.sprint === 'none') {
        filtered = filtered.filter(p => !p.sprint_id);
      } else {
        filtered = filtered.filter(p => p.sprint_id === filters.sprint);
      }
      console.log('  → Após filtro sprint:', filtered.length);
    }

    // Filtro por prioridade
    if (filters.priority !== 'all') {
      filtered = filtered.filter(p => p.priority === filters.priority);
      console.log('  → Após filtro prioridade:', filtered.length);
    }

    // Filtro por responsável
    if (filters.responsible !== 'all') {
      filtered = filtered.filter(p => p.responsible === filters.responsible);
      console.log('  → Após filtro responsável:', filtered.length);
    }

    filtered = filtered.sort((a, b) => {
      if (a.status !== b.status) return 0;
      return (a.order || 0) - (b.order || 0);
    });

    console.log('  ✅ TOTAL APÓS FILTROS:', filtered.length);
    return filtered;
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid grid-cols-3 gap-6">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-96 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Projetos</h1>
              <p className="text-slate-600">Quadro Kanban para gerenciar suas ações</p>
            </div>
          </div>
          <Button 
            onClick={() => {
              setEditingProject(null);
              setShowForm(true);
            }}
            className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Projeto
          </Button>
        </div>

        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-projects"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all');
                      setSelectedUser('all');
                    }}
                  />
                  <Label htmlFor="show-all-projects" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-orange-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all');
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <ProjectForm
              project={editingProject}
              objectives={objectives}
              keyResults={keyResults}
              sprints={sprints}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingProject(null);
              }}
            />
          </div>
        )}

        <ProjectFilters
          filters={filters}
          onFiltersChange={setFilters}
          objectives={objectives}
          sprints={sprints}
          projects={projects}
        />

        <KanbanBoard
          projects={getFilteredProjects()}
          objectives={objectives}
          keyResults={keyResults}
          sprints={sprints}
          onStatusUpdate={handleStatusUpdate}
          onReorder={handleReorder}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
}
