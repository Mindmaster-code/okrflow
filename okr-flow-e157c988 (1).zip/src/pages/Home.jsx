import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import Landing from "./Landing";
import { Loader2 } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      
      if (isAuth) {
        // Usuário logado -> redireciona pro Dashboard
        navigate(createPageUrl("Dashboard"), { replace: true });
      } else {
        // Usuário deslogado -> mostra Landing (sem Layout)
        setChecking(false);
      }
    } catch (error) {
      console.error("Auth check error:", error);
      setChecking(false);
    }
  };

  if (checking) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-400 animate-spin mx-auto mb-4" />
          <p className="text-slate-300 text-lg">Carregando OKR Flow...</p>
        </div>
      </div>
    );
  }

  // Renderiza Landing sem Layout
  // O Layout só deve aparecer quando o usuário estiver logado
  return <Landing />;
}