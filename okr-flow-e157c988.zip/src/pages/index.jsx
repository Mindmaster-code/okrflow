import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Projects from "./Projects";

import Initiatives from "./Initiatives";

import Objectives from "./Objectives";

import KeyResults from "./KeyResults";

import Sprints from "./Sprints";

import Reports from "./Reports";

import Home from "./Home";

import Profile from "./Profile";

import Landing from "./Landing";

import DiagnosticTest from "./DiagnosticTest";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Projects: Projects,
    
    Initiatives: Initiatives,
    
    Objectives: Objectives,
    
    KeyResults: KeyResults,
    
    Sprints: Sprints,
    
    Reports: Reports,
    
    Home: Home,
    
    Profile: Profile,
    
    Landing: Landing,
    
    DiagnosticTest: DiagnosticTest,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Projects" element={<Projects />} />
                
                <Route path="/Initiatives" element={<Initiatives />} />
                
                <Route path="/Objectives" element={<Objectives />} />
                
                <Route path="/KeyResults" element={<KeyResults />} />
                
                <Route path="/Sprints" element={<Sprints />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/DiagnosticTest" element={<DiagnosticTest />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}