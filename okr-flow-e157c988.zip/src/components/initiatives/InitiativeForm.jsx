
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";
import AISuggestButton from "../ai/AISuggestButton";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function InitiativeForm({ 
  initiative, 
  objectives, 
  keyResults,
  sprints, 
  onSubmit, 
  onCancel 
}) {
  const [formData, setFormData] = useState({
    key_result_id: initiative?.key_result_id || "",
    sprint_id: initiative?.sprint_id || "",
    title: initiative?.title || "",
    description: initiative?.description || "",
    responsible: initiative?.responsible || "",
    start_date: initiative?.start_date || "",
    end_date: initiative?.end_date || "",
    status: initiative?.status || "todo",
    priority: initiative?.priority || "medium"
  });
  
  const [selectedObjectiveId, setSelectedObjectiveId] = useState("");

  useEffect(() => {
    if (initiative?.key_result_id) {
      const relatedKr = keyResults.find(kr => kr.id === initiative.key_result_id);
      if (relatedKr) {
        setSelectedObjectiveId(relatedKr.objective_id);
      }
    }
  }, [initiative, keyResults]);

  // Verificar se o sprint atual pertence a outro projeto (inconsistência)
  const checkSprintInconsistency = () => {
    if (!formData.key_result_id || !formData.sprint_id) return null;
    
    const selectedKR = keyResults.find(kr => kr.id === formData.key_result_id);
    if (!selectedKR) return null;
    
    const selectedObjective = objectives.find(obj => obj.id === selectedKR.objective_id);
    if (!selectedObjective) return null;
    
    const currentSprint = sprints.find(s => s.id === formData.sprint_id);
    if (!currentSprint) return null;
    
    // Se o sprint NÃO é do mesmo projeto, há inconsistência
    if (currentSprint.project_id !== selectedObjective.project_id) {
      return {
        sprintName: currentSprint.name,
        currentProjectId: currentSprint.project_id,
        expectedProjectId: selectedObjective.project_id
      };
    }
    
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleObjectiveChange = (objectiveId) => {
    setSelectedObjectiveId(objectiveId);
    handleChange('key_result_id', '');
    handleChange('start_date', '');
    handleChange('end_date', '');
    handleChange('sprint_id', ''); // Clear sprint when objective changes
  };

  const handleInitiativeSuggestion = (suggestion) => {
    setFormData(prev => ({
      ...prev,
      title: suggestion.title,
      description: suggestion.description,
      priority: suggestion.priority
    }));
  };

  const getKeyResultDates = () => {
    const selectedKeyResult = keyResults.find(kr => kr.id === formData.key_result_id);
    if (!selectedKeyResult) return null;
    
    return {
      start: selectedKeyResult.start_date,
      end: selectedKeyResult.end_date
    };
  };

  // Obter sprints disponíveis + sprint atual (se houver)
  const getAvailableSprints = () => {
    if (!formData.key_result_id) return [];
    
    const selectedKR = keyResults.find(kr => kr.id === formData.key_result_id);
    if (!selectedKR) return [];
    
    const selectedObjective = objectives.find(obj => obj.id === selectedKR.objective_id);
    if (!selectedObjective) return [];
    
    // Sprints do mesmo projeto
    const projectSprints = sprints.filter(sprint => sprint.project_id === selectedObjective.project_id);
    
    // Se há um sprint atual de outro projeto, incluir ele também (para permitir ver e trocar)
    if (formData.sprint_id) {
      const currentSprint = sprints.find(s => s.id === formData.sprint_id);
      if (currentSprint && currentSprint.project_id !== selectedObjective.project_id) {
        // Adicionar o sprint "errado" com indicação
        // Ensure uniqueness if for some reason currentSprint is already in projectSprints (unlikely given the condition)
        if (!projectSprints.some(s => s.id === currentSprint.id)) {
            return [...projectSprints, currentSprint];
        }
      }
    }
    
    return projectSprints;
  };

  const keyResultDates = getKeyResultDates();
  const filteredKeyResults = keyResults.filter(kr => kr.objective_id === selectedObjectiveId);
  const selectedKeyResult = keyResults.find(kr => kr.id === formData.key_result_id);
  const selectedObjective = objectives.find(obj => obj.id === selectedObjectiveId);
  const availableSprints = getAvailableSprints();
  const sprintInconsistency = checkSprintInconsistency();

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">
            {initiative ? 'Editar Iniciativa' : 'Nova Iniciativa'}
          </CardTitle>
          {formData.key_result_id && (
            <AISuggestButton
              type="initiatives"
              context={{
                key_result_title: selectedKeyResult?.title,
                objective_title: selectedObjective?.title
              }}
              onSuggestionSelect={handleInitiativeSuggestion}
              variant="default"
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
            />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Objetivo Pai *
              </Label>
              <Select 
                value={selectedObjectiveId} 
                onValueChange={handleObjectiveChange}
                required
              >
                <SelectTrigger className="border-slate-200 focus:border-orange-500">
                  <SelectValue placeholder="Selecione o objetivo pai" />
                </SelectTrigger>
                <SelectContent>
                  {objectives.map((objective) => (
                    <SelectItem key={objective.id} value={objective.id}>
                      {objective.title} ({objective.quarter} {objective.year})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Resultado Chave *
              </Label>
              <Select 
                value={formData.key_result_id} 
                onValueChange={(value) => handleChange('key_result_id', value)}
                required
                disabled={!selectedObjectiveId}
              >
                <SelectTrigger className="border-slate-200 focus:border-orange-500">
                  <SelectValue placeholder="Selecione o resultado chave" />
                </SelectTrigger>
                <SelectContent>
                  {filteredKeyResults.map((kr) => (
                    <SelectItem key={kr.id} value={kr.id}>
                      {kr.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-700">Sprint (Opcional)</Label>
            
            {sprintInconsistency && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-2">
                <p className="text-xs text-red-800 font-medium mb-1">
                  ⚠️ Inconsistência Detectada
                </p>
                <p className="text-xs text-red-700">
                  Esta iniciativa está no sprint "{sprintInconsistency.sprintName}" que pertence a outro projeto. 
                  Recomendamos mover para um sprint correto ou remover o sprint.
                </p>
              </div>
            )}
            
            <Select 
              value={formData.sprint_id || "none"} 
              onValueChange={(value) => handleChange('sprint_id', value === "none" ? null : value)}
              disabled={!formData.key_result_id}
            >
              <SelectTrigger className={`border-slate-200 focus:border-orange-500 ${sprintInconsistency ? 'border-red-300' : ''}`}>
                <SelectValue placeholder={
                  !formData.key_result_id 
                    ? "Selecione um Key Result primeiro" 
                    : availableSprints.length === 0
                    ? "Nenhum sprint disponível"
                    : "Selecione um sprint"
                } />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sem sprint (Backlog)</SelectItem>
                {availableSprints.map((sprint) => {
                  const isCurrentWrongSprint = formData.sprint_id === sprint.id && sprintInconsistency;
                  return (
                    <SelectItem key={sprint.id} value={sprint.id}>
                      {sprint.name} ({format(new Date(sprint.start_date), 'dd/MM', { locale: ptBR })} - {format(new Date(sprint.end_date), 'dd/MM/yy', { locale: ptBR })})
                      {isCurrentWrongSprint && " ⚠️ Projeto diferente"}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            
            {formData.key_result_id && availableSprints.length === 0 && (
              <p className="text-xs text-amber-600">
                ⚠️ Não há sprints criados para o projeto deste objetivo.
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-semibold text-slate-700">
              Título *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange('title', e.target.value)}
              placeholder="Ex: Implementar sistema de pagamento"
              required
              className="border-slate-200 focus:border-orange-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-semibold text-slate-700">
              Descrição
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descreva os detalhes da iniciativa..."
              rows={3}
              className="border-slate-200 focus:border-orange-500"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="responsible" className="text-sm font-semibold text-slate-700">
                Responsável *
              </Label>
              <Input
                id="responsible"
                value={formData.responsible}
                onChange={(e) => handleChange('responsible', e.target.value)}
                placeholder="Nome do responsável"
                required
                className="border-slate-200 focus:border-orange-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Prioridade
              </Label>
              <Select value={formData.priority} onValueChange={(value) => handleChange('priority', value)}>
                <SelectTrigger className="border-slate-200 focus:border-orange-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baixa</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="critical">Crítica</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="start_date" className="text-sm font-semibold text-slate-700">
                Data de Início *
              </Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => handleChange('start_date', e.target.value)}
                required
                min={keyResultDates?.start}
                max={keyResultDates?.end}
                className="border-slate-200 focus:border-orange-500"
                disabled={!formData.key_result_id}
              />
              {keyResultDates && (
                <p className="text-xs text-slate-500">
                  Período do KR: {keyResultDates.start} a {keyResultDates.end}
                </p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="end_date" className="text-sm font-semibold text-slate-700">
                Data de Fim *
              </Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date}
                onChange={(e) => handleChange('end_date', e.target.value)}
                required
                min={formData.start_date || keyResultDates?.start}
                max={keyResultDates?.end}
                className="border-slate-200 focus:border-orange-500"
                disabled={!formData.key_result_id}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-semibold text-slate-700">
                Status
              </Label>
              <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                <SelectTrigger className="border-slate-200 focus:border-orange-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todo">A Fazer</SelectItem>
                  <SelectItem value="doing">Fazendo</SelectItem>
                  <SelectItem value="done">Feito</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
              <Save className="w-4 h-4 mr-2" />
              Salvar Iniciativa
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
