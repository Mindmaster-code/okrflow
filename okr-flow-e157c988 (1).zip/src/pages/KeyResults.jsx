
import React, { useState, useEffect } from "react";
import { KeyResult, Objective, Project } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Key, Eye, Building2 } from "lucide-react"; // Import Eye icon and Building2

import KeyResultForm from "../components/keyresults/KeyResultForm";
import KeyResultCard from "../components/keyresults/KeyResultCard";
import KeyResultFilters from "../components/keyresults/KeyResultFilters";

// New imports for admin filter UI
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";


export default function KeyResults() {
  const [keyResults, setKeyResults] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [projects, setProjects] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingKeyResult, setEditingKeyResult] = useState(null);
  const [filters, setFilters] = useState({
    project: 'all',
    objective: 'all',
    status: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // New states for admin filter
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedUser, setSelectedUser] = useState('all');
  const [allUsers, setAllUsers] = useState([]);
  // New states for company filter
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  useEffect(() => {
    loadData();
  }, [showAllUsers, selectedCompany, selectedUser]); // Added dependencies for admin filter and company filter

  const loadData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      console.log('🔍 Carregando Key Results - Usuário:', userData.email, 'Role:', userData.role);
      
      // Buscar TODOS os dados primeiro
      const allObjectives = await Objective.list('-created_date');
      const allKeyResults = await KeyResult.list();
      const allProjects = await Project.list('-created_date');
      
      console.log('📊 DADOS TOTAIS:', {
        objectives: allObjectives.length,
        keyResults: allKeyResults.length,
        projects: allProjects.length
      });
      
      let objectivesData;
      let keyResultsData;
      let projectsData;
      
      if (userData.role === 'admin' && showAllUsers) {
        console.log('📊 MODO ADMIN - Ver todos os usuários');
        
        const allUsersData = await User.list();
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(uniqueCompanies);

        // Determinar quais usuários mostrar
        let usersInScope = Object.keys(companyMap);
        
        if (selectedCompany !== 'all') {
          usersInScope = usersInScope.filter(
            email => companyMap[email] === selectedCompany
          );
        }
        
        if (selectedUser !== 'all') {
          usersInScope = usersInScope.filter(email => email === selectedUser);
        }
        
        setAllUsers(usersInScope);

        // Filtrar dados pelos usuários no escopo (independente de projetos!)
        objectivesData = allObjectives.filter(o => usersInScope.includes(o.created_by));
        const objectiveIds = objectivesData.map(o => o.id);
        keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        projectsData = allProjects.filter(p => usersInScope.includes(p.created_by));
        
      } else {
        console.log('👤 MODO USUÁRIO - Apenas dados do usuário');
        
        // Usuário normal: filtrar DIRETO pelo email
        objectivesData = allObjectives.filter(o => o.created_by === userData.email);
        const objectiveIds = objectivesData.map(o => o.id);
        keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
        projectsData = allProjects.filter(p => p.created_by === userData.email);
        
        setAllUsers([]);
        setSelectedUser('all');
        setAllCompanies([]);
        setSelectedCompany('all');
        setUserCompanyMap({});
      }
      
      console.log('✅ DADOS FILTRADOS:', {
        objectives: objectivesData.length,
        keyResults: keyResultsData.length,
        projects: projectsData.length,
        usersInScope: userData.role === 'admin' && showAllUsers ? 'múltiplos' : userData.email
      });

      setObjectives(objectivesData);
      setProjects(projectsData);
      
      // Recalcular progresso dos key results
      const updatedKeyResults = keyResultsData.map(kr => ({
        ...kr,
        progress: kr.target_value > 0 ? Math.min(100, Math.round((kr.current_value / kr.target_value) * 100)) : 0
      }));

      setKeyResults(updatedKeyResults);
    } catch (error) {
      console.error('❌ Error loading data:', error);
      alert('Erro ao carregar dados: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (keyResultData) => {
    try {
      const progress = keyResultData.target_value > 0 
        ? Math.min(100, Math.round((keyResultData.current_value / keyResultData.target_value) * 100))
        : 0;
      
      const dataWithProgress = { ...keyResultData, progress };

      if (editingKeyResult) {
        await KeyResult.update(editingKeyResult.id, dataWithProgress);
      } else {
        await KeyResult.create(dataWithProgress);
      }
      setShowForm(false);
      setEditingKeyResult(null);
      loadData();
    } catch (error) {
      console.error('Error saving key result:', error);
    }
  };

  const handleEdit = (keyResult) => {
    setEditingKeyResult(keyResult);
    setShowForm(true);
  };

  const handleDelete = async (keyResultId) => {
    if (window.confirm('Tem certeza que deseja excluir este resultado chave?')) {
      try {
        await KeyResult.delete(keyResultId);
        loadData();
      } catch (error) {
        console.error('Error deleting key result:', error);
      }
    }
  };

  const getFilteredKeyResults = () => {
    let filtered = keyResults;
    
    if (filters.project !== 'all') {
      const relevantObjectiveIds = objectives
        .filter(obj => obj.project_id === filters.project)
        .map(obj => obj.id);
      filtered = filtered.filter(kr => relevantObjectiveIds.includes(kr.objective_id));
    }

    return filtered.filter(keyResult => {
      const statusMatch = filters.status === 'all' || 
        (filters.status === 'completed' && keyResult.progress >= 100) ||
        (filters.status === 'in_progress' && keyResult.progress > 0 && keyResult.progress < 100) ||
        (filters.status === 'not_started' && keyResult.progress === 0);

      return (filters.objective === 'all' || keyResult.objective_id === filters.objective) &&
             statusMatch;
    });
  };

  const getObjectiveInfo = (objectiveId) => {
    const objective = objectives.find(obj => obj.id === objectiveId);
    if (!objective) return { title: 'Objetivo não encontrado', project: 'N/A' };
    
    const project = projects.find(p => p.id === objective.project_id);
    return {
      title: objective.title,
      project: project ? project.name : 'Projeto não encontrado',
      quarter: `${objective.quarter} ${objective.year}`
    };
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="h-80 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
              <Key className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Resultados Chave</h1>
              <p className="text-slate-600">Gerencie métricas quantificáveis dos seus objetivos</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Resultado Chave
          </Button>
        </div>

        {/* Admin Filter Section */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-kr"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all'); // Reset company filter
                      setSelectedUser('all'); // Reset user filter
                    }}
                  />
                  <Label htmlFor="show-all-kr" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-green-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all'); // Reset user filter when company changes
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <KeyResultForm
              keyResult={editingKeyResult}
              objectives={objectives}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingKeyResult(null);
              }}
            />
          </div>
        )}

        <KeyResultFilters
          filters={filters}
          onFiltersChange={setFilters}
          projects={projects}
          objectives={objectives}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getFilteredKeyResults().map((keyResult) => {
            const objectiveInfo = getObjectiveInfo(keyResult.objective_id);
            return (
              <div key={keyResult.id} className="relative">
                {showAllUsers && user?.role === 'admin' && (
                  <Badge className="absolute -top-2 -right-2 z-10 bg-green-600 text-white text-xs">
                    {keyResult.responsible}
                  </Badge>
                )}
                <KeyResultCard
                  keyResult={keyResult}
                  objectiveInfo={objectiveInfo}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              </div>
            );
          })}
        </div>

        {getFilteredKeyResults().length === 0 && (
          <div className="text-center py-16">
            <Key className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum resultado chave encontrado
            </h3>
            <p className="text-slate-500 mb-6">
              Crie seu primeiro resultado chave mensurável
            </p>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Criar Primeiro Resultado Chave
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
