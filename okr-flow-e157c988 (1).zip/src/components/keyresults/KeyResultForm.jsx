import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";
import AISuggestButton from "../ai/AISuggestButton";

export default function KeyResultForm({ keyResult, objectives, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    objective_id: keyResult?.objective_id || "",
    title: keyResult?.title || "",
    description: keyResult?.description || "",
    responsible: keyResult?.responsible || "",
    start_date: keyResult?.start_date || "",
    end_date: keyResult?.end_date || "",
    target_value: keyResult?.target_value || "",
    current_value: keyResult?.current_value || 0,
    unit: keyResult?.unit || ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      target_value: parseFloat(formData.target_value) || 0,
      current_value: parseFloat(formData.current_value) || 0
    });
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleKRSuggestion = (suggestion) => {
    setFormData(prev => ({
      ...prev,
      title: suggestion.title,
      description: suggestion.description,
      target_value: suggestion.target_value,
      current_value: suggestion.current_value,
      unit: suggestion.unit
    }));
  };

  const selectedObjective = objectives.find(obj => obj.id === formData.objective_id);

  const getObjectiveDates = () => {
    if (!selectedObjective) return null;
    
    const year = selectedObjective.year;
    const quarterDates = {
      'Q1': { start: `${year}-01-01`, end: `${year}-03-31` },
      'Q2': { start: `${year}-04-01`, end: `${year}-06-30` },
      'Q3': { start: `${year}-07-01`, end: `${year}-09-30` },
      'Q4': { start: `${year}-10-01`, end: `${year}-12-31` }
    };
    
    return quarterDates[selectedObjective.quarter];
  };

  const objectiveDates = getObjectiveDates();
  const currentProgress = formData.target_value > 0 
    ? Math.min(100, Math.round((formData.current_value / formData.target_value) * 100))
    : 0;

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">
            {keyResult ? 'Editar Resultado Chave' : 'Novo Resultado Chave'}
          </CardTitle>
          {formData.objective_id && (
            <AISuggestButton
              type="key_results"
              context={{
                objective_title: selectedObjective?.title,
                objective_description: selectedObjective?.description,
                quarter: selectedObjective?.quarter,
                year: selectedObjective?.year
              }}
              onSuggestionSelect={handleKRSuggestion}
              variant="default"
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
            />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-700">
              Objetivo *
            </Label>
            <Select 
              value={formData.objective_id} 
              onValueChange={(value) => {
                handleChange('objective_id', value);
                handleChange('start_date', '');
                handleChange('end_date', '');
              }}
              required
            >
              <SelectTrigger className="border-slate-200 focus:border-green-500">
                <SelectValue placeholder="Selecione o objetivo" />
              </SelectTrigger>
              <SelectContent>
                {objectives.map((objective) => (
                  <SelectItem key={objective.id} value={objective.id}>
                    {objective.title} ({objective.quarter} {objective.year})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {objectiveDates && (
              <p className="text-xs text-slate-500">
                Período do objetivo: {objectiveDates.start} a {objectiveDates.end}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-semibold text-slate-700">
              Título do Resultado Chave *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange('title', e.target.value)}
              placeholder="Ex: Aumentar NPS para 85 pontos"
              required
              className="border-slate-200 focus:border-green-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-semibold text-slate-700">
              Descrição
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descreva como este resultado será medido..."
              rows={3}
              className="border-slate-200 focus:border-green-500"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="responsible" className="text-sm font-semibold text-slate-700">
                Responsável *
              </Label>
              <Input
                id="responsible"
                value={formData.responsible}
                onChange={(e) => handleChange('responsible', e.target.value)}
                placeholder="Nome do responsável"
                required
                className="border-slate-200 focus:border-green-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="unit" className="text-sm font-semibold text-slate-700">
                Unidade de Medida *
              </Label>
              <Input
                id="unit"
                value={formData.unit}
                onChange={(e) => handleChange('unit', e.target.value)}
                placeholder="Ex: pontos, %, vendas, usuários"
                required
                className="border-slate-200 focus:border-green-500"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="start_date" className="text-sm font-semibold text-slate-700">
                Data de Início *
              </Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => handleChange('start_date', e.target.value)}
                required
                min={objectiveDates?.start}
                max={objectiveDates?.end}
                className="border-slate-200 focus:border-green-500"
                disabled={!formData.objective_id}
              />
              {!formData.objective_id && (
                <p className="text-xs text-amber-600">Selecione um objetivo primeiro</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="end_date" className="text-sm font-semibold text-slate-700">
                Data de Fim *
              </Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date}
                onChange={(e) => handleChange('end_date', e.target.value)}
                required
                min={formData.start_date || objectiveDates?.start}
                max={objectiveDates?.end}
                className="border-slate-200 focus:border-green-500"
                disabled={!formData.objective_id}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="target_value" className="text-sm font-semibold text-slate-700">
                Valor Alvo *
              </Label>
              <Input
                id="target_value"
                type="number"
                step="0.01"
                value={formData.target_value}
                onChange={(e) => handleChange('target_value', e.target.value)}
                placeholder="Meta a ser atingida"
                required
                className="border-slate-200 focus:border-green-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="current_value" className="text-sm font-semibold text-slate-700">
                Valor Atual
              </Label>
              <Input
                id="current_value"
                type="number"
                step="0.01"
                value={formData.current_value}
                onChange={(e) => handleChange('current_value', e.target.value)}
                placeholder="Progresso atual"
                className="border-slate-200 focus:border-green-500"
              />
            </div>
          </div>

          {(formData.target_value && formData.current_value !== undefined) && (
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <p className="text-sm font-medium text-slate-700 mb-2">
                Progresso Atual: {currentProgress}%
              </p>
              <div className="w-full bg-slate-200 rounded-full h-3">
                <div 
                  className="h-3 bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all duration-500"
                  style={{ width: `${currentProgress}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-slate-500 mt-1">
                <span>{formData.current_value} {formData.unit}</span>
                <span>{formData.target_value} {formData.unit}</span>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
              <Save className="w-4 h-4 mr-2" />
              Salvar Resultado Chave
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}