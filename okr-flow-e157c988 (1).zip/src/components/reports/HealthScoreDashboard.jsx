import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, 
  Target, ThermometerSun, Activity, Clock, MessageSquare, Shield
} from "lucide-react";
import { format, subDays, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

const HealthScoreCard = ({ score, label, trend }) => {
  const getColor = (score) => {
    if (score >= 80) return {
      bg: 'from-green-500 to-green-600',
      text: 'text-green-700',
      ring: 'ring-green-500',
      status: 'Excelente'
    };
    if (score >= 60) return {
      bg: 'from-blue-500 to-blue-600',
      text: 'text-blue-700',
      ring: 'ring-blue-500',
      status: 'Bom'
    };
    if (score >= 40) return {
      bg: 'from-orange-500 to-orange-600',
      text: 'text-orange-700',
      ring: 'ring-orange-500',
      status: 'Atenção'
    };
    return {
      bg: 'from-red-500 to-red-600',
      text: 'text-red-700',
      ring: 'ring-red-500',
      status: 'Crítico'
    };
  };

  const color = getColor(score);

  return (
    <Card className="bg-white border-0 shadow-xl">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${color.bg} flex items-center justify-center shadow-lg ring-4 ${color.ring} ring-opacity-20`}>
              <span className="text-2xl font-bold text-white">{score}</span>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">{label}</p>
              <p className={`text-lg font-bold ${color.text}`}>{color.status}</p>
            </div>
          </div>
          {trend !== undefined && (
            <div className={`flex items-center gap-1 ${trend > 0 ? 'text-green-600' : trend < 0 ? 'text-red-600' : 'text-slate-500'}`}>
              {trend > 0 ? <TrendingUp className="w-5 h-5" /> : trend < 0 ? <TrendingDown className="w-5 h-5" /> : null}
              <span className="text-sm font-bold">{trend > 0 ? '+' : ''}{trend}%</span>
            </div>
          )}
        </div>
        <Progress value={score} className="h-2" />
      </CardContent>
    </Card>
  );
};

const ObjectiveHealthCard = ({ objective, keyResults, checkIns }) => {
  const objKRs = keyResults.filter(kr => kr.objective_id === objective.id);
  
  const healthData = objKRs.map(kr => {
    const krCheckIns = checkIns
      .filter(ci => ci.key_result_id === kr.id)
      .sort((a, b) => new Date(b.check_in_date) - new Date(a.check_in_date));
    
    const lastCheckIn = krCheckIns[0];
    
    return {
      kr,
      lastCheckIn,
      hasRecentUpdate: lastCheckIn ? differenceInDays(new Date(), new Date(lastCheckIn.check_in_date)) <= 7 : false
    };
  });

  const onTrack = healthData.filter(d => d.lastCheckIn?.status === 'on_track').length;
  const atRisk = healthData.filter(d => d.lastCheckIn?.status === 'at_risk').length;
  const offTrack = healthData.filter(d => d.lastCheckIn?.status === 'off_track').length;
  const noCheckIn = healthData.filter(d => !d.lastCheckIn).length;

  const healthScore = objKRs.length > 0
    ? Math.round(((onTrack * 100) + (atRisk * 50) + (offTrack * 0)) / objKRs.length)
    : 0;

  const getScoreColor = (score) => {
    if (score >= 80) return 'bg-green-100 border-green-300';
    if (score >= 60) return 'bg-blue-100 border-blue-300';
    if (score >= 40) return 'bg-orange-100 border-orange-300';
    return 'bg-red-100 border-red-300';
  };

  return (
    <Card className={`${getScoreColor(healthScore)} border-2`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h4 className="font-semibold text-slate-900 mb-1">{objective.title}</h4>
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Badge variant="outline">{objective.quarter} {objective.year}</Badge>
              <span>{objKRs.length} KRs</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-slate-900">{healthScore}</p>
            <p className="text-xs text-slate-600">Health Score</p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 mt-3">
          <div className="text-center p-2 bg-green-50 rounded">
            <p className="text-lg font-bold text-green-700">{onTrack}</p>
            <p className="text-xs text-green-600">No Rumo</p>
          </div>
          <div className="text-center p-2 bg-orange-50 rounded">
            <p className="text-lg font-bold text-orange-700">{atRisk}</p>
            <p className="text-xs text-orange-600">Em Risco</p>
          </div>
          <div className="text-center p-2 bg-red-50 rounded">
            <p className="text-lg font-bold text-red-700">{offTrack}</p>
            <p className="text-xs text-red-600">Críticos</p>
          </div>
          <div className="text-center p-2 bg-slate-50 rounded">
            <p className="text-lg font-bold text-slate-700">{noCheckIn}</p>
            <p className="text-xs text-slate-600">Sem Check-in</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const CriticalKRCard = ({ kr, objective, lastCheckIn }) => {
  return (
    <div className="flex items-start gap-3 p-4 bg-red-50 border-2 border-red-200 rounded-lg">
      <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <h5 className="font-semibold text-slate-900 text-sm">{kr.title}</h5>
        <p className="text-xs text-slate-600 mt-1">{objective.title}</p>
        <div className="flex flex-wrap items-center gap-2 mt-2">
          <Badge className="bg-red-100 text-red-700 text-xs">
            {lastCheckIn?.status === 'off_track' ? 'Fora do Rumo' : 'Em Risco'}
          </Badge>
          {lastCheckIn?.confidence_level && (
            <span className="text-xs text-slate-600">
              Confiança: {lastCheckIn.confidence_level}/10
            </span>
          )}
          <span className="text-xs text-slate-600">
            Progresso: {kr.progress}%
          </span>
        </div>
        {lastCheckIn?.blockers && (
          <div className="mt-2 p-2 bg-white rounded border border-red-200">
            <p className="text-xs text-red-800">
              <strong>Bloqueio:</strong> {lastCheckIn.blockers}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default function HealthScoreDashboard({ 
  objectives, 
  keyResults, 
  checkIns, 
  filters 
}) {
  const analytics = useMemo(() => {
    // Filtrar por período
    let filteredObjectives = objectives.filter(o =>
      o.year.toString() === filters.year && o.quarter === filters.quarter
    );

    if (filters.objective && filters.objective !== 'all') {
      filteredObjectives = filteredObjectives.filter(o => o.id === filters.objective);
    }

    const filteredKRs = keyResults.filter(kr =>
      filteredObjectives.some(obj => obj.id === kr.objective_id)
    );

    const filteredCheckIns = checkIns.filter(ci =>
      filteredKRs.some(kr => kr.id === ci.key_result_id)
    );

    // Calcular métricas
    const krWithCheckIns = filteredKRs.map(kr => {
      const krCheckIns = filteredCheckIns
        .filter(ci => ci.key_result_id === kr.id)
        .sort((a, b) => new Date(b.check_in_date) - new Date(a.check_in_date));
      
      return {
        kr,
        checkIns: krCheckIns,
        lastCheckIn: krCheckIns[0],
        previousCheckIn: krCheckIns[1]
      };
    });

    // Status counts
    const onTrack = krWithCheckIns.filter(d => d.lastCheckIn?.status === 'on_track').length;
    const atRisk = krWithCheckIns.filter(d => d.lastCheckIn?.status === 'at_risk').length;
    const offTrack = krWithCheckIns.filter(d => d.lastCheckIn?.status === 'off_track').length;
    const noCheckIn = krWithCheckIns.filter(d => !d.lastCheckIn).length;

    // Health Score Geral (0-100)
    const totalKRs = filteredKRs.length;
    const healthScore = totalKRs > 0
      ? Math.round(((onTrack * 100) + (atRisk * 50) + (offTrack * 0) + (noCheckIn * 0)) / totalKRs)
      : 0;

    // Calcular tendência (comparar últimas 2 semanas)
    const twoWeeksAgo = subDays(new Date(), 14);
    const recentCheckIns = filteredCheckIns.filter(ci => 
      new Date(ci.check_in_date) >= twoWeeksAgo
    );
    const olderCheckIns = filteredCheckIns.filter(ci => 
      new Date(ci.check_in_date) < twoWeeksAgo
    );

    const recentOnTrack = recentCheckIns.filter(ci => ci.status === 'on_track').length;
    const olderOnTrack = olderCheckIns.filter(ci => ci.status === 'on_track').length;
    
    const recentRate = recentCheckIns.length > 0 ? (recentOnTrack / recentCheckIns.length) * 100 : 0;
    const olderRate = olderCheckIns.length > 0 ? (olderOnTrack / olderCheckIns.length) * 100 : 0;
    const trend = Math.round(recentRate - olderRate);

    // Nível de confiança médio
    const checkInsWithConfidence = filteredCheckIns.filter(ci => ci.confidence_level);
    const avgConfidence = checkInsWithConfidence.length > 0
      ? Math.round(checkInsWithConfidence.reduce((sum, ci) => sum + ci.confidence_level, 0) / checkInsWithConfidence.length)
      : 0;

    // Confiança como score 0-100
    const confidenceScore = Math.round(avgConfidence * 10);

    // Score de Engajamento (baseado em frequência de check-ins)
    const krsWithRecentCheckIn = krWithCheckIns.filter(d => {
      if (!d.lastCheckIn) return false;
      const daysSince = differenceInDays(new Date(), new Date(d.lastCheckIn.check_in_date));
      return daysSince <= 7;
    }).length;
    const engagementScore = totalKRs > 0 ? Math.round((krsWithRecentCheckIn / totalKRs) * 100) : 0;

    // KRs Críticos (off_track ou at_risk com baixa confiança)
    const criticalKRs = krWithCheckIns
      .filter(d => 
        d.lastCheckIn && 
        (d.lastCheckIn.status === 'off_track' || 
         (d.lastCheckIn.status === 'at_risk' && d.lastCheckIn.confidence_level <= 5))
      )
      .sort((a, b) => {
        const aScore = (a.lastCheckIn.status === 'off_track' ? 0 : 50) + (a.lastCheckIn.confidence_level || 5);
        const bScore = (b.lastCheckIn.status === 'off_track' ? 0 : 50) + (b.lastCheckIn.confidence_level || 5);
        return aScore - bScore;
      })
      .slice(0, 5);

    // Tendência ao longo do tempo (últimos 30 dias)
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      const dayCheckIns = filteredCheckIns.filter(ci => {
        const ciDate = new Date(ci.check_in_date);
        return ciDate.toDateString() === date.toDateString();
      });
      
      const onTrackCount = dayCheckIns.filter(ci => ci.status === 'on_track').length;
      const score = dayCheckIns.length > 0 
        ? Math.round((onTrackCount / dayCheckIns.length) * 100)
        : null;

      return {
        date: format(date, 'dd/MM'),
        score: score
      };
    }).filter(d => d.score !== null);

    // Bloqueios mais frequentes
    const allBlockers = filteredCheckIns
      .filter(ci => ci.blockers && ci.blockers.trim())
      .map(ci => ci.blockers);

    return {
      healthScore,
      trend,
      confidenceScore,
      engagementScore,
      onTrack,
      atRisk,
      offTrack,
      noCheckIn,
      totalKRs,
      avgConfidence,
      criticalKRs,
      trendData: last30Days,
      objectives: filteredObjectives,
      allBlockers: allBlockers.length
    };
  }, [objectives, keyResults, checkIns, filters]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Health Score Dashboard</h2>
        <p className="text-slate-600">
          Análise de saúde dos OKRs baseada em check-ins • {filters.quarter} {filters.year}
        </p>
      </div>

      {/* Main Scores */}
      <div className="grid md:grid-cols-3 gap-6">
        <HealthScoreCard 
          score={analytics.healthScore} 
          label="Health Score Geral"
          trend={analytics.trend}
        />
        <HealthScoreCard 
          score={analytics.confidenceScore} 
          label="Nível de Confiança"
        />
        <HealthScoreCard 
          score={analytics.engagementScore} 
          label="Score de Engajamento"
        />
      </div>

      {/* Status Overview */}
      <Card className="bg-white border-0 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Distribuição de Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg border-2 border-green-200">
              <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-green-700">{analytics.onTrack}</p>
              <p className="text-sm text-green-600 font-medium">No Rumo</p>
              <p className="text-xs text-slate-500 mt-1">
                {analytics.totalKRs > 0 ? Math.round((analytics.onTrack / analytics.totalKRs) * 100) : 0}%
              </p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg border-2 border-orange-200">
              <AlertTriangle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-orange-700">{analytics.atRisk}</p>
              <p className="text-sm text-orange-600 font-medium">Em Risco</p>
              <p className="text-xs text-slate-500 mt-1">
                {analytics.totalKRs > 0 ? Math.round((analytics.atRisk / analytics.totalKRs) * 100) : 0}%
              </p>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg border-2 border-red-200">
              <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-red-700">{analytics.offTrack}</p>
              <p className="text-sm text-red-600 font-medium">Fora do Rumo</p>
              <p className="text-xs text-slate-500 mt-1">
                {analytics.totalKRs > 0 ? Math.round((analytics.offTrack / analytics.totalKRs) * 100) : 0}%
              </p>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg border-2 border-slate-200">
              <Clock className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-slate-700">{analytics.noCheckIn}</p>
              <p className="text-sm text-slate-600 font-medium">Sem Check-in</p>
              <p className="text-xs text-slate-500 mt-1">
                {analytics.totalKRs > 0 ? Math.round((analytics.noCheckIn / analytics.totalKRs) * 100) : 0}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Tendência */}
        <Card className="bg-white border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Tendência de Saúde (30 dias)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analytics.trendData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={analytics.trendData}>
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 11 }}
                    interval="preserveStartEnd"
                  />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ 
                      background: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px'
                    }}
                    formatter={(value) => [`${value}%`, 'Health Score']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#3b82f6" 
                    strokeWidth={3}
                    dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-12">
                <Clock className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Dados insuficientes para mostrar tendência</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Insights Rápidos */}
        <Card className="bg-white border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ThermometerSun className="w-5 h-5 text-purple-600" />
              Insights Rápidos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-4 h-4 text-blue-600" />
                <p className="text-sm font-semibold text-blue-900">Confiança Média</p>
              </div>
              <p className="text-2xl font-bold text-blue-700">{analytics.avgConfidence}/10</p>
              <p className="text-xs text-blue-600 mt-1">
                {analytics.avgConfidence >= 7 ? 'Equipe confiante nos resultados' : 
                 analytics.avgConfidence >= 5 ? 'Confiança moderada' : 
                 'Atenção: baixa confiança'}
              </p>
            </div>

            <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4 text-purple-600" />
                <p className="text-sm font-semibold text-purple-900">Engajamento</p>
              </div>
              <p className="text-2xl font-bold text-purple-700">{analytics.engagementScore}%</p>
              <p className="text-xs text-purple-600 mt-1">
                KRs atualizados nos últimos 7 dias
              </p>
            </div>

            <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
              <div className="flex items-center gap-2 mb-1">
                <MessageSquare className="w-4 h-4 text-orange-600" />
                <p className="text-sm font-semibold text-orange-900">Bloqueios Ativos</p>
              </div>
              <p className="text-2xl font-bold text-orange-700">{analytics.allBlockers}</p>
              <p className="text-xs text-orange-600 mt-1">
                Reportados em check-ins recentes
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Saúde por Objetivo */}
      <Card className="bg-white border-0 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-green-600" />
            Saúde por Objetivo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {analytics.objectives.map(objective => (
              <ObjectiveHealthCard
                key={objective.id}
                objective={objective}
                keyResults={keyResults}
                checkIns={checkIns}
              />
            ))}
            {analytics.objectives.length === 0 && (
              <p className="text-center text-slate-500 py-8">
                Nenhum objetivo encontrado para o período selecionado
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* KRs Críticos */}
      {analytics.criticalKRs.length > 0 && (
        <Card className="bg-white border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Key Results Críticos ({analytics.criticalKRs.length})
            </CardTitle>
            <p className="text-sm text-slate-600 mt-1">
              Requerem atenção imediata da liderança
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            {analytics.criticalKRs.map(({ kr, lastCheckIn }) => {
              const objective = objectives.find(o => o.id === kr.objective_id);
              return (
                <CriticalKRCard
                  key={kr.id}
                  kr={kr}
                  objective={objective}
                  lastCheckIn={lastCheckIn}
                />
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}