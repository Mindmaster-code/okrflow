import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, User } from "lucide-react";
import { format, parseISO, differenceInDays, isWithinInterval, startOfMonth, endOfMonth, addMonths } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function TimelineView({ projects, sprints, initiatives, keyResults }) {
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  
  const today = new Date();
  const startDate = startOfMonth(addMonths(today, -1));
  const endDate = endOfMonth(addMonths(today, 2));
  const totalDays = differenceInDays(endDate, startDate);
  
  // Filtrar dados por projeto
  const filteredSprints = selectedProjectId === 'all' 
    ? sprints 
    : sprints.filter(s => s.project_id === selectedProjectId);
  
  const filteredInitiatives = selectedProjectId === 'all'
    ? initiatives
    : initiatives.filter(i => {
        const kr = keyResults.find(kr => kr.id === i.key_result_id);
        if (!kr) return false;
        const obj = projects.find(p => p.id === selectedProjectId);
        return obj;
      });
  
  // Agrupar iniciativas por responsável
  const initiativesByPerson = {};
  filteredInitiatives.forEach(initiative => {
    if (!initiativesByPerson[initiative.responsible]) {
      initiativesByPerson[initiative.responsible] = [];
    }
    initiativesByPerson[initiative.responsible].push(initiative);
  });
  
  const getBarPosition = (startDateStr, endDateStr) => {
    const start = parseISO(startDateStr);
    const end = parseISO(endDateStr);
    
    const daysFromStart = differenceInDays(start, startDate);
    const duration = differenceInDays(end, start);
    
    const left = Math.max(0, (daysFromStart / totalDays) * 100);
    const width = Math.min(100 - left, (duration / totalDays) * 100);
    
    return { left: `${left}%`, width: `${width}%` };
  };
  
  const isActive = (startDateStr, endDateStr) => {
    return isWithinInterval(today, {
      start: parseISO(startDateStr),
      end: parseISO(endDateStr)
    });
  };
  
  const todayPosition = `${(differenceInDays(today, startDate) / totalDays) * 100}%`;
  
  // Gerar marcadores de mês
  const monthMarkers = [];
  let currentMonth = new Date(startDate);
  while (currentMonth <= endDate) {
    const position = (differenceInDays(currentMonth, startDate) / totalDays) * 100;
    monthMarkers.push({
      date: new Date(currentMonth),
      position: `${position}%`
    });
    currentMonth = addMonths(currentMonth, 1);
  }
  
  return (
    <Card className="bg-white shadow-lg border-0">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            Timeline de Entregas
          </CardTitle>
          <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Filtrar por projeto" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Projetos</SelectItem>
              {projects.map(p => (
                <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        {/* Grid de meses */}
        <div className="relative h-10 mb-6 border-b border-slate-200">
          {monthMarkers.map((marker, idx) => (
            <div
              key={idx}
              className="absolute top-0 bottom-0 border-l border-slate-200"
              style={{ left: marker.position }}
            >
              <span className="absolute top-0 left-2 text-xs font-semibold text-slate-600">
                {format(marker.date, 'MMM/yy', { locale: ptBR })}
              </span>
            </div>
          ))}
          
          {/* Linha HOJE */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
            style={{ left: todayPosition }}
          >
            <Badge className="absolute -top-1 left-1/2 -translate-x-1/2 bg-red-500 text-white text-xs whitespace-nowrap">
              HOJE
            </Badge>
          </div>
        </div>
        
        <div className="space-y-8">
          {/* Sprints */}
          {filteredSprints.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-bold text-slate-900 flex items-center gap-2">
                <span className="text-lg">⚡</span>
                Sprints
              </h3>
              {filteredSprints.map(sprint => {
                const { left, width } = getBarPosition(sprint.start_date, sprint.end_date);
                const active = isActive(sprint.start_date, sprint.end_date);
                
                return (
                  <div key={sprint.id} className="relative h-12">
                    <div className="absolute inset-0 bg-slate-100 rounded-lg"></div>
                    <div
                      className={`absolute top-1 bottom-1 rounded-lg flex items-center px-3 ${
                        active 
                          ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg' 
                          : sprint.status === 'completed'
                          ? 'bg-blue-500 text-white'
                          : 'bg-slate-300 text-slate-700'
                      }`}
                      style={{ left, width }}
                    >
                      <span className="text-sm font-semibold truncate">{sprint.name}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          {/* Iniciativas por Pessoa */}
          {Object.keys(initiativesByPerson).length > 0 && (
            <div className="space-y-6">
              <h3 className="font-bold text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-green-600" />
                Entregas por Pessoa
              </h3>
              
              {Object.entries(initiativesByPerson).map(([person, personInitiatives]) => (
                <div key={person} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm">
                      {person.charAt(0)}
                    </div>
                    <span className="font-semibold text-slate-800">{person}</span>
                    <Badge variant="outline" className="text-xs">
                      {personInitiatives.length} iniciativa{personInitiatives.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>
                  
                  <div className="relative h-16 ml-10">
                    <div className="absolute inset-0 bg-slate-50 rounded-lg border border-slate-200"></div>
                    
                    {personInitiatives.map(initiative => {
                      const { left, width } = getBarPosition(initiative.start_date, initiative.end_date);
                      const active = isActive(initiative.start_date, initiative.end_date);
                      
                      return (
                        <div
                          key={initiative.id}
                          className={`absolute top-2 bottom-2 rounded-md flex items-center px-2 text-xs font-medium group cursor-pointer ${
                            initiative.status === 'done'
                              ? 'bg-green-500 text-white'
                              : initiative.status === 'doing'
                              ? 'bg-blue-500 text-white'
                              : 'bg-slate-400 text-white'
                          } ${active ? 'ring-2 ring-orange-400 shadow-lg' : ''}`}
                          style={{ left, width, minWidth: '60px' }}
                          title={initiative.title}
                        >
                          <span className="truncate">{initiative.title}</span>
                          {initiative.status === 'done' && <span className="ml-1">✓</span>}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {filteredSprints.length === 0 && Object.keys(initiativesByPerson).length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>Nenhuma entrega encontrada para este filtro</p>
            </div>
          )}
        </div>
        
        {/* Legenda */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex flex-wrap gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-slate-400"></div>
            <span>A Fazer</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-blue-500"></div>
            <span>Fazendo</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-green-500"></div>
            <span>Feito</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded ring-2 ring-orange-400"></div>
            <span>Em andamento agora</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}