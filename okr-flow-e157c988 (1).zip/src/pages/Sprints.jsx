import React, { useState, useEffect } from "react";
import { Sprint, Project, Objective, KeyResult } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, Eye, Building2 } from "lucide-react";

import SprintForm from "../components/sprints/SprintForm";
import SprintCard from "../components/sprints/SprintCard";
import SprintFilters from "../components/sprints/SprintFilters";

import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Sprints() {
  const [sprints, setSprints] = useState([]);
  const [projects, setProjects] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingSprint, setEditingSprint] = useState(null);
  const [filters, setFilters] = useState({
    status: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allUsers, setAllUsers] = useState([]);
  const [allCompanies, setAllCompanies] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  useEffect(() => {
    loadData();
  }, [showAllUsers, selectedCompany, selectedUser]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let objectivesData;
      
      if (userData.role === 'admin' && showAllUsers) {
        objectivesData = await Objective.list('-created_date');
        
        const allUsersData = await User.list();
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const companies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(companies);

        let filteredObjectivesByCompany = objectivesData;
        let usersInFilter = [...new Set(objectivesData.map(o => o.created_by))];

        if (selectedCompany !== 'all') {
          const usersInSelectedCompany = Object.keys(companyMap).filter(
            email => companyMap[email] === selectedCompany
          );
          filteredObjectivesByCompany = objectivesData.filter(o => usersInSelectedCompany.includes(o.created_by));
          usersInFilter = usersInSelectedCompany.filter(u => filteredObjectivesByCompany.some(o => o.created_by === u));
        }
        
        setAllUsers(usersInFilter);
        objectivesData = filteredObjectivesByCompany;

        if (selectedUser !== 'all') {
          objectivesData = objectivesData.filter(o => o.created_by === selectedUser);
        }
      } else {
        objectivesData = await Objective.filter({ created_by: userData.email });
        setAllUsers([]);
        setAllCompanies([]);
        setSelectedCompany('all');
        setSelectedUser('all');
      }
      
      const objectiveIds = objectivesData.map(o => o.id);
      
      const allKeyResults = await KeyResult.list();
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
      const keyResultIds = keyResultsData.map(kr => kr.id);
      
      const allProjects = await Project.list();
      const projectsData = allProjects.filter(proj => keyResultIds.includes(proj.key_result_id));
      
      const allSprints = await Sprint.list('-created_date');
      const sprintsData = allSprints.filter(spr => {
        if (userData.role === 'admin' && showAllUsers) {
          const userEmails = objectivesData.map(o => o.created_by);
          return userEmails.includes(spr.created_by);
        }
        return spr.created_by === userData.email;
      });

      // Auto-update sprint status
      const updatedSprints = await Promise.all(sprintsData.map(async (sprint) => {
        const sprintProjects = projectsData.filter(p => p.sprint_id === sprint.id);
        const today = new Date();
        const endDate = new Date(sprint.end_date);
        
        let newStatus = sprint.status;
        
        if (sprintProjects.length > 0) {
          const allDone = sprintProjects.every(p => p.status === 'done');
          if (allDone || endDate < today) {
            newStatus = 'completed';
          } else if (sprint.status === 'planning') {
            newStatus = 'active';
          }
        } else if (endDate < today && sprint.status !== 'completed') {
          newStatus = 'completed';
        }
        
        if (newStatus !== sprint.status) {
          await Sprint.update(sprint.id, { status: newStatus });
          return { ...sprint, status: newStatus };
        }
        
        return sprint;
      }));

      setSprints(updatedSprints);
      setProjects(projectsData);
      setObjectives(objectivesData);
      setKeyResults(keyResultsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (sprintData) => {
    try {
      if (editingSprint) {
        await Sprint.update(editingSprint.id, sprintData);
      } else {
        await Sprint.create(sprintData);
      }
      setShowForm(false);
      setEditingSprint(null);
      loadData();
    } catch (error) {
      console.error('Error saving sprint:', error);
    }
  };

  const handleEdit = (sprint) => {
    setEditingSprint(sprint);
    setShowForm(true);
  };

  const handleDelete = async (sprintId) => {
    if (window.confirm('Tem certeza que deseja excluir este sprint? Os projetos associados ficarão sem sprint.')) {
      try {
        await Sprint.delete(sprintId);
        loadData();
      } catch (error) {
        console.error('Error deleting sprint:', error);
      }
    }
  };

  const getFilteredSprints = () => {
    return sprints.filter(sprint => {
      return filters.status === 'all' || sprint.status === filters.status;
    });
  };

  const getSprintProjects = (sprintId) => {
    return projects.filter(p => p.sprint_id === sprintId);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="h-80 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Sprints</h1>
              <p className="text-slate-600">Organize projetos em períodos de execução</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Sprint
          </Button>
        </div>

        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-sprints"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all');
                      setSelectedUser('all');
                    }}
                  />
                  <Label htmlFor="show-all-sprints" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-indigo-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all');
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <SprintForm
              sprint={editingSprint}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingSprint(null);
              }}
            />
          </div>
        )}

        <SprintFilters
          filters={filters}
          onFiltersChange={setFilters}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getFilteredSprints().map((sprint) => (
            <div key={sprint.id} className="relative">
              {showAllUsers && user?.role === 'admin' && (
                <Badge className="absolute -top-2 -right-2 z-10 bg-indigo-600 text-white text-xs">
                  {sprint.created_by}
                </Badge>
              )}
              <SprintCard
                sprint={sprint}
                projects={getSprintProjects(sprint.id)}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>

        {getFilteredSprints().length === 0 && (
          <div className="text-center py-16">
            <Calendar className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum sprint encontrado
            </h3>
            <p className="text-slate-500 mb-6">
              Crie seu primeiro sprint para organizar os projetos
            </p>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Criar Primeiro Sprint
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}