import React, { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Zap, CheckCircle2, Clock, AlertTriangle, GitCommitHorizontal, FileText, Calendar } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { format, eachDayOfInterval, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

const KpiCard = ({ title, value, description, icon: Icon, color }) => (
  <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
      <Icon className={`h-5 w-5 ${color || 'text-slate-500'}`} />
    </CardHeader>
    <CardContent>
      <div className="text-3xl font-bold text-slate-900">{value}</div>
      <p className="text-xs text-slate-500">{description}</p>
    </CardContent>
  </Card>
);

export default function SprintReviewReport({ sprints, initiatives, keyResults }) {
  const [selectedSprintId, setSelectedSprintId] = useState(null);
  const [sprintData, setSprintData] = useState(null);

  useEffect(() => {
    if (sprints.length > 0 && !selectedSprintId) {
      const activeSprint = sprints.find(s => s.status === 'active') || 
                          sprints.find(s => s.status === 'completed') || 
                          sprints[sprints.length - 1];
      setSelectedSprintId(activeSprint.id);
    }
  }, [sprints, selectedSprintId]);

  useEffect(() => {
    if (selectedSprintId) {
      const sprint = sprints.find(s => s.id === selectedSprintId);
      const sprintInitiatives = initiatives.filter(i => i.sprint_id === selectedSprintId);
      
      const completedInitiatives = sprintInitiatives.filter(i => i.status === 'done');
      const inProgressInitiatives = sprintInitiatives.filter(i => i.status === 'doing');
      const todoInitiatives = sprintInitiatives.filter(i => i.status === 'todo');
      
      const throughput = completedInitiatives.length;
      const completionRate = sprintInitiatives.length > 0 ? Math.round((throughput / sprintInitiatives.length) * 100) : 0;
      
      // Gerar dados do burndown
      const sprintDays = eachDayOfInterval({
        start: parseISO(sprint.start_date),
        end: parseISO(sprint.end_date)
      });
      
      const totalInitiatives = sprintInitiatives.length;
      const sprintDuration = sprintDays.length;
      
      const burndownData = sprintDays.map((day, index) => {
        const idealRemaining = Math.max(0, totalInitiatives - ((index + 1) / sprintDuration) * totalInitiatives);
        // Simulação simples do real (na prática viria do histórico)
        const actualRemaining = Math.max(0, totalInitiatives - throughput * Math.min(1, (index + 1) / sprintDuration));
        
        return {
          date: format(day, 'dd/MM', { locale: ptBR }),
          ideal: Math.round(idealRemaining * 10) / 10,
          real: Math.round(actualRemaining * 10) / 10,
        };
      });

      // Identificar riscos
      const risks = [];
      const overdueInitiatives = sprintInitiatives.filter(i => {
        const today = new Date();
        const endDate = new Date(i.end_date);
        return endDate < today && i.status !== 'done';
      });
      
      if (overdueInitiatives.length > 0) {
        risks.push(`${overdueInitiatives.length} iniciativa(s) atrasada(s)`);
      }
      
      if (completionRate < 50 && sprint.status === 'active') {
        risks.push('Sprint com baixa taxa de conclusão');
      }
      
      if (inProgressInitiatives.length > completedInitiatives.length && sprint.status === 'active') {
        risks.push('Muitas iniciativas em progresso simultaneamente');
      }

      setSprintData({
        sprint,
        initiatives: sprintInitiatives,
        completedInitiatives,
        inProgressInitiatives,
        todoInitiatives,
        throughput,
        completionRate,
        burndownData,
        risks,
        overdueInitiatives
      });
    }
  }, [selectedSprintId, sprints, initiatives]);

  if (!sprints || sprints.length === 0) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
        <CardContent className="py-16 text-center">
          <Zap className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-600 mb-2">Nenhum Sprint Encontrado</h3>
          <p className="text-slate-500">Crie um sprint para poder gerar um relatório de review.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Select value={selectedSprintId} onValueChange={setSelectedSprintId}>
        <SelectTrigger className="w-full md:w-96 bg-white/80 shadow-lg border-0">
          <SelectValue placeholder="Selecione um Sprint para revisar" />
        </SelectTrigger>
        <SelectContent>
          {sprints.map(s => (
            <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      {sprintData && (
        <div className="space-y-8">
          {/* Header do Sprint */}
          <div className="p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border-0">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">{sprintData.sprint.name}</h2>
                <p className="text-slate-600 mt-1">{sprintData.sprint.description}</p>
              </div>
              <Badge className={`${
                sprintData.sprint.status === 'active' ? 'bg-green-100 text-green-700' :
                sprintData.sprint.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                'bg-yellow-100 text-yellow-700'
              }`}>
                {sprintData.sprint.status === 'active' ? 'Ativo' :
                 sprintData.sprint.status === 'completed' ? 'Concluído' : 'Planejamento'}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Calendar className="w-4 h-4" />
              <span>{format(new Date(sprintData.sprint.start_date), "dd MMMM", { locale: ptBR })}</span>
              <span>-</span>
              <span>{format(new Date(sprintData.sprint.end_date), "dd MMMM yyyy", { locale: ptBR })}</span>
            </div>
          </div>

          {/* KPIs do Sprint */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <KpiCard 
              title="Throughput"
              value={sprintData.throughput}
              description="Iniciativas entregues"
              icon={GitCommitHorizontal}
              color="text-green-600"
            />
            <KpiCard 
              title="Taxa de Conclusão"
              value={`${sprintData.completionRate}%`}
              description={`${sprintData.completedInitiatives.length} de ${sprintData.initiatives.length} iniciativas`}
              icon={CheckCircle2}
              color="text-blue-600"
            />
            <KpiCard 
              title="Riscos Identificados"
              value={sprintData.risks.length}
              description="Pontos de atenção"
              icon={AlertTriangle}
              color={sprintData.risks.length > 0 ? "text-red-600" : "text-green-600"}
            />
          </div>

          {/* Burndown Chart */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                Burndown Chart - Previsto vs Realizado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={sprintData.burndownData}>
                  <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.3} />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip 
                    formatter={(value, name) => [
                      `${value} iniciativas`, 
                      name === 'ideal' ? 'Ideal' : 'Real'
                    ]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="ideal" 
                    stroke="#94a3b8" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Ideal"
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="real" 
                    stroke="#8b5cf6" 
                    strokeWidth={3}
                    name="Real"
                    dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Entregas Realizadas */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-700">
                  <CheckCircle2 className="w-5 h-5" />
                  Entregas Realizadas ({sprintData.completedInitiatives.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sprintData.completedInitiatives.length > 0 ? (
                  <div className="space-y-3">
                    {sprintData.completedInitiatives.map(initiative => (
                      <div key={initiative.id} className="p-3 rounded-lg bg-green-50 border border-green-200">
                        <p className="font-semibold text-slate-800">{initiative.title}</p>
                        <p className="text-sm text-slate-600 mt-1">{initiative.responsible}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-500 py-8">Nenhuma iniciativa foi concluída neste sprint.</p>
                )}
              </CardContent>
            </Card>

            {/* Entregas Pendentes */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-700">
                  <Clock className="w-5 h-5" />
                  Entregas Pendentes ({sprintData.inProgressInitiatives.length + sprintData.todoInitiatives.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {sprintData.inProgressInitiatives.map(initiative => (
                    <div key={initiative.id} className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-slate-800">{initiative.title}</p>
                          <p className="text-sm text-slate-600">{initiative.responsible}</p>
                        </div>
                        <Badge className="bg-blue-100 text-blue-700">Em Andamento</Badge>
                      </div>
                    </div>
                  ))}
                  {sprintData.todoInitiatives.map(initiative => (
                    <div key={initiative.id} className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-slate-800">{initiative.title}</p>
                          <p className="text-sm text-slate-600">{initiative.responsible}</p>
                        </div>
                        <Badge className="bg-slate-100 text-slate-700">A Fazer</Badge>
                      </div>
                    </div>
                  ))}
                  {(sprintData.inProgressInitiatives.length + sprintData.todoInitiatives.length) === 0 && (
                    <p className="text-center text-slate-500 py-8">Todas as iniciativas foram concluídas!</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Riscos e Alertas */}
          {sprintData.risks.length > 0 && (
            <Card className="bg-red-50 border-red-200 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-700">
                  <AlertTriangle className="w-5 h-5" />
                  Riscos e Pontos de Atenção
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {sprintData.risks.map((risk, index) => (
                    <li key={index} className="flex items-center gap-2 text-red-700">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      {risk}
                    </li>
                  ))}
                </ul>
                {sprintData.overdueInitiatives.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-semibold text-red-800 mb-2">Iniciativas Atrasadas:</h4>
                    <div className="space-y-1">
                      {sprintData.overdueInitiatives.map(initiative => (
                        <div key={initiative.id} className="text-sm text-red-700">
                          • {initiative.title} (Resp: {initiative.responsible})
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}