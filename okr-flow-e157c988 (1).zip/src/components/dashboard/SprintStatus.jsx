import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, CheckCircle, Clock, Play } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function SprintStatus({ sprints, projects }) {
  const getSprintProjects = (sprintId) => {
    return projects.filter(p => p.sprint_id === sprintId);
  };

  const getSprintProgress = (sprint) => {
    const sprintProjects = getSprintProjects(sprint.id);
    if (sprintProjects.length === 0) return 0;
    
    const doneCount = sprintProjects.filter(p => p.status === 'done').length;
    return Math.round((doneCount / sprintProjects.length) * 100);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-600" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-blue-600" />;
      case 'planning': return <Clock className="w-4 h-4 text-yellow-600" />;
      default: return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'Ativo';
      case 'completed': return 'Concluído';
      case 'planning': return 'Planejamento';
      default: return 'Desconhecido';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'completed': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'planning': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-slate-900">
          <Calendar className="w-5 h-5 text-orange-600" />
          Status dos Sprints
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sprints.slice(0, 6).map((sprint) => {
            const progress = getSprintProgress(sprint);
            const projectCount = getSprintProjects(sprint.id).length;
            
            return (
              <div key={sprint.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(sprint.status)}
                    <div>
                      <h4 className="font-semibold text-slate-900">{sprint.name}</h4>
                      <p className="text-xs text-slate-500">
                        {format(new Date(sprint.start_date), "dd/MM", { locale: ptBR })} - 
                        {format(new Date(sprint.end_date), "dd/MM/yyyy", { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(sprint.status)}>
                    {getStatusLabel(sprint.status)}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">
                    {projectCount} projeto{projectCount !== 1 ? 's' : ''}
                  </span>
                  <span className="font-semibold text-slate-900">
                    {progress}% concluído
                  </span>
                </div>
                
                <div className="mt-2 w-full bg-slate-200 rounded-full h-2">
                  <div 
                    className="h-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            );
          })}
          {sprints.length === 0 && (
            <p className="text-center text-slate-500 py-8">
              Nenhum sprint encontrado
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}