
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Calendar, FolderOpen, Zap, Clock, Play, CheckCircle2, Pencil, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function SprintCard({ 
  sprint, 
  initiatives, 
  projectName, 
  onEdit, 
  onDelete 
}) {
  const [showInitiatives, setShowInitiatives] = React.useState(false);
  
  // According to the outline, initiatives passed as a prop are already filtered
  // to belong to the correct project and sprint.
  const projectInitiatives = initiatives;

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'completed': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'planning': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'Ativo';
      case 'completed': return 'Concluído';
      case 'planning': return 'Planejamento';
      default: return 'Desconhecido';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-600" />;
      case 'completed': return <CheckCircle2 className="w-4 h-4 text-blue-600" />;
      case 'planning': return <Clock className="w-4 h-4 text-yellow-600" />;
      default: return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const completedInitiatives = projectInitiatives.filter(i => i.status === 'done').length;
  const progress = projectInitiatives.length > 0 
    ? Math.round((completedInitiatives / projectInitiatives.length) * 100) 
    : 0;

  const getDaysRemaining = () => {
    const today = new Date();
    const endDate = new Date(sprint.end_date);
    const diffTime = endDate.getTime() - today.getTime(); // Use getTime() for accurate date arithmetic
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = getDaysRemaining();

  const initiativesByStatus = {
    todo: projectInitiatives.filter(i => i.status === 'todo').length,
    doing: projectInitiatives.filter(i => i.status === 'doing').length,
    done: projectInitiatives.filter(i => i.status === 'done').length
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0 group">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            {getStatusIcon(sprint.status)}
            <Badge className={`${getStatusColor(sprint.status)}`}>
              {getStatusLabel(sprint.status)}
            </Badge>
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(sprint)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-indigo-50 hover:text-indigo-600"
            >
              <Pencil className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(sprint.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        <h3 className="font-bold text-lg text-slate-900 group-hover:text-indigo-600 transition-colors leading-tight">
          {sprint.name}
        </h3>
        
        {sprint.description && (
          <p className="text-slate-600 text-sm mt-2 line-clamp-2">
            {sprint.description}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <FolderOpen className="w-4 h-4 text-slate-400" />
            <span className="truncate">{projectName}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>
              {format(new Date(sprint.start_date), "dd/MM", { locale: ptBR })} - 
              {format(new Date(sprint.end_date), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Zap className="w-4 h-4 text-slate-400" />
            <span>{projectInitiatives.length} iniciativa{projectInitiatives.length !== 1 ? 's' : ''}</span>
          </div>
        </div>

        {/* Progress Section */}
        <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-slate-700">Progresso</span>
            <span className="text-xl font-bold text-slate-900">{progress}%</span>
          </div>
          
          <Progress value={progress} className="h-2" />
          
          <div className="text-xs text-slate-500">
            {daysRemaining > 0 
              ? `${daysRemaining} dia${daysRemaining !== 1 ? 's' : ''} restante${daysRemaining !== 1 ? 's' : ''}` 
              : daysRemaining === 0 
                ? 'Termina hoje' 
                : `Terminou há ${Math.abs(daysRemaining)} dia${Math.abs(daysRemaining) !== 1 ? 's' : ''}`
            }
          </div>
        </div>

        {/* Initiatives Breakdown */}
        {projectInitiatives.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-700">Iniciativas:</h4>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="text-center p-2 bg-slate-100 rounded">
                <div className="font-semibold text-slate-600">{initiativesByStatus.todo}</div>
                <div className="text-slate-500">A Fazer</div>
              </div>
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="font-semibold text-blue-600">{initiativesByStatus.doing}</div>
                <div className="text-blue-500">Fazendo</div>
              </div>
              <div className="text-center p-2 bg-green-50 rounded">
                <div className="font-semibold text-green-600">{initiativesByStatus.done}</div>
                <div className="text-green-500">Feito</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
