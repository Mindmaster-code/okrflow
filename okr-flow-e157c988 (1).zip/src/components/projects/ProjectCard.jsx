import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreVertical, Pencil, Trash2, Calendar, Target, Key, Zap, User, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function ProjectCard({ 
  project, 
  keyResultTitle, 
  objectiveTitle,
  sprintName, 
  onEdit, 
  onDelete,
  isDragging 
}) {
  const priorityConfig = {
    low: { label: "Baixa", color: "bg-blue-100 text-blue-800" },
    medium: { label: "Média", color: "bg-yellow-100 text-yellow-800" },
    high: { label: "Alta", color: "bg-orange-100 text-orange-800" },
    critical: { label: "Crítica", color: "bg-red-100 text-red-800" }
  };

  const priority = priorityConfig[project.priority] || priorityConfig.medium;

  return (
    <Card className={`bg-white hover:shadow-lg transition-all duration-200 border border-slate-200 ${
      isDragging ? 'shadow-2xl rotate-2' : ''
    }`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-slate-900 mb-1 line-clamp-2">
              {project.title}
            </h4>
            <div className="flex flex-wrap gap-1.5 mt-2">
              <Badge className={priority.color}>
                {priority.label}
              </Badge>
              {project.priority === 'critical' && (
                <Badge className="bg-red-500 text-white">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Urgente
                </Badge>
              )}
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(project)}>
                <Pencil className="w-4 h-4 mr-2" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => onDelete(project.id)}
                className="text-red-600"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {project.description && (
          <p className="text-sm text-slate-600 line-clamp-2">{project.description}</p>
        )}
        
        <div className="space-y-2 text-xs">
          <div className="flex items-start gap-2 text-slate-600">
            <Target className="w-4 h-4 flex-shrink-0 mt-0.5 text-purple-600" />
            <span className="line-clamp-1">{objectiveTitle}</span>
          </div>
          
          <div className="flex items-start gap-2 text-slate-600">
            <Key className="w-4 h-4 flex-shrink-0 mt-0.5 text-green-600" />
            <span className="line-clamp-1">{keyResultTitle}</span>
          </div>
          
          {sprintName && (
            <div className="flex items-center gap-2 text-slate-600">
              <Zap className="w-4 h-4 text-orange-600" />
              <span>{sprintName}</span>
            </div>
          )}
          
          <div className="flex items-center gap-2 text-slate-600">
            <User className="w-4 h-4 text-blue-600" />
            <span className="font-medium">{project.responsible}</span>
          </div>
          
          <div className="flex items-center gap-2 text-slate-500">
            <Calendar className="w-4 h-4" />
            <span>
              {format(new Date(project.start_date), "dd/MM", { locale: ptBR })} - {format(new Date(project.end_date), "dd/MM/yy", { locale: ptBR })}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}