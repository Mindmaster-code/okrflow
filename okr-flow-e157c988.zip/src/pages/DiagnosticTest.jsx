import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Loader2, Database, User, FolderOpen } from "lucide-react";

export default function DiagnosticTest() {
  const [results, setResults] = useState({});
  const [loading, setLoading] = useState(false);

  const runTests = async () => {
    setLoading(true);
    const testResults = {};

    try {
      // Test 1: Authentication
      testResults.auth = { loading: true };
      setResults({...testResults});
      
      try {
        const user = await base44.auth.me();
        testResults.auth = {
          status: 'success',
          data: user,
          message: `Usuário: ${user.email}`
        };
      } catch (error) {
        testResults.auth = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 2: User Entity
      testResults.users = { loading: true };
      setResults({...testResults});
      
      try {
        const users = await base44.entities.User.list();
        testResults.users = {
          status: 'success',
          count: users.length,
          data: users,
          message: `${users.length} usuários encontrados`
        };
      } catch (error) {
        testResults.users = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 3: Project Entity
      testResults.projects = { loading: true };
      setResults({...testResults});
      
      try {
        const projects = await base44.entities.Project.list();
        testResults.projects = {
          status: 'success',
          count: projects.length,
          data: projects,
          message: `${projects.length} projetos encontrados`
        };
      } catch (error) {
        testResults.projects = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 4: Objective Entity
      testResults.objectives = { loading: true };
      setResults({...testResults});
      
      try {
        const objectives = await base44.entities.Objective.list();
        testResults.objectives = {
          status: 'success',
          count: objectives.length,
          data: objectives,
          message: `${objectives.length} objetivos encontrados`
        };
      } catch (error) {
        testResults.objectives = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 5: KeyResult Entity
      testResults.keyResults = { loading: true };
      setResults({...testResults});
      
      try {
        const keyResults = await base44.entities.KeyResult.list();
        testResults.keyResults = {
          status: 'success',
          count: keyResults.length,
          data: keyResults,
          message: `${keyResults.length} key results encontrados`
        };
      } catch (error) {
        testResults.keyResults = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 6: Initiative Entity
      testResults.initiatives = { loading: true };
      setResults({...testResults});
      
      try {
        const initiatives = await base44.entities.Initiative.list();
        testResults.initiatives = {
          status: 'success',
          count: initiatives.length,
          data: initiatives,
          message: `${initiatives.length} iniciativas encontradas`
        };
      } catch (error) {
        testResults.initiatives = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

      // Test 7: Sprint Entity
      testResults.sprints = { loading: true };
      setResults({...testResults});
      
      try {
        const sprints = await base44.entities.Sprint.list();
        testResults.sprints = {
          status: 'success',
          count: sprints.length,
          data: sprints,
          message: `${sprints.length} sprints encontrados`
        };
      } catch (error) {
        testResults.sprints = {
          status: 'error',
          message: error.message
        };
      }
      setResults({...testResults});

    } catch (error) {
      console.error('Test error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runTests();
  }, []);

  const getStatusIcon = (status) => {
    if (status === 'success') return <CheckCircle className="w-6 h-6 text-green-600" />;
    if (status === 'error') return <XCircle className="w-6 h-6 text-red-600" />;
    return <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />;
  };

  const tests = [
    { key: 'auth', title: 'Autenticação', icon: User },
    { key: 'users', title: 'Usuários', icon: User },
    { key: 'projects', title: 'Projetos', icon: FolderOpen },
    { key: 'objectives', title: 'Objetivos', icon: Database },
    { key: 'keyResults', title: 'Key Results', icon: Database },
    { key: 'initiatives', title: 'Iniciativas', icon: Database },
    { key: 'sprints', title: 'Sprints', icon: Database }
  ];

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-white shadow-xl border-0 mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-2xl">
              <Database className="w-8 h-8 text-blue-600" />
              Diagnóstico do Banco de Dados
            </CardTitle>
            <p className="text-slate-600 mt-2">
              Testando conexão com todas as entidades do sistema
            </p>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={runTests} 
              disabled={loading}
              className="mb-6"
            >
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Executar Testes Novamente
            </Button>

            <div className="space-y-4">
              {tests.map((test) => {
                const result = results[test.key] || {};
                const TestIcon = test.icon;

                return (
                  <Card key={test.key} className="border-2">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <TestIcon className="w-5 h-5 text-slate-600" />
                          <div>
                            <h3 className="font-semibold text-lg">{test.title}</h3>
                            <p className="text-sm text-slate-600">
                              {result.loading ? 'Testando...' : result.message || 'Aguardando...'}
                            </p>
                          </div>
                        </div>
                        {getStatusIcon(result.status)}
                      </div>

                      {result.status === 'success' && result.data && (
                        <details className="mt-4">
                          <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">
                            Ver dados ({Array.isArray(result.data) ? result.data.length : 1} registros)
                          </summary>
                          <pre className="mt-2 p-3 bg-slate-50 rounded text-xs overflow-auto max-h-64">
                            {JSON.stringify(result.data, null, 2)}
                          </pre>
                        </details>
                      )}

                      {result.status === 'error' && (
                        <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded">
                          <p className="text-sm text-red-700 font-mono">{result.message}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-bold text-lg mb-2 text-blue-900">📋 Interpretação dos Resultados:</h3>
            <ul className="space-y-2 text-sm text-blue-800">
              <li>✅ <strong>Todos verdes:</strong> Banco está funcionando perfeitamente</li>
              <li>⚠️ <strong>Alguns vermelhos:</strong> Problema específico em alguma entidade</li>
              <li>❌ <strong>Todos vermelhos:</strong> Problema de conexão ou autenticação</li>
              <li>🔢 <strong>0 registros:</strong> Banco vazio (pode estar normal se é app novo)</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}