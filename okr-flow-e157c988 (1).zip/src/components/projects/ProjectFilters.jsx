import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ProjectFilters({
  filters,
  onFiltersChange,
  objectives,
  sprints,
  projects
}) {
  const getAvailableSprints = () => {
    if (filters.objective === 'all') {
      return sprints;
    }

    const selectedObjective = objectives.find(obj => obj.id === filters.objective);
    if (!selectedObjective) {
      return [];
    }

    return sprints.filter(sprint => sprint.created_by === selectedObjective.created_by);
  };

  const availableSprints = getAvailableSprints();
  const uniqueResponsibles = [...new Set(projects.map(p => p.responsible))];

  const handleFilterChange = (key, value) => {
    onFiltersChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
      <CardContent className="p-4">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <span className="text-sm font-semibold text-slate-700">Filtros:</span>
          </div>

          <Select value={filters.objective} onValueChange={(value) => handleFilterChange('objective', value)}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Todos os objetivos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os objetivos</SelectItem>
              {objectives.map((objective) => (
                <SelectItem key={objective.id} value={objective.id}>
                  {objective.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filters.sprint} onValueChange={(value) => onFiltersChange({ ...filters, sprint: value })}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Sprint" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Sprints</SelectItem>
              <SelectItem value="none">Sem Sprint (Backlog)</SelectItem>
              {availableSprints.map((sprint) => (
                <SelectItem key={sprint.id} value={sprint.id}>{sprint.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {filters.objective !== 'all' && availableSprints.length === 0 && (
            <Badge variant="outline" className="text-xs text-amber-600 border-amber-300">
              Nenhum sprint disponível
            </Badge>
          )}

          <Select value={filters.priority} onValueChange={(value) => handleFilterChange('priority', value)}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Prioridade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="critical">Crítica</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
              <SelectItem value="medium">Média</SelectItem>
              <SelectItem value="low">Baixa</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.responsible} onValueChange={(value) => handleFilterChange('responsible', value)}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Responsável" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              {uniqueResponsibles.map((responsible) => (
                <SelectItem key={responsible} value={responsible}>
                  {responsible}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
}