import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Building2, Briefcase, Phone, Sparkles, User as UserIcon, Target } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function OnboardingModal({ open, onComplete }) {
  const [formData, setFormData] = useState({
    full_name: "",
    company: "",
    position: "",
    phone: "",
    goal: ""
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    
    try {
      console.log("Tentando salvar:", formData);
      
      await base44.auth.updateMe(formData);
      
      console.log("Salvo com sucesso!");
      onComplete();
    } catch (error) {
      console.error("ERRO COMPLETO:", error);
      console.error("Mensagem:", error.message);
      console.error("Stack:", error.stack);
      
      setError(error.message || "Erro ao salvar perfil. Tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <DialogTitle className="text-2xl">Bem-vindo ao OKR Flow!</DialogTitle>
          </div>
          <DialogDescription className="text-base">
            Para começar, conte-nos um pouco sobre você.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-sm text-red-800">
                <strong>Erro:</strong> {error}
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="full_name" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-purple-600" />
              Seu Nome Completo *
            </Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              placeholder="Ex: João Silva"
              required
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="company" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-blue-600" />
              Nome da Empresa *
            </Label>
            <Input
              id="company"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              placeholder="Ex: Acme Corporation"
              required
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="position" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-green-600" />
              Seu Cargo *
            </Label>
            <Input
              id="position"
              value={formData.position}
              onChange={(e) => setFormData({ ...formData, position: e.target.value })}
              placeholder="Ex: CEO, Gerente de Projetos, Analista"
              required
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Phone className="w-4 h-4 text-orange-600" />
              Telefone
            </Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(11) 99999-9999"
              className="border-slate-200 focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="goal" className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Target className="w-4 h-4 text-red-600" />
              O que você busca na ferramenta? *
            </Label>
            <Textarea
              id="goal"
              value={formData.goal}
              onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
              placeholder="Ex: Organizar OKRs da empresa, alinhar equipe com objetivos estratégicos, acompanhar resultados..."
              required
              rows={3}
              className="border-slate-200 focus:border-blue-500 resize-none"
            />
            <p className="text-xs text-slate-500">
              Seja específico - isso nos ajuda a melhorar a ferramenta para você
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              💡 <strong>Por que pedimos isso?</strong>
              <br />
              Para entender melhor nossos usuários e oferecer uma experiência personalizada.
            </p>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            disabled={saving}
          >
            {saving ? "Salvando..." : "Começar a usar o OKR Flow"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}