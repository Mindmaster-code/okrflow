
import React, { useState, useEffect, useCallback } from "react";
import { Objective, Project, KeyResult } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Target, Eye, Building2 } from "lucide-react"; // Added Building2 import
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

import ObjectiveForm from "../components/objectives/ObjectiveForm";
import ObjectiveCard from "../components/objectives/ObjectiveCard";
import ObjectiveFilters from "../components/objectives/ObjectiveFilters";

export default function Objectives() {
  const [objectives, setObjectives] = useState([]);
  const [projects, setProjects] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingObjective, setEditingObjective] = useState(null);
  const [filters, setFilters] = useState({
    project: 'all',
    quarter: 'all',
    year: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all'); // New state for company filter
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]); // New state for all available companies
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({}); // New state to map users to companies

  const recalculateObjectivesProgress = async (objectivesData, keyResultsData) => {
    for (const objective of objectivesData) {
      const relatedKeyResults = keyResultsData.filter(kr => kr.objective_id === objective.id);
      
      let newProgress = 0;
      if (relatedKeyResults.length > 0) {
        const totalProgress = relatedKeyResults.reduce((sum, kr) => {
          const krProgress = kr.target_value > 0 ? Math.min(100, (kr.current_value / kr.target_value) * 100) : 0;
          return sum + krProgress;
        }, 0);
        newProgress = Math.round(totalProgress / relatedKeyResults.length);
      }
      
      if (objective.progress !== newProgress) {
        await Objective.update(objective.id, { progress: newProgress });
      }
    }
  };

  const loadData = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let projectsData;
      let allFetchedProjects = []; 
      
      if (userData.role === 'admin' && showAllUsers) {
        // Admin viewing all projects, potentially filtered by company/user
        allFetchedProjects = await Project.list('-created_date');
        const allUsersData = await User.list(); // Fetch all users to get company info
        
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        const uniqueCompanies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(uniqueCompanies);
        
        let filteredProjectsByCompany = allFetchedProjects;
        let usersInCurrentScope = []; // Users after company filter

        if (selectedCompany !== 'all') {
          // Filter projects by selected company
          const usersFromSelectedCompany = Object.keys(companyMap).filter(
            email => companyMap[email] === selectedCompany
          );
          filteredProjectsByCompany = allFetchedProjects.filter(p => usersFromSelectedCompany.includes(p.created_by));
          usersInCurrentScope = usersFromSelectedCompany;
        } else {
          // No company filter, all users from all fetched projects
          usersInCurrentScope = [...new Set(allFetchedProjects.map(p => p.created_by))];
        }
        setAllUsers(usersInCurrentScope.sort()); // Set allUsers for the dropdown based on company filter

        projectsData = filteredProjectsByCompany;

        // Apply user filter if selectedUser is not 'all'
        if (selectedUser !== 'all') {
          projectsData = projectsData.filter(p => p.created_by === selectedUser);
        }
      } else {
        // Non-admin or admin not showing all users, only own projects
        projectsData = await Project.filter({ created_by: userData.email });
        setAllUsers([]); // Clear allUsers if not in admin all-users view
        setAllCompanies([]); // Clear allCompanies
        setUserCompanyMap({}); // Clear userCompanyMap
      }
      
      setProjects(projectsData);
      
      const allObjectives = await Objective.list('-created_date');
      const projectIds = projectsData.map(p => p.id);
      const objectivesData = allObjectives.filter(obj => projectIds.includes(obj.project_id));
      
      const allKeyResults = await KeyResult.list();
      const objectiveIds = objectivesData.map(obj => obj.id);
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));

      setObjectives(objectivesData);
      setKeyResults(keyResultsData);
      
      await recalculateObjectivesProgress(objectivesData, keyResultsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, [showAllUsers, selectedCompany, selectedUser]); // Added selectedCompany to dependencies

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSubmit = async (objectiveData) => {
    try {
      if (editingObjective) {
        await Objective.update(editingObjective.id, objectiveData);
      } else {
        await Objective.create(objectiveData);
      }
      setShowForm(false);
      setEditingObjective(null);
      loadData();
    } catch (error) {
      console.error('Error saving objective:', error);
    }
  };

  const handleEdit = (objective) => {
    setEditingObjective(objective);
    setShowForm(true);
  };

  const handleDelete = async (objectiveId) => {
    if (window.confirm('Tem certeza que deseja excluir este objetivo? Todos os resultados chave relacionados serão afetados.')) {
      try {
        await Objective.delete(objectiveId);
        loadData();
      } catch (error) {
        console.error('Error deleting objective:', error);
      }
    }
  };

  const getFilteredObjectives = () => {
    return objectives.filter(objective => {
      return (filters.project === 'all' || objective.project_id === filters.project) &&
             (filters.quarter === 'all' || objective.quarter === filters.quarter) &&
             (filters.year === 'all' || objective.year.toString() === filters.year);
    });
  };

  const getObjectiveKeyResults = (objectiveId) => {
    return keyResults.filter(kr => kr.objective_id === objectiveId);
  };

  const getProjectName = (projectId) => {
    const project = projects.find(p => p.id === projectId);
    return project ? project.name : 'Projeto não encontrado';
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="h-80 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Objetivos</h1>
              <p className="text-slate-600">Gerencie seus objetivos estratégicos por trimestre</p>
            </div>
          </div>
          <Button 
            onClick={() => {
              setShowForm(true);
              setEditingObjective(null); // Ensure editingObjective is null for new objective
            }}
            className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Objetivo
          </Button>
        </div>

        {/* Filtro Admin */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-obj" // Changed ID to be more specific
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all'); // Reset company filter when toggling
                      setSelectedUser('all'); // Reset user filter when toggling
                    }}
                  />
                  <Label htmlFor="show-all-obj" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-purple-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all'); // Reset user filter when company changes
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && userCompanyMap[email] !== 'Sem empresa' && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <ObjectiveForm
              objective={editingObjective}
              projects={projects}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingObjective(null);
              }}
            />
          </div>
        )}

        <ObjectiveFilters
          filters={filters}
          onFiltersChange={setFilters}
          projects={projects}
          objectives={objectives}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getFilteredObjectives().map((objective) => (
            <div key={objective.id} className="relative">
              {showAllUsers && user?.role === 'admin' && (
                <Badge className="absolute -top-2 -right-2 z-10 bg-purple-600 text-white text-xs">
                  {projects.find(p => p.id === objective.project_id)?.created_by}
                </Badge>
              )}
              <ObjectiveCard
                objective={objective}
                keyResults={getObjectiveKeyResults(objective.id)}
                projectName={getProjectName(objective.project_id)}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>

        {getFilteredObjectives().length === 0 && (
          <div className="text-center py-16">
            <Target className="w-24 h-24 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              Nenhum objetivo encontrado
            </h3>
            <p className="text-slate-500 mb-6">
              Crie seu primeiro objetivo estratégico para começar
            </p>
            <Button 
              onClick={() => {
                setShowForm(true);
                setEditingObjective(null);
              }}
              className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Criar Primeiro Objetivo
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
