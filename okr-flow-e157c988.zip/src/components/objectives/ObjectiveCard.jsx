
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
// The Progress component is no longer used, so it can be removed from imports.
// import { Progress } from "@/components/ui/progress"; 
import { Target, Calendar, FolderOpen, Key, Pencil, Trash2, TrendingUp } from "lucide-react";

export default function ObjectiveCard({ 
  objective, 
  keyResults, 
  projectName, 
  onEdit, 
  onDelete 
}) {
  const getProgressColor = (progress) => {
    if (progress >= 80) return 'text-green-600';
    if (progress >= 60) return 'text-blue-600';
    if (progress >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getProgressGradient = (progress) => {
    if (progress >= 80) return 'from-green-500 to-green-600';
    if (progress >= 60) return 'from-blue-500 to-blue-600';
    if (progress >= 40) return 'from-yellow-500 to-yellow-600';
    return 'from-red-500 to-red-600';
  };

  const getQuarterColor = (quarter) => {
    switch (quarter) {
      case 'Q1': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Q2': return 'bg-green-100 text-green-700 border-green-200';
      case 'Q3': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Q4': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const completedKeyResults = keyResults.filter(kr => {
    const progress = kr.target_value > 0 ? (kr.current_value / kr.target_value) * 100 : 0;
    return progress >= 100;
  }).length;

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0 group">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            <Badge className={`${getQuarterColor(objective.quarter)}`}>
              {objective.quarter} {objective.year}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {keyResults.length} KR{keyResults.length !== 1 ? 's' : ''}
            </Badge>
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(objective)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-purple-50 hover:text-purple-600"
            >
              <Pencil className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(objective.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        <h3 className="font-bold text-lg text-slate-900 group-hover:text-purple-600 transition-colors leading-tight">
          {objective.title}
        </h3>
        
        {objective.description && (
          <p className="text-slate-600 text-sm mt-2 line-clamp-2">
            {objective.description}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <FolderOpen className="w-4 h-4 text-slate-400" />
            <span className="truncate">{projectName}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Key className="w-4 h-4 text-slate-400" />
            <span>
              {completedKeyResults} de {keyResults.length} resultado{keyResults.length !== 1 ? 's' : ''} concluído{completedKeyResults !== 1 ? 's' : ''}
            </span>
          </div>
        </div>

        {/* Progress Section */}
        <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-700">Progresso Geral</span>
            </div>
            <span className={`text-2xl font-bold ${getProgressColor(objective.progress)}`}>
              {objective.progress}%
            </span>
          </div>
          
          {/* The redundant <Progress> component and its wrapping div.space-y-2 have been removed. 
              Only the custom styled progress bar remains. */}
          <div className={`w-full h-2 rounded-full bg-slate-200`}>
            <div 
              className={`h-2 rounded-full bg-gradient-to-r ${getProgressGradient(objective.progress)} transition-all duration-500`}
              style={{ width: `${objective.progress}%` }}
            />
          </div>
          
          <div className="text-xs text-slate-500">
            {objective.progress >= 80 ? '🎯 Excelente progresso!' :
             objective.progress >= 60 ? '✅ Bom progresso' :
             objective.progress >= 40 ? '⚠️ Atenção necessária' :
             '🚨 Precisa de foco'}
          </div>
        </div>

        {/* Key Results Preview */}
        {keyResults.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-700">Principais Resultados:</h4>
            <div className="space-y-1">
              {keyResults.slice(0, 2).map((kr) => {
                const krProgress = kr.target_value > 0 ? Math.min(100, (kr.current_value / kr.target_value) * 100) : 0;
                return (
                  <div key={kr.id} className="flex items-center justify-between text-xs">
                    <span className="truncate text-slate-600 flex-1 mr-2">{kr.title}</span>
                    <span className={`font-medium ${getProgressColor(krProgress)}`}>
                      {Math.round(krProgress)}%
                    </span>
                  </div>
                );
              })}
              {keyResults.length > 2 && (
                <p className="text-xs text-slate-500">
                  +{keyResults.length - 2} mais...
                </p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
