import { base44 } from './base44Client';


export const migrateInitiatives = base44.functions.migrateInitiatives;

