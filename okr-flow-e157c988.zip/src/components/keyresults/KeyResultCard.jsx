
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
// The Progress import is no longer needed as the component is removed
// import { Progress } from "@/components/ui/progress";
import { Calendar, User, Target, TrendingUp, Pencil, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function KeyResultCard({ 
  keyResult, 
  objectiveInfo, 
  onEdit, 
  onDelete 
}) {
  const getProgressColor = (progress) => {
    if (progress >= 100) return 'text-green-600';
    if (progress >= 80) return 'text-blue-600';
    if (progress >= 60) return 'text-yellow-600';
    if (progress >= 30) return 'text-orange-600';
    return 'text-red-600';
  };

  const getProgressGradient = (progress) => {
    if (progress >= 100) return 'from-green-500 to-green-600';
    if (progress >= 80) return 'from-blue-500 to-blue-600';
    if (progress >= 60) return 'from-yellow-500 to-yellow-600';
    if (progress >= 30) return 'from-orange-500 to-orange-600';
    return 'from-red-500 to-red-600';
  };

  const getStatusIcon = (progress) => {
    if (progress >= 100) return '🎯';
    if (progress >= 80) return '✅';
    if (progress >= 60) return '📈';
    if (progress >= 30) return '⚠️';
    return '🚨';
  };

  const isOverdue = () => {
    const today = new Date();
    const endDate = new Date(keyResult.end_date);
    // Set both dates to the start of the day to compare only the date part
    today.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);
    return endDate < today && keyResult.progress < 100;
  };

  return (
    <Card className={`bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0 group ${
      isOverdue() ? 'ring-1 ring-red-300' : ''
    }`}>
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {objectiveInfo.quarter}
            </Badge>
            {isOverdue() && (
              <Badge className="bg-red-100 text-red-700 text-xs">
                Atrasado
              </Badge>
            )}
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(keyResult)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-green-50 hover:text-green-600"
            >
              <Pencil className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(keyResult.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        <h3 className="font-bold text-lg text-slate-900 group-hover:text-green-600 transition-colors leading-tight">
          {keyResult.title}
        </h3>
        
        {keyResult.description && (
          <p className="text-slate-600 text-sm mt-2 line-clamp-2">
            {keyResult.description}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Target className="w-4 h-4 text-slate-400" />
            <span className="truncate">{objectiveInfo.title}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <User className="w-4 h-4 text-slate-400" />
            <span>{keyResult.responsible}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span className={isOverdue() ? 'text-red-600 font-medium' : ''}>
              {format(new Date(keyResult.start_date), "dd/MM", { locale: ptBR })} - 
              {format(new Date(keyResult.end_date), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
        </div>

        {/* Progress Section */}
        <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-700">Progresso</span>
              <span className="text-sm">{getStatusIcon(keyResult.progress)}</span>
            </div>
            <span className={`text-2xl font-bold ${getProgressColor(keyResult.progress)}`}>
              {keyResult.progress}%
            </span>
          </div>
          
          {/* Removed the redundant Progress component and its wrapper div */}
          <div className={`w-full h-2 rounded-full bg-slate-200`}>
            <div 
              className={`h-2 rounded-full bg-gradient-to-r ${getProgressGradient(keyResult.progress)} transition-all duration-500`}
              style={{ width: `${keyResult.progress}%` }}
            />
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">
              <strong className={getProgressColor(keyResult.progress)}>
                {keyResult.current_value}
              </strong> {keyResult.unit}
            </span>
            <span className="text-slate-500">
              Meta: {keyResult.target_value} {keyResult.unit}
            </span>
          </div>
        </div>

        {/* Project Info */}
        <div className="pt-2 border-t border-slate-200">
          <p className="text-xs text-slate-500">
            Projeto: <span className="font-medium">{objectiveInfo.project}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
