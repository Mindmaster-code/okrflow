import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Calendar, Zap, Clock, Play, CheckCircle2, Pencil, Trash2, ChevronDown, ChevronUp, List } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function SprintCard({ 
  sprint, 
  projects, 
  onEdit, 
  onDelete 
}) {
  const [showProjects, setShowProjects] = useState(false);

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'completed': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'planning': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'Ativo';
      case 'completed': return 'Concluído';
      case 'planning': return 'Planejamento';
      default: return 'Desconhecido';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-600" />;
      case 'completed': return <CheckCircle2 className="w-4 h-4 text-blue-600" />;
      case 'planning': return <Clock className="w-4 h-4 text-yellow-600" />;
      default: return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'done':
        return <Badge className="bg-green-100 text-green-700 text-xs">Feito</Badge>;
      case 'doing':
        return <Badge className="bg-blue-100 text-blue-700 text-xs">Fazendo</Badge>;
      case 'todo':
        return <Badge className="bg-slate-100 text-slate-700 text-xs">A Fazer</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority) => {
    const colors = {
      critical: 'bg-red-100 text-red-700',
      high: 'bg-orange-100 text-orange-700',
      medium: 'bg-yellow-100 text-yellow-700',
      low: 'bg-blue-100 text-blue-700'
    };
    const labels = {
      critical: 'Crítica',
      high: 'Alta',
      medium: 'Média',
      low: 'Baixa'
    };
    return <Badge className={`${colors[priority]} text-xs`}>{labels[priority]}</Badge>;
  };

  const completedProjects = projects.filter(p => p.status === 'done').length;
  const progress = projects.length > 0 
    ? Math.round((completedProjects / projects.length) * 100) 
    : 0;

  const getDaysRemaining = () => {
    const today = new Date();
    const endDate = new Date(sprint.end_date);
    const diffTime = endDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = getDaysRemaining();

  const projectsByStatus = {
    todo: projects.filter(p => p.status === 'todo').length,
    doing: projects.filter(p => p.status === 'doing').length,
    done: projects.filter(p => p.status === 'done').length
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 border-0 group">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            {getStatusIcon(sprint.status)}
            <Badge className={`${getStatusColor(sprint.status)}`}>
              {getStatusLabel(sprint.status)}
            </Badge>
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(sprint)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-indigo-50 hover:text-indigo-600"
            >
              <Pencil className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(sprint.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        <h3 className="font-bold text-lg text-slate-900 group-hover:text-indigo-600 transition-colors leading-tight">
          {sprint.name}
        </h3>
        
        {sprint.description && (
          <p className="text-slate-600 text-sm mt-2 line-clamp-2">
            {sprint.description}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>
              {format(new Date(sprint.start_date), "dd/MM", { locale: ptBR })} - 
              {format(new Date(sprint.end_date), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Zap className="w-4 h-4 text-slate-400" />
            <span>{projects.length} projeto{projects.length !== 1 ? 's' : ''}</span>
          </div>
        </div>

        {/* Progress Section */}
        <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-slate-700">Progresso</span>
            <span className="text-xl font-bold text-slate-900">{progress}%</span>
          </div>
          
          <Progress value={progress} className="h-2" />
          
          <div className="text-xs text-slate-500">
            {daysRemaining > 0 
              ? `${daysRemaining} dia${daysRemaining !== 1 ? 's' : ''} restante${daysRemaining !== 1 ? 's' : ''}` 
              : daysRemaining === 0 
                ? 'Termina hoje' 
                : `Terminou há ${Math.abs(daysRemaining)} dia${Math.abs(daysRemaining) !== 1 ? 's' : ''}`
            }
          </div>
        </div>

        {/* Projects Breakdown */}
        {projects.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-slate-700">Projetos:</h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowProjects(!showProjects)}
                className="h-6 text-xs"
              >
                <List className="w-3 h-3 mr-1" />
                Ver detalhes
                {showProjects ? <ChevronUp className="w-3 h-3 ml-1" /> : <ChevronDown className="w-3 h-3 ml-1" />}
              </Button>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="text-center p-2 bg-slate-100 rounded">
                <div className="font-semibold text-slate-600">{projectsByStatus.todo}</div>
                <div className="text-slate-500">A Fazer</div>
              </div>
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="font-semibold text-blue-600">{projectsByStatus.doing}</div>
                <div className="text-blue-500">Fazendo</div>
              </div>
              <div className="text-center p-2 bg-green-50 rounded">
                <div className="font-semibold text-green-600">{projectsByStatus.done}</div>
                <div className="text-green-500">Feito</div>
              </div>
            </div>

            {/* Lista expandível de projetos */}
            <Collapsible open={showProjects} onOpenChange={setShowProjects}>
              <CollapsibleContent className="space-y-2 mt-3">
                <div className="max-h-64 overflow-y-auto space-y-2 px-2">
                  {projects.map((project) => (
                    <div 
                      key={project.id}
                      className="p-3 bg-white rounded-lg border border-slate-200 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h5 className="font-medium text-sm text-slate-900 flex-1 leading-tight">
                          {project.title}
                        </h5>
                        {getProjectStatusBadge(project.status)}
                      </div>
                      
                      <div className="flex items-center gap-2 flex-wrap">
                        {getPriorityBadge(project.priority)}
                        <span className="text-xs text-slate-600">
                          👤 {project.responsible}
                        </span>
                      </div>
                      
                      {project.description && (
                        <p className="text-xs text-slate-500 mt-2 line-clamp-2">
                          {project.description}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        )}
      </CardContent>
    </Card>
  );
}