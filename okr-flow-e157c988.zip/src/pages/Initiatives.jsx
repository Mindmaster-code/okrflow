
import React, { useState, useEffect, useCallback } from "react";
import { Initiative, Objective, Sprint, KeyResult, Project } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Zap, Filter, Eye, Building2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";


import KanbanBoard from "../components/initiatives/KanbanBoard";
import InitiativeForm from "../components/initiatives/InitiativeForm";
import InitiativeFilters from "../components/initiatives/InitiativeFilters";

export default function Initiatives() {
  const [initiatives, setInitiatives] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [keyResults, setKeyResults] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingInitiative, setEditingInitiative] = useState(null);
  const [filters, setFilters] = useState({
    objective: 'all',
    sprint: 'all',
    priority: 'all',
    responsible: 'all'
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [allCompanies, setAllCompanies] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userCompanyMap, setUserCompanyMap] = useState({});

  const loadData = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      let projectsData;
      
      if (userData.role === 'admin' && showAllUsers) {
        // Fetch all projects for admins when 'show all users' is enabled
        projectsData = await Project.list('-created_date');
        
        // Fetch all users to build company map
        const allUsersData = await User.list();
        const companyMap = {};
        allUsersData.forEach(u => {
          companyMap[u.email] = u.company || 'Sem empresa';
        });
        setUserCompanyMap(companyMap);
        
        // Extract unique company names
        const companies = [...new Set(Object.values(companyMap))].sort();
        setAllCompanies(companies);
        
        let filteredProjectsByCompany = projectsData;
        let usersToDisplayInDropdown = [];

        // Filter projects by selected company
        if (selectedCompany !== 'all') {
          const usersInSelectedCompany = Object.keys(companyMap).filter(
            email => companyMap[email] === selectedCompany
          );
          filteredProjectsByCompany = projectsData.filter(p => usersInSelectedCompany.includes(p.created_by));
          usersToDisplayInDropdown = usersInSelectedCompany;
        } else {
          // If no company selected, show all users who created projects
          usersToDisplayInDropdown = [...new Set(projectsData.map(p => p.created_by))];
        }
        
        setAllUsers(usersToDisplayInDropdown); // Update the users dropdown list

        projectsData = filteredProjectsByCompany; // Apply company filter to projects

        // Filter projects by selected user
        if (selectedUser !== 'all') {
          projectsData = projectsData.filter(p => p.created_by === selectedUser);
        }
      } else {
        // For non-admins or if 'show all users' is off, show only current user's projects
        projectsData = await Project.filter({ created_by: userData.email });
        setAllCompanies([]); // Clear admin specific filters
        setAllUsers([]);
        setSelectedCompany('all');
        setSelectedUser('all');
      }
      
      const projectIds = projectsData.map(p => p.id);
      
      const allObjectives = await Objective.list();
      const objectivesData = allObjectives.filter(obj => projectIds.includes(obj.project_id));
      const objectiveIds = objectivesData.map(obj => obj.id);
      
      const allKeyResults = await KeyResult.list();
      const keyResultsData = allKeyResults.filter(kr => objectiveIds.includes(kr.objective_id));
      const keyResultIds = keyResultsData.map(kr => kr.id);
      
      const allSprints = await Sprint.list();
      const sprintsData = allSprints.filter(spr => projectIds.includes(spr.project_id));
      
      const allInitiatives = await Initiative.list('-created_date');
      const initiativesData = allInitiatives.filter(init => keyResultIds.includes(init.key_result_id));

      setInitiatives(initiativesData);
      setObjectives(objectivesData);
      setSprints(sprintsData);
      setKeyResults(keyResultsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }, [showAllUsers, selectedCompany, selectedUser]);

  useEffect(() => {
    loadData();
    
    // Auto-refresh a cada 30 segundos para manter dashboard atualizado
    const interval = setInterval(() => {
      loadData();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [loadData]); // Added loadData to dependencies

  const handleSubmit = async (initiativeData) => {
    try {
      if (editingInitiative) {
        await Initiative.update(editingInitiative.id, initiativeData);
      } else {
        await Initiative.create({ ...initiativeData, order: 0, status: initiativeData.status || 'backlog' });
      }
      setShowForm(false);
      setEditingInitiative(null);
      loadData();
    } catch (error) {
      console.error('Error saving initiative:', error);
    }
  };

  const handleStatusUpdate = async (initiativeId, newStatus, newIndex) => {
    try {
      const initiative = initiatives.find(i => i.id === initiativeId);
      if (!initiative) return;
      
      if (!initiative.key_result_id) {
        alert('Esta iniciativa precisa ser editada para ter um resultado chave associado antes de ser movida.');
        loadData(); // Revert if validation fails
        return;
      }
      
      // --- Optimistic UI Update ---
      const movedInitiative = { ...initiative, status: newStatus };

      // Get initiatives from the original status column, excluding the moved one
      const initiativesInOldStatus = initiatives
        .filter(i => i.status === initiative.status && i.id !== initiativeId)
        .sort((a, b) => (a.order || 0) - (b.order || 0))
        .map((i, idx) => ({ ...i, order: idx })); // Re-assign orders in the old column

      // Get initiatives from the new status column, excluding the moved one if it was already there
      const initiativesInNewStatus = initiatives
        .filter(i => i.status === newStatus && i.id !== initiativeId)
        .sort((a, b) => (a.order || 0) - (b.order || 0));

      // Insert the moved initiative into the new status column at the specified index
      const newStatusColumnWithMoved = [...initiativesInNewStatus];
      newStatusColumnWithMoved.splice(newIndex, 0, movedInitiative);

      // Re-assign orders in the new status column
      const newStatusColumnWithOrders = newStatusColumnWithMoved.map((i, idx) => ({ ...i, order: idx }));

      // Combine all columns to form the new optimistic state
      const finalOptimisticState = [
        ...initiativesInOldStatus,
        ...newStatusColumnWithOrders,
        ...initiatives.filter(i => i.status !== initiative.status && i.status !== newStatus) // Other unchanged columns
      ];

      setInitiatives(finalOptimisticState);
      
      // --- Backend Update (in background) ---
      // The updates array should contain all initiatives whose status or order has changed.
      // This includes all initiatives that were in the old status column (now potentially reordered)
      // and all initiatives that are now in the new status column (new status and/or new order).
      const updates = finalOptimisticState
        .filter(i => (i.status === initiative.status && i.id !== initiativeId) || i.status === newStatus)
        .map(init => {
          if (!init.key_result_id) {
            console.warn(`Initiative ${init.id} missing key_result_id during API update, skipping:`, init);
            return null;
          }
          return Initiative.update(init.id, {
            key_result_id: init.key_result_id,
            sprint_id: init.sprint_id || null,
            title: init.title,
            description: init.description || '',
            responsible: init.responsible,
            start_date: init.start_date,
            end_date: init.end_date,
            priority: init.priority,
            status: init.status, 
            order: init.order
          });
        }).filter(Boolean); // Remove any null updates
      
      await Promise.all(updates);
      
    } catch (error) {
      console.error('Error updating initiative status:', error);
      alert('Erro ao atualizar status da iniciativa. Verifique se todas têm um resultado chave associado.');
      loadData(); // Only reload on error
    }
  };

  const handleReorder = async (initiativeId, status, oldIndex, newIndex) => {
    try {
      const statusInitiatives = initiatives
        .filter(i => i.status === status)
        .sort((a, b) => (a.order || 0) - (b.order || 0));
      
      const movedInitiative = statusInitiatives.find(i => i.id === initiativeId);
      
      if (!movedInitiative) return;
      if (!movedInitiative.key_result_id) {
        alert(`A iniciativa "${movedInitiative.title}" não pode ser reordenada porque não tem um resultado chave associado. Edite-a para corrigir.`);
        loadData(); // Revert if validation fails
        return;
      }
      
      // --- Optimistic UI Update ---
      const reorderedArray = [...statusInitiatives];
      const [itemToMove] = reorderedArray.splice(oldIndex, 1);
      reorderedArray.splice(newIndex, 0, itemToMove);
      
      // Update orders for the reordered column
      const reorderedColumnWithNewOrders = reorderedArray.map((init, idx) => ({ ...init, order: idx }));

      // Create the new global initiatives state
      const finalOptimisticState = initiatives.map(init => {
        const updatedItem = reorderedColumnWithNewOrders.find(r => r.id === init.id);
        if (updatedItem) {
          return updatedItem; // Replace with updated order if in the reordered column
        }
        return init; // Keep other initiatives as they are
      });

      setInitiatives(finalOptimisticState);
      
      // --- Backend Update (in background) ---
      const updates = reorderedColumnWithNewOrders.map(init => {
        if (!init.key_result_id) { // Safeguard, should be caught by initial check
          console.warn(`Initiative ${init.id} missing key_result_id during API update, skipping:`, init);
          return null;
        }
        return Initiative.update(init.id, {
          key_result_id: init.key_result_id,
          sprint_id: init.sprint_id || null,
          title: init.title,
          description: init.description || '',
          responsible: init.responsible,
          start_date: init.start_date,
          end_date: init.end_date,
          priority: init.priority,
          status: init.status,
          order: init.order
        });
      }).filter(Boolean); // Filter out any null updates
      
      await Promise.all(updates);
      
    } catch (error) {
      console.error('Error reordering initiatives:', error);
      alert('Erro ao reordenar iniciativas. Verifique se todas têm um resultado chave associado.');
      loadData(); // Only reload on error
    }
  };

  const handleEdit = (initiative) => {
    setEditingInitiative(initiative);
    setShowForm(true);
  };

  const handleDelete = async (initiativeId) => {
    if (window.confirm('Tem certeza que deseja excluir esta iniciativa?')) {
      try {
        await Initiative.delete(initiativeId);
        loadData();
      } catch (error) {
        console.error('Error deleting initiative:', error);
      }
    }
  };

  const getFilteredInitiatives = () => {
    let filtered = initiatives;
    
    if (filters.objective !== 'all') {
      const relevantKeyResultIds = keyResults
        .filter(kr => kr.objective_id === filters.objective)
        .map(kr => kr.id);
      filtered = filtered.filter(i => relevantKeyResultIds.includes(i.key_result_id));
    }

    filtered = filtered.filter(initiative => {
      return (filters.sprint === 'all' || initiative.sprint_id === filters.sprint) &&
             (filters.priority === 'all' || initiative.priority === filters.priority) &&
             (filters.responsible === 'all' || initiative.responsible === filters.responsible);
    });

    filtered = filtered.sort((a, b) => (a.order || 0) - (b.order || 0));

    return filtered;
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-48 mb-6"></div>
            <div className="grid grid-cols-3 gap-6">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-96 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-900">Iniciativas</h1>
              <p className="text-slate-600">Quadro Kanban para gerenciar suas ações</p>
            </div>
          </div>
          <Button 
            onClick={() => {
              setEditingInitiative(null);
              setShowForm(true);
            }}
            className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Nova Iniciativa
          </Button>
        </div>

        {/* Filtro Admin */}
        {user?.role === 'admin' && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    id="show-all-init"
                    checked={showAllUsers}
                    onCheckedChange={(checked) => {
                      setShowAllUsers(checked);
                      setSelectedCompany('all'); // Reset company selection when toggling
                      setSelectedUser('all'); // Reset user selection when toggling
                    }}
                  />
                  <Label htmlFor="show-all-init" className="flex items-center gap-2 cursor-pointer">
                    <Eye className="w-4 h-4 text-orange-600" />
                    <span className="font-medium">Ver todos os usuários</span>
                    <Badge variant="outline" className="text-xs">Admin</Badge>
                  </Label>
                </div>

                {showAllUsers && (
                  <div className="flex flex-col md:flex-row gap-3 pt-2">
                    {allCompanies.length > 0 && (
                      <Select 
                        value={selectedCompany} 
                        onValueChange={(value) => {
                          setSelectedCompany(value);
                          setSelectedUser('all'); // Reset user when company changes
                        }}
                      >
                        <SelectTrigger className="w-full md:w-64">
                          <Building2 className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filtrar por empresa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as empresas</SelectItem>
                          {allCompanies.map(company => (
                            <SelectItem key={company} value={company}>{company}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {allUsers.length > 0 && (
                      <Select value={selectedUser} onValueChange={setSelectedUser}>
                        <SelectTrigger className="w-full md:w-64">
                          <SelectValue placeholder="Filtrar por usuário" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todos os usuários</SelectItem>
                          {allUsers.map(email => (
                            <SelectItem key={email} value={email}>
                              {email}
                              {userCompanyMap[email] && (
                                <span className="text-xs text-slate-500 ml-2">
                                  • {userCompanyMap[email]}
                                </span>
                              )}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {showForm && (
          <div className="mb-8">
            <InitiativeForm
              initiative={editingInitiative}
              objectives={objectives}
              keyResults={keyResults}
              sprints={sprints}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingInitiative(null);
              }}
            />
          </div>
        )}

        <InitiativeFilters
          filters={filters}
          onFiltersChange={setFilters}
          objectives={objectives}
          sprints={sprints}
          initiatives={initiatives}
        />

        <KanbanBoard
          initiatives={getFilteredInitiatives()}
          objectives={objectives}
          keyResults={keyResults}
          sprints={sprints}
          onStatusUpdate={handleStatusUpdate}
          onReorder={handleReorder}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
}
